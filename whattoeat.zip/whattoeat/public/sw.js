// Service worker: lets the app be added to the home screen and open without a connection.
//
// The site's own files: network first (so a deploy shows up straight away, as every file is
// served "no-cache"), the saved copy if the network fails or takes more than 3 seconds.
// Libraries from CDNs have the version in their URL, so the saved copy is used when there is one.
// Firestore traffic isn't touched: the Firestore SDK keeps its own offline copy of the data.
const CACHE = "wte-v2";
const SHELL = [
  "./",
  "index.html",
  "recipes.html",
  "recipe.html",
  "editor.html",
  "pantry.html",
  "plan.html",
  "groceries.html",
  "settings.html",
  "manifest.webmanifest",
  "css/styles.css",
  "icons/icon-192.png",
  "icons/favicon-32.png",
  "js/pwa.js",
  "js/firebase.js",
  "js/menu.js",
  "js/vault.js",
  "js/store.js",
  "js/units.js",
  "js/weights.js",
  "js/notes.js",
  "js/cost.js",
  "js/mealplan.js",
  "js/app.js",
  "js/recipes.js",
  "js/recipe.js",
  "js/recipe-pdf.js",
  "js/recipe-excel.js",
  "js/editor.js",
  "js/pantry.js",
  "js/plan.js",
  "js/groceries.js",
  "js/settings.js",
  "js/seed/meals.js",
  "js/seed/questions.js",
  "js/seed/items.js",
  "js/seed/prices.js"
];
// Needed to start at all; the PDF and Excel libraries are saved the first time they're used.
const LIBS = [
  "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js",
  "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js"
];
const CDNS = ["www.gstatic.com", "fonts.googleapis.com", "fonts.gstatic.com", "cdnjs.cloudflare.com", "cdn.jsdelivr.net"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE).then(async (cache) => {
      await cache.addAll(SHELL);
      // A library that can't be fetched now is saved on first use instead.
      await Promise.all(LIBS.map((url) => cache.add(new Request(url, { mode: "cors" })).catch(() => {})));
      await self.skipWaiting();
    })
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin === location.origin) event.respondWith(networkFirst(event));
  else if (CDNS.includes(url.hostname)) event.respondWith(cacheFirst(request));
});

async function networkFirst(event) {
  const { request } = event;
  const cache = await caches.open(CACHE);
  const network = fetch(request).then((response) => {
    if (response.ok) event.waitUntil(cache.put(request, response.clone()));
    return response;
  });
  network.catch(() => {}); // a failure is handled below, whichever answer is used
  const slow = new Promise((resolve) => setTimeout(resolve, 3000));
  const saved = () =>
    cache.match(request).then((hit) => hit || cache.match(request, { ignoreSearch: true })).then((hit) =>
      // recipe.html?id=… uses the saved recipe.html; any other page falls back to the wheel
      hit || (request.mode === "navigate" ? cache.match("index.html") : undefined)
    );
  try {
    const first = await Promise.race([network, slow]);
    if (first) return first;
    return (await saved()) || (await network);
  } catch {
    const hit = await saved();
    if (hit) return hit;
    throw new Error(`Offline and not saved: ${request.url}`);
  }
}

async function cacheFirst(request) {
  const cache = await caches.open(CACHE);
  const hit = await cache.match(request);
  if (hit) return hit;
  const response = await fetch(request);
  if (response.ok || response.type === "opaque") cache.put(request, response.clone());
  return response;
}
