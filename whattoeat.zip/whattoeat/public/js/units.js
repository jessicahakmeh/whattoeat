// Quantities: reading amounts like "200g", "1 1/2 cups", "2-3 cloves" or "6 x 1.5L",
// scaling them, and comparing an amount used in a recipe with a pack size.
//
// Every amount converts to a base unit for its kind:
//   g (weight), ml (volume), pcs (count), cm (length), cm2 (area)
// Counting words such as "clove", "can" or "bunch" keep their own unit, so "2 cloves"
// only compares directly with cloves. Across kinds (a tablespoon of tomato paste against a
// 300g jar, 2 tomatoes against a price per kg), the kitchen weights in weights.js are used
// (or the grocery item's own "Conversion"), and the result is marked approximate.
import { words } from "./menu.js";
import { GRAMS_PER_CUP, GRAMS_PER_PIECE, GRAMS_PER_COUNT, VAGUE_AMOUNTS, SIZE_WORDS, TYPICAL_AMOUNTS, JUICE_PER_GRAM } from "./weights.js";

const UNITS = {
  mg: ["g", 0.001], g: ["g", 1], gr: ["g", 1], grs: ["g", 1], gm: ["g", 1], gram: ["g", 1], gramme: ["g", 1],
  kg: ["g", 1000], kilo: ["g", 1000], kilogram: ["g", 1000],
  oz: ["g", 28.35], ounce: ["g", 28.35], lb: ["g", 453.6], pound: ["g", 453.6],
  ml: ["ml", 1], millilitre: ["ml", 1], milliliter: ["ml", 1], cl: ["ml", 10], dl: ["ml", 100],
  l: ["ml", 1000], lt: ["ml", 1000], ltr: ["ml", 1000], litre: ["ml", 1000], liter: ["ml", 1000],
  "fl oz": ["ml", 29.57],
  tsp: ["ml", 5], teaspoon: ["ml", 5], tbsp: ["ml", 15], tbs: ["ml", 15], tablespoon: ["ml", 15],
  cup: ["ml", 240], glass: ["ml", 250], mug: ["ml", 300],
  pinch: ["g", 0.5, true], dash: ["ml", 0.6, true],
  pc: ["pcs", 1], pcs: ["pcs", 1], piece: ["pcs", 1], unit: ["pcs", 1], each: ["pcs", 1], ea: ["pcs", 1], dozen: ["pcs", 12],
  mm: ["cm", 0.1], cm: ["cm", 1], m: ["cm", 100], metre: ["cm", 100], meter: ["cm", 100], ft: ["cm", 30.48], foot: ["cm", 30.48], feet: ["cm", 30.48],
  "sq ft": ["cm2", 929.03], "sq m": ["cm2", 10000], m2: ["cm2", 10000], sqm: ["cm2", 10000]
};

// Counted things with their own unit ("2 cloves", "1 can").
const COUNT_UNITS = new Set([
  "clove", "slice", "bunch", "can", "tin", "jar", "bottle", "pack", "packet", "bag", "box", "sachet", "stick",
  "sprig", "leaf", "head", "roll", "sheet", "loaf", "fillet", "cube", "carton", "pot", "tub", "bar", "scoop",
  "stalk", "rib", "ear", "pod", "bean"
]);

// Amounts that can't be measured at all ("some").
const UNMEASURED = new Set(["some", "as", "to"]);

const FRACTIONS = { "½": "1/2", "⅓": "1/3", "⅔": "2/3", "¼": "1/4", "¾": "3/4", "⅕": "1/5", "⅙": "1/6", "⅛": "1/8", "⅜": "3/8", "⅝": "5/8", "⅞": "7/8" };
const WORD_NUMBERS = { a: "1", an: "1", one: "1", two: "2", three: "3", four: "4", five: "5", six: "6", half: "1/2" };

// A number: "1 1/2", "1/2", "2" or "1.5" (mixed numbers and fractions first, so "1/2" isn't read as 1).
const NUM = String.raw`\d+\s+\d+\/\d+|\d+\/\d+|\d+(?:\.\d+)?`;
const RANGE = String.raw`\s*(?:-|–|—|to)\s*`;
const AMOUNT = new RegExp(String.raw`^(${NUM})(?:${RANGE}(${NUM}))?`);
const MULTIPACK = new RegExp(String.raw`^(${NUM})\s*(?:x|×|\*)\s*(?=\d)`);
const PREFIX = String.raw`(?:about|approx\.?|approximately|around|roughly|~|c\.)\s*`;
const VAGUE_PHRASE = /^(to taste|as needed|as required)\b/;

// ½ as " 1/2", "1,000" as "1000" and "1,5" as "1.5".
const numerals = (text) =>
  String(text)
    .replace(/[½⅓⅔¼¾⅕⅙⅛⅜⅝⅞]/g, (c) => ` ${FRACTIONS[c]}`)
    .replace(/(\d),(\d{3})(?!\d)/g, "$1$2")
    .replace(/(\d),(\d)/g, "$1.$2")
    .trim();

// Lower case, numerals as above, "about" dropped, "a"/"half a" as numbers.
function normalise(text) {
  let s = numerals(String(text || "").toLowerCase());
  s = s.replace(new RegExp(`^${PREFIX}`), "");
  s = s.replace(/^(a|an|one|two|three|four|five|six|half)\b(?:\s+an?\b)?/, (w) => WORD_NUMBERS[w.split(/\s+/)[0]]);
  return s.trim();
}

function number(text) {
  return text
    .trim()
    .split(/\s+/)
    .reduce((sum, part) => {
      const [a, b] = part.split("/").map(Number);
      return sum + (b ? a / b : a);
    }, 0);
}

const isVague = (w) => Boolean(VAGUE_AMOUNTS[w]);

// "cloves" -> "clove", "leaves" -> "leaf", "boxes" -> "box", "handfuls" -> "handful".
function singular(w) {
  const known = (s) => UNITS[s] || COUNT_UNITS.has(s) || isVague(s);
  if (known(w)) return w;
  const candidates = [w.slice(0, -1), w.slice(0, -2), w.endsWith("ves") ? `${w.slice(0, -3)}f` : ""];
  return w.endsWith("s") ? candidates.find((s) => s && known(s)) || w.slice(0, -1) : w;
}

// The unit at the start of `rest`: [base unit, factor, approx] or null (unmeasurable).
// A vague word ("handful") is ["vague:handful", 1, true]; parseQty resolves it.
function readUnit(rest) {
  const two = rest.match(/^(fl\.?\s*oz|sq\.?\s*(?:ft|m))\b/);
  if (two) return UNITS[two[1].replace(/[.\s]+/g, " ")];
  const w = (rest.match(/^[a-z]+/) || [""])[0];
  if (!w) return ["pcs", 1];
  const s = singular(w);
  if (UNITS[w]) return UNITS[w];
  if (UNITS[s]) return UNITS[s];
  if (COUNT_UNITS.has(s)) return [s, 1];
  if (isVague(s)) return [`vague:${s}`, 1, true];
  if (UNMEASURED.has(w)) return null;
  return ["pcs", 1]; // "2 eggs", "3 large", "1 medium onion"
}

// "1kg" -> { amount: 1000, unit: "g" }; "2-3 cloves" -> { amount: 2.5, unit: "clove", approx: true };
// "1 can (400g)" -> { amount: 400, unit: "g" }; "a pinch" -> { amount: 0.5, unit: "g", approx: true };
// "a handful" of `name` -> a typical weight (≈); "to taste" -> about half a teaspoon (≈); "some" -> null.
export function parseQty(text, name = "") {
  let s = normalise(text);
  if (!s) return null;
  const phrase = s.match(VAGUE_PHRASE);
  if (phrase) return vague(phrase[1], 1, name);
  // A measure without a number ("pinch", "handful"): one of it.
  if (!/^\d/.test(s) && readUnit(s.replace(/^(\w+)\s+/, (m, w) => (SIZE_WORDS[w] ? "" : m)))?.[2]) s = `1 ${s}`;
  let multiplier = 1;
  const pack = s.match(MULTIPACK);
  if (pack) {
    multiplier = number(pack[1]);
    s = s.slice(pack[0].length);
  }
  const m = s.match(AMOUNT);
  if (!m) return null;
  const low = number(m[1]);
  const amount = m[2] ? (low + number(m[2])) / 2 : low;
  let rest = s.slice(m[0].length).trim();
  // "1 big splash", "2 heaped tbsp": the size word scales a measure; "1 large onion" stays a piece.
  let size = 1;
  const sizeWord = rest.match(/^([a-z]+)\s+/);
  if (sizeWord && SIZE_WORDS[sizeWord[1]]) {
    const after = readUnit(rest.slice(sizeWord[0].length));
    if (after && after[0] !== "pcs") {
      size = SIZE_WORDS[sizeWord[1]];
      rest = rest.slice(sizeWord[0].length);
    }
  }
  const unit = readUnit(rest);
  if (!unit || !Number.isFinite(amount)) return null;
  const [base, factor, rough] = unit;
  if (base.startsWith("vague:")) return vague(base.slice(6), amount * multiplier * size, name);
  const result = { amount: amount * factor * multiplier * size, unit: base };
  if (rough || m[2] || size !== 1) result.approx = true;

  // A count with its weight or volume in brackets: "1 can (400g)" is 400g.
  const inner = rest.match(/\(([^)]+)\)/);
  if (inner && !["g", "ml"].includes(base)) {
    const measured = parseQty(inner[1]);
    if (measured && ["g", "ml"].includes(measured.unit)) {
      return { ...measured, amount: measured.amount * amount * multiplier, ...(result.approx && { approx: true }) };
    }
  }
  return result;
}

// n of a vague measure for `name` ("2 handfuls" of cashews = 60g), always approximate.
function vague(word, n, name) {
  const v = VAGUE_AMOUNTS[word];
  const each = (name && byName(v.byName || {}, name)) ?? v.amount;
  return { amount: each * n, unit: v.unit, approx: true, vague: word };
}

// The amount at the start of a line and what follows: "1 tbsp tomato paste" ->
// { qty: "1 tbsp", name: "tomato paste" }; "3 eggs" -> { qty: "3", name: "eggs" }.
export function splitAmount(text) {
  const original = String(text || "").trim();
  const s = normalise(original);
  const phrase = s.match(VAGUE_PHRASE);
  if (phrase) return { qty: phrase[1], name: s.slice(phrase[0].length).replace(/^\s*(of\s+)?/, "") };
  const m = s.match(new RegExp(String.raw`^(${NUM})(?:${RANGE}(${NUM}))?\s*`));
  if (!m) return { qty: "", name: original };
  let rest = s.slice(m[0].length);
  let qty = m[0].trim();
  const two = rest.match(/^(fl\.?\s*oz|sq\.?\s*(?:ft|m))\b\s*/);
  const word = two ? two[0] : (rest.match(/^([a-z]+)\b\s*/) || [""])[0];
  const w = word.trim();
  if (w && (two || UNITS[w] || UNITS[singular(w)] || COUNT_UNITS.has(singular(w)) || isVague(singular(w)))) {
    qty += ` ${w}`;
    rest = rest.slice(word.length);
  }
  return { qty, name: rest.replace(/^(of\s+)/, "").trim() };
}

// ---------- Scaling ----------

const NICE = [[0.25, "¼"], [0.5, "½"], [0.75, "¾"], [1 / 3, "⅓"], [2 / 3, "⅔"]];

function format(n, fractions) {
  if (n >= 10) return String(Math.round(n));
  if (fractions) {
    const whole = Math.floor(n);
    const nice = NICE.find(([f]) => Math.abs(n - whole - f) < 0.02);
    if (nice) return `${whole || ""}${nice[1]}`;
    if (Math.abs(n - Math.round(n)) < 0.02) return String(Math.round(n));
  }
  return String(Math.round(n * 100) / 100);
}

// Spoons and cups in teaspoons (3 tsp = 1 tbsp, 16 tbsp = 1 cup).
const SPOONS = { tsp: 1, tsps: 1, teaspoon: 1, teaspoons: 1, tbsp: 3, tbsps: 3, tbs: 3, tablespoon: 3, tablespoons: 3, cup: 48, cups: 48 };
const near = (n, step) => Math.round(n / step) * step;
const CUP_STEPS = [0.25, 1 / 3, 0.5, 2 / 3, 0.75, 1];

// A spoon amount in the unit you'd measure it with: 10 tsp -> "3½ tbsp", 24 tsp -> "½ cup",
// 0.4 tbsp -> "1¼ tsp". Rounded to what spoons and cups can measure.
function spoonAmount(tsp) {
  const show = (n, unit) => `${format(n, true)} ${unit}`;
  const tbsp = tsp / 3;
  if (tbsp >= 4) {
    const cups = tbsp / 16;
    const whole = Math.floor(cups);
    const best = [whole, ...CUP_STEPS.map((f) => whole + f)].filter((c) => c > 0).reduce((x, y) => (Math.abs(y - cups) < Math.abs(x - cups) ? y : x));
    if (Math.abs(best - cups) / cups <= 0.08) return show(best, best > 1 ? "cups" : "cup");
    if (tbsp <= 8) return show(near(tbsp, 0.5), "tbsp");
    return show(near(cups, 0.25), "cups");
  }
  if (tsp >= 3 && (Math.abs(tbsp - near(tbsp, 0.5)) <= 0.1 || tsp > 8)) return show(Math.max(1, near(tbsp, 0.5)), "tbsp");
  return show(Math.max(0.25, near(tsp, tsp < 3 ? 0.25 : 0.5)), "tsp");
}

// "200g" x 1.5 -> "300g"; "1/2 cup" x 2 -> "1 cup"; "2-3 cloves" x 2 -> "4-6 cloves";
// "2 x 400g" x 2 -> "4 x 400g"; "2 tsp" x 5 -> "3½ tbsp"; "600g" x 2 -> "1.2kg"; "a pinch" stays.
export function scaleQty(text, factor) {
  if (factor === 1 || !text) return text || "";
  const original = String(text);
  const s = numerals(original);
  // "a handful" x 2.5 -> "2½ handfuls", "a pinch" x 2 -> "2 pinches" (they stay as they are when smaller).
  const vague = s.match(/^an?\s+(handful|pinch)\b(.*)$/i);
  if (vague && factor >= 1.5) {
    const n = near(factor, 0.5);
    return `${format(n, true)} ${vague[1].toLowerCase() === "pinch" ? "pinches" : "handfuls"}${vague[2]}`;
  }
  const m = s.match(new RegExp(String.raw`^(${PREFIX})?(${NUM})(?:(${RANGE})(${NUM}))?`, "i"));
  if (!m) return original;
  const [all, prefix = "", a, sep, b] = m;
  // A single spoon, cup or metric amount moves to the unit that reads best.
  const unit = !b && s.slice(all.length).match(/^\s*([a-z]+)\b\.?/i);
  if (unit) {
    const word = unit[1].toLowerCase();
    const rest = s.slice(all.length + unit[0].length);
    const amount = number(a) * factor;
    if (SPOONS[word]) return `${prefix}${spoonAmount(amount * SPOONS[word])}${rest}`;
    const metric = { g: ["g", 1], gr: ["g", 1], kg: ["g", 1000], ml: ["ml", 1], l: ["ml", 1000], lt: ["ml", 1000], ltr: ["ml", 1000] }[unit[1].toLowerCase()];
    if (metric) {
      const base = amount * metric[1];
      const big = base >= 1000;
      const n = big ? base / 1000 : base;
      return `${prefix}${big ? Math.round(n * 100) / 100 : n >= 10 ? Math.round(n) : Math.round(n * 10) / 10}${big ? (metric[0] === "g" ? "kg" : "L") : metric[0]}${rest}`;
    }
  }
  // Kitchen amounts read better as fractions (½ bunch, 1¼ tbsp); metric ones stay decimal.
  const metric = /^\s*(mg|g|gr|kg|ml|cl|dl|l|lt|ltr)\b/i.test(s.slice(all.length));
  const fractions = /[\/½⅓⅔¼¾⅕⅙⅛⅜⅝⅞]/.test(original) || !metric;
  const scaled = format(number(a) * factor, fractions) + (b ? `${sep.trim() === "to" ? " to " : "-"}${format(number(b) * factor, fractions)}` : "");
  return `${prefix}${scaled}${s.slice(all.length)}`;
}

// ---------- Kitchen weights by ingredient name ----------

// Words in their singular form, as weights.js tables are keyed ("bay leaves" -> "bay leaf").
const FIXES = { leave: "leaf", loave: "loaf", chilly: "chili", chillie: "chili", chilli: "chili", chile: "chili", jalapeno: "jalapeno", tomatoe: "tomato", potatoe: "potato" };
const keyWords = (name) => words(name).map((w) => FIXES[w] || w);

// Tables re-keyed the same way, once.
const normalised = new Map();
function table(source) {
  if (!normalised.has(source)) {
    const out = {};
    Object.entries(source).forEach(([k, v]) => (out[keyWords(k).join(" ")] = v));
    normalised.set(source, out);
  }
  return normalised.get(source);
}

// The value for the longest run of words in `name` found in `source` ("tomato paste"
// before "tomato"; "rice vinegar" is vinegar, not rice, because later words win ties).
function byName(source, name) {
  const t = table(source);
  const w = keyWords(name);
  for (let n = Math.min(4, w.length); n >= 1; n--) {
    for (let i = w.length - n; i >= 0; i--) {
      const v = t[w.slice(i, i + n).join(" ")];
      if (v !== undefined) return v;
    }
  }
  return undefined;
}

// Whether the ingredient itself is something you count ("onions", "lemons"), not just a word
// in its name ("tomato paste" isn't counted in tomatoes).
export function countedByPiece(name) {
  const t = table(GRAMS_PER_PIECE);
  const w = keyWords(name);
  return w.length > 0 && (t[w.join(" ")] !== undefined || (w.length === 1 && t[w[0]] !== undefined));
}

// Grams per millilitre of an ingredient, if known.
const density = (name) => {
  const cup = byName(GRAMS_PER_CUP, name);
  return cup === undefined ? undefined : cup / 236.6;
};

// Grams in one `unit` (pcs or a counting word) of the ingredient `name`, if known.
function gramsPer(unit, name) {
  if (unit === "pcs") return byName(GRAMS_PER_PIECE, name);
  const counts = GRAMS_PER_COUNT[unit];
  if (!counts) return undefined;
  const { "*": fallback, ...specific } = counts;
  return byName(specific, name) ?? (unit === "head" || unit === "loaf" ? byName(GRAMS_PER_PIECE, name) : undefined) ?? fallback;
}

// A grocery item's own conversion, e.g. "1 cup = 200g; 1 pc = 150g" -> { ml: g per ml, pcs: g, … }.
// Text that can't be read is ignored (see conversionProblem).
export function itemConversion(item) {
  const out = {};
  String(item?.conversion || "")
    .split(/[;\n]/)
    .forEach((part) => {
      const [left, right] = part.split("=");
      if (!right) return;
      const from = parseQty(left);
      const to = parseQty(right);
      if (!from || !to || !(from.amount > 0) || !(to.amount > 0) || to.unit !== "g") return;
      out[from.unit] = to.amount / from.amount;
    });
  return out;
}

export function conversionProblem(text) {
  const parts = String(text || "").split(/[;\n]/).map((s) => s.trim()).filter(Boolean);
  const bad = parts.filter((p) => {
    const [left, right] = p.split("=");
    const from = parseQty(left);
    const to = right && parseQty(right);
    return !from || !to || to.unit !== "g";
  });
  return bad.length ? `Write it as an amount = grams, like "1 cup = 200g" or "1 pc = 150g" (several: separate with ;).` : "";
}

// Grams in `q` of `name`: { grams, approx } or undefined. `own` is the item's conversion;
// `juice` means the amount is juice squeezed from the fruit ("4 tbsp lemon, juiced").
function toGrams(q, name, own, juice) {
  if (q.unit === "g") return { grams: q.amount, approx: false };
  if (q.unit === "cm" || q.unit === "cm2") return undefined;
  if (own[q.unit]) return { grams: q.amount * own[q.unit], approx: false };
  const yieldPerGram = juice && q.unit === "ml" ? byName(JUICE_PER_GRAM, name) : undefined;
  if (yieldPerGram) return { grams: q.amount / yieldPerGram, approx: true };
  if (q.unit === "ml") {
    const d = density(name);
    return { grams: q.amount * (d ?? 1), approx: true };
  }
  const per = gramsPer(q.unit, name);
  return per ? { grams: q.amount * per, approx: true } : undefined;
}

// Grams back into `unit` (ml, pcs or a counting word).
function fromGrams(grams, unit, name, own) {
  if (unit === "g") return { amount: grams, approx: false };
  if (own[unit]) return { amount: grams / own[unit], approx: false };
  if (unit === "ml") return { amount: grams / (density(name) ?? 1), approx: true };
  const per = gramsPer(unit, name);
  return per ? { amount: grams / per, approx: true } : undefined;
}

const counted = (u) => u === "pcs" || COUNT_UNITS.has(u);

// `q` expressed in `unit` for the ingredient `name` (and its grocery `item`, whose own
// conversion wins): { amount, approx } or null when the two can't be compared (metres
// against grams, a bunch of something with no known weight against a price per kg).
// `state` is how the recipe prepares it: "juiced" turns a volume of juice into fruit.
export function convert(q, unit, name, item, state = "") {
  if (!q) return null;
  // Juice against fruit sold by weight or piece; bottled juice (sold by volume) is 1:1.
  const juice = /juic/i.test(state) && unit !== "ml";
  if (q.unit === unit) return { amount: q.amount, approx: Boolean(q.approx) };
  const own = itemConversion(item);
  const g = toGrams(q, name, own, juice);
  const back = g && fromGrams(g.grams, unit, name, own);
  if (back) return { amount: back.amount, approx: Boolean(q.approx || g.approx || back.approx) };
  // No weights known: a counted thing against pieces is one each ("1 can" of a "1pc" pack).
  if (counted(q.unit) && counted(unit)) return { amount: q.amount, approx: true };
  return null;
}

// Counting words that mean "one of the packs you buy" when nothing else is known:
// "1/2 bag of tortilla chips" is half the bag on the shelf.
const PACK_WORDS = new Set(["bag", "pack", "packet", "box", "jar", "bottle", "carton", "tub", "sachet", "pot", "bar", "can", "tin"]);

// `q` in the units of `pack` (a parsed pack size), counting a pack word as one pack.
export function asPacks(q, pack) {
  return q && pack?.amount > 0 && PACK_WORDS.has(q.unit) ? { amount: q.amount * pack.amount, approx: true } : null;
}

// What a seasoning or condiment listed without an amount ("Salt") is costed at: a typical
// amount ("1 tsp"), or "" when there isn't one.
export const typicalQty = (name) => byName(TYPICAL_AMOUNTS, name) || "";

// ---------- Showing amounts ----------

const trim = (n, places) => String(Math.round(n * 10 ** places) / 10 ** places);

// 16.2 g -> "16 g", 1500 g -> "1.5 kg", 2 clove -> "2 cloves", 0.5 pcs -> "½ pc".
export function formatAmount(amount, unit) {
  if (!Number.isFinite(amount)) return "";
  const small = (n) => trim(n, n < 1 ? 2 : n < 10 ? 1 : 0);
  if (unit === "g") return amount >= 1000 ? `${trim(amount / 1000, 2)} kg` : `${small(amount)} g`;
  if (unit === "ml") return amount >= 1000 ? `${trim(amount / 1000, 2)} L` : `${small(amount)} ml`;
  if (unit === "cm") return amount >= 100 ? `${trim(amount / 100, 2)} m` : `${small(amount)} cm`;
  if (unit === "cm2") return `${trim(amount / 10000, 2)} m²`;
  const n = format(amount, true);
  const word = unit === "pcs" ? "pc" : unit;
  return `${n} ${word}${amount > 1 + 1e-9 && !/s$/.test(word) ? (/(x|ch|sh)$/.test(word) ? "es" : "s") : ""}`;
}

// Price per kg / L / piece / m / m², to compare packs of different sizes.
export function unitPrice(record) {
  const q = parseQty(record.qty);
  if (!q || !(q.amount > 0) || !(record.price >= 0)) return null;
  const per = { g: [1000, "kg"], ml: [1000, "L"], pcs: [1, "pc"], cm: [100, "m"], cm2: [10000, "m²"] }[q.unit] || [1, q.unit];
  return { value: (record.price / q.amount) * per[0], label: per[1] };
}

// A message when an amount or pack size can't be read (shown next to the field), else "".
export function qtyProblem(text) {
  if (!String(text || "").trim()) return "";
  return parseQty(text) ? "" : "Not a measurable amount (try 200g, 2 tbsp, 1/2 cup, a handful or 3 pcs), so costs will use the full pack price.";
}
