// One recipe as an Excel workbook: readable on its own, and what Settings → Import a recipe
// reads back. Sheets:
//   Recipe       Field | Value   (name, emoji, description, servings, minutes, wheel tags…)
//   Ingredients  Amount | Ingredient | Swap | Optional | Item ID | State (diced, juiced…)
//                a swap is its own row, under the ingredient it can replace; Item ID is the
//                grocery item's id, which is its name as a slug ("chicken-breast")
//   Method       Step | What to do
//   Tips         Tip            ([[Recipe name]] links to another recipe)
//   Goes with    What | Recipe | Recipe ID
//   Guide        the recipe's longer write-up, one line per row (only when it has one)
import { ingredientOptions, isOptional, itemSlug, slugify } from "./menu.js";

const asTagList = (v) => (Array.isArray(v) ? v : v === undefined || v === null ? [] : [v]);

// SheetJS, loaded only when it's needed.
const SHEETJS = "https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js";

export function loadSheetJS() {
  if (window.XLSX) return Promise.resolve(window.XLSX);
  return new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = SHEETJS;
    s.onload = () => resolve(window.XLSX);
    s.onerror = () => reject(new Error("Couldn't load the Excel library. Check your connection."));
    document.head.append(s);
  });
}

const SWAP = "↔ or instead of";
const cleanName = (name) => String(name || "").replace(/\s*\(optional\)/i, "").trim();
// The linked item's id; recipes saved before ids were names fall back to the name.
const itemIdOf = (option) => (/^[a-z0-9]+(-[a-z0-9]+)*$/.test(option.itemId || "") ? option.itemId : itemSlug(option.item));
export { itemSlug };

// Wheel questions that tag recipes (time is covered by Minutes).
const tagQuestions = (questions) => questions.filter((q) => !q.options.some((o) => o.min !== undefined || o.max !== undefined));

// "Vegan, Meat" for a recipe's values of one question (each value shown as its option's label).
function tagLabels(meal, q) {
  const specific = q.options.filter((o) => !o.any);
  return [
    ...new Set(
      asTagList(meal[q.field]).map((v) => (specific.find((o) => o.value === v) || specific.find((o) => o.values?.includes(v)))?.label ?? String(v))
    )
  ].join(", ");
}

// …and back: labels (or raw values) to values; one value stays a plain value.
function tagValues(text, q) {
  const values = String(text)
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .map((label) => {
      const o = q.options.find((x) => !x.any && x.label.toLowerCase() === label.toLowerCase());
      return o ? (o.value ?? o.values?.[0]) : label.toLowerCase();
    })
    .filter((v) => v !== undefined);
  return values.length > 1 ? [...new Set(values)] : values[0];
}

const sheet = (XLSX, rows, widths) => {
  const ws = XLSX.utils.aoa_to_sheet(rows);
  ws["!cols"] = widths.map((wch) => ({ wch }));
  return ws;
};

export function recipeWorkbook(XLSX, meal, meals = [], questions = [], siteUrl = "") {
  const book = XLSX.utils.book_new();
  const info = [
    ["Field", "Value"],
    ["Name", meal.name],
    ["Emoji", meal.emoji || ""],
    ["Description", meal.description || ""],
    ["Servings", Number(meal.servings) > 0 ? Number(meal.servings) : ""],
    ["Minutes", typeof meal.minutes === "number" ? meal.minutes : ""],
    ["Prep minutes", Number(meal.prep) || ""],
    ["Cook minutes", Number(meal.cook) || ""],
    ["Chill minutes", Number(meal.chill) || ""],
    ["On the wheel", meal.onWheel === false ? "No" : "Yes"],
    ...tagQuestions(questions).map((q) => [q.title, tagLabels(meal, q)]),
    [],
    ["Recipe ID", meal.id || slugify(meal.name)],
    ["Link", siteUrl && meal.id ? `${siteUrl}/recipe.html?id=${encodeURIComponent(meal.id)}` : ""],
    ["Exported", new Date().toISOString().slice(0, 10)],
    ["Importing", "What To Eat → ⚙️ Settings → Import a recipe, and choose this file."]
  ];
  XLSX.utils.book_append_sheet(book, sheet(XLSX, info, [22, 70]), "Recipe");

  const ingredients = [["Amount", "Ingredient", "Swap", "Optional", "Item ID", "State"]];
  (meal.ingredients || []).forEach((ing) => {
    const [main, ...swaps] = ingredientOptions(ing);
    ingredients.push([main.qty || "", cleanName(main.item), "", isOptional(ing) ? "Yes" : "", itemIdOf(main), ing.state || ""]);
    // A swap's own amount only when it differs (ingredientOptions fills in the main one).
    swaps.forEach((s) => ingredients.push([s.qty && s.qty !== main.qty ? s.qty : "", cleanName(s.item), `${SWAP} ${cleanName(main.item)}`, "", itemIdOf(s), ""]));
  });
  XLSX.utils.book_append_sheet(book, sheet(XLSX, ingredients, [12, 32, 34, 10, 28, 18]), "Ingredients");

  // Sub-steps ("- " lines) stay in their step's cell, one per line.
  const steps = [["Step", "What to do"], ...(meal.steps || []).map((s, i) => [i + 1, s])];
  XLSX.utils.book_append_sheet(book, sheet(XLSX, steps, [6, 100]), "Method");
  XLSX.utils.book_append_sheet(book, sheet(XLSX, [["Tip"], ...(meal.tips || []).map((t) => [t])], [100]), "Tips");
  if (meal.notes) XLSX.utils.book_append_sheet(book, sheet(XLSX, [["Guide"], ...String(meal.notes).split("\n").map((l) => [l])], [120]), "Guide");

  const links = [
    ["What", "Recipe", "Recipe ID"],
    ...(meal.links || []).map((l) => [l.label || "", meals.find((m) => m.id === l.id)?.name || "", l.id])
  ];
  XLSX.utils.book_append_sheet(book, sheet(XLSX, links, [16, 34, 30]), "Goes with");
  return book;
}

// Reads a workbook made by recipeWorkbook (and edited by hand, within reason) into the
// recipe-file shape that readRecipeFile() checks: { app, kind: "recipe", recipe }.
export function readRecipeWorkbook(XLSX, data, questions = []) {
  const book = XLSX.read(data, { type: "array" });
  const rows = (name) => {
    const ws = book.Sheets[Object.keys(book.Sheets).find((n) => n.toLowerCase() === name.toLowerCase())];
    return ws ? XLSX.utils.sheet_to_json(ws, { header: 1, defval: "", raw: true }).slice(1) : null;
  };
  const text = (v) => (v === undefined || v === null ? "" : String(v).trim());
  const info = rows("Recipe");
  if (!info) throw new Error("This workbook has no Recipe sheet.");
  const field = new Map(info.filter((r) => text(r[0])).map((r) => [text(r[0]).toLowerCase(), r[1]]));
  const number = (key) => (text(field.get(key)) === "" ? undefined : Number(field.get(key)));

  const recipe = {
    name: text(field.get("name")),
    emoji: text(field.get("emoji")),
    description: text(field.get("description")),
    servings: number("servings"),
    minutes: number("minutes"),
    prep: number("prep minutes"),
    cook: number("cook minutes"),
    chill: number("chill minutes"),
    onWheel: !/^no$/i.test(text(field.get("on the wheel"))),
    notes: (rows("Guide") || []).map((r) => (r[0] === undefined || r[0] === null ? "" : String(r[0]))).join("\n").trim() || undefined,
    ingredients: [],
    steps: (rows("Method") || []).map((r) => text(r[1] ?? r[0])).filter(Boolean),
    tips: (rows("Tips") || []).map((r) => text(r[0])).filter(Boolean),
    links: (rows("Goes with") || [])
      .filter((r) => text(r[2]) || text(r[1]))
      .map((r) => ({ id: text(r[2]) || slugify(text(r[1])), label: text(r[0]) || undefined, name: text(r[1]) || undefined }))
  };
  tagQuestions(questions).forEach((q) => {
    const v = text(field.get(q.title.toLowerCase()));
    if (v) recipe[q.field] = tagValues(v, q);
  });

  (rows("Ingredients") || []).forEach((r) => {
    const [qty, item, swap, optional, itemId, state] = r.map(text);
    if (!item) return;
    const option = { item, qty: qty || undefined, itemId: itemId || undefined };
    const main = recipe.ingredients[recipe.ingredients.length - 1];
    if (swap && main) (main.swaps ||= []).push(option);
    else recipe.ingredients.push({ ...option, state: state || undefined, optional: /^(yes|y|true|x)$/i.test(optional) || undefined });
  });
  return { app: "whattoeat", kind: "recipe", version: 1, recipe: JSON.parse(JSON.stringify(recipe)) };
}
