// The PIN screen. It only locks the pages: the PIN is compared in the browser with
// the hash stored in settings/pin, and the database itself stays open (see firestore.rules).
import { el } from "./menu.js";

const STORAGE_KEY = "wte-unlocked";

export async function pinHash(pin) {
  const bytes = new TextEncoder().encode(`whattoeat:${pin}`);
  const hash = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(hash)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

// The PIN hash this tab or device was unlocked with.
function remembered() {
  try {
    return sessionStorage.getItem(STORAGE_KEY) || localStorage.getItem(STORAGE_KEY);
  } catch {
    return null;
  }
}

function remember(hash, onDevice) {
  try {
    sessionStorage.setItem(STORAGE_KEY, hash);
    if (onDevice) localStorage.setItem(STORAGE_KEY, hash);
  } catch {
    // Storage blocked: you'll be asked for the PIN again next time.
  }
}

export function lock() {
  try {
    sessionStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    // Nothing stored.
  }
}

// The current PIN hash; null = no PIN set; undefined = couldn't check (offline, never loaded).
async function currentHash() {
  const { loadPinHash } = await import("./store.js");
  try {
    return await loadPinHash();
  } catch (err) {
    console.warn("Couldn't load the PIN.", err);
    return undefined;
  }
}

// True if this tab/device is already unlocked with the current PIN.
export async function isUnlocked() {
  const saved = remembered();
  if (!saved) return false;
  const hash = await currentHash();
  return hash === undefined || hash === null || hash === saved;
}

// Resolves once the pages may be used: straight away if there's no PIN yet or this
// device is unlocked, else after the PIN form rendered into `container` is filled in.
export async function requireUnlock(container, message = "Enter your PIN to continue.") {
  const hash = await currentHash();
  const saved = remembered();
  if (hash === null) return true; // no PIN set yet (Settings asks you to create one)
  if (saved && (hash === undefined || saved === hash)) return true; // offline: trust this device
  if (saved) lock(); // the PIN was changed

  return new Promise((resolve) => {
    container.innerHTML = "";
    const form = el("form", "card pin-card");
    form.innerHTML = `
      <p class="pin-icon" aria-hidden="true">🔒</p>
      <h2>Locked</h2>
      <p class="muted"></p>
      <input class="field pin-input" type="password" inputmode="numeric" pattern="[0-9]{6}" maxlength="6"
             autocomplete="current-password" placeholder="••••••" aria-label="6-digit PIN" required>
      <label class="small"><input type="checkbox"> Remember on this device</label>
      <button class="btn primary" type="submit">Unlock</button>
      <p class="pin-error" role="alert"></p>`;
    form.querySelector(".muted").textContent = message;
    const input = form.querySelector("input[type=password]");
    const rememberBox = form.querySelector("input[type=checkbox]");
    const error = form.querySelector(".pin-error");
    const button = form.querySelector("button");

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      button.disabled = true;
      error.textContent = "";
      const expected = hash === undefined ? await currentHash() : hash;
      if (expected === undefined) {
        error.textContent = "Couldn't reach the database. Check your connection.";
      } else if ((await pinHash(input.value)) === expected) {
        remember(expected, rememberBox.checked);
        container.innerHTML = "";
        resolve(true);
        return;
      } else {
        error.textContent = "Wrong PIN.";
      }
      button.disabled = false;
      input.select();
    });

    // Digits only, and unlock as soon as the 6th digit is typed.
    input.addEventListener("input", () => {
      input.value = input.value.replace(/\D/g, "").slice(0, 6);
      if (input.value.length === 6 && !button.disabled) form.requestSubmit();
    });

    container.appendChild(form);
    input.focus();
  });
}

// After changing the PIN on this device, stay unlocked with the new one.
export function rememberNewPin(hash) {
  let onDevice = false;
  try {
    onDevice = Boolean(localStorage.getItem(STORAGE_KEY));
  } catch {
    // ignore
  }
  remember(hash, onDevice);
}
