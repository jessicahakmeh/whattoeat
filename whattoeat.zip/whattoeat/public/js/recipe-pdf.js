// 📤 Share PDF on a recipe page: the recipe as a designed A4 PDF.
// On a phone it opens the share sheet (WhatsApp, mail, files…); on a computer it opens
// the PDF in a new tab to download or print.
//
// The recipe is laid out as a card (styles.css, .pdf-card) at A4 width, pushed apart so no
// line is cut by a page break, drawn with html2canvas (so emoji look right) and placed into
// a PDF with jsPDF, one image per page. Both libraries load only when a PDF is made.
import { el, ingredientOptions, isOptional, plainTips, mealTags, slugify } from "./menu.js";
import { inline, renderNotes } from "./notes.js";
import { scaleQty } from "./units.js";

const LIBS = [
  "https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js",
  "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"
];
const PAGE_W = 794; // A4 at 96 dpi
const PAGE_H = 1123;
const MARGIN = 48;

function loadScript(src) {
  if (document.querySelector(`script[src="${src}"]`)) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = src;
    s.onload = resolve;
    s.onerror = () => reject(new Error("Couldn't load the PDF maker. Check your connection."));
    document.head.append(s);
  });
}

// The card, at the servings chosen on the page (`factor`).
function recipeCard(meal, { meals = [], questions = [], factor = 1 }) {
  const card = el("div", "pdf-card");
  const block = (node) => (node.classList.add("pdf-block"), node);

  const head = block(el("header", "pdf-head"));
  head.append(el("div", "pdf-emoji", meal.emoji || "🍽️"));
  const titles = el("div");
  titles.append(el("h1", "", meal.name));
  if (meal.description) titles.append(el("p", "pdf-desc", meal.description));
  const chips = el("div", "pdf-chips");
  const base = Number(meal.servings) > 0 ? Number(meal.servings) : null;
  if (base) chips.append(el("span", "", `🍽 Serves ${Math.round(base * factor * 100) / 100}`));
  if (typeof meal.minutes === "number") chips.append(el("span", "", `⏱ ${meal.minutes} min`));
  mealTags(meal, questions)
    .filter((t) => !t.startsWith("⏱"))
    .slice(0, 6)
    .forEach((t) => chips.append(el("span", "", t)));
  if (chips.children.length) titles.append(chips);
  head.append(titles);
  card.append(head);

  const section = (title) => {
    const s = el("section", "pdf-section");
    s.append(block(el("h2", "", title)));
    card.append(s);
    return s;
  };

  if (meal.ingredients?.length) {
    const ul = el("ul", "pdf-ingredients");
    meal.ingredients.forEach((ing) => {
      const [main, ...swaps] = ingredientOptions(ing);
      const li = block(el("li"));
      const qty = scaleQty(main.qty, factor);
      if (qty) li.append(el("b", "", `${qty} `));
      li.append(main.item.replace(/\s*\(optional\)/i, ""));
      if (ing.state) li.append(`, ${ing.state}`);
      if (swaps.length) li.append(el("span", "pdf-or", ` or ${swaps.map((s) => s.item).join(" / ")}`));
      if (isOptional(ing)) li.append(el("span", "pdf-optional", "optional"));
      ul.append(li);
    });
    section("🧺 Ingredients").append(ul);
  }

  const method = section("👩‍🍳 Method");
  if (meal.steps?.length) {
    const ol = el("ol", "pdf-steps");
    meal.steps.forEach((step, i) => {
      const li = block(el("li"));
      // The step, with its sub-steps (lines starting "- ") as a list under it.
      const [first, ...subs] = String(step).split("\n");
      const p = inline(el("p"), plainTips(first));
      if (subs.length) {
        const sub = el("ol", "sub-steps");
        subs.forEach((s) => sub.append(inline(el("li"), plainTips(s.replace(/^\s*[-•]\s*/, "")))));
        p.append(sub);
      }
      li.append(el("span", "pdf-num", String(i + 1)), p);
      ol.append(li);
    });
    method.append(ol);
  } else {
    method.append(block(el("p", "pdf-desc", "No method written yet.")));
  }

  if (meal.tips?.length) {
    const ul = el("ul", "pdf-tips");
    meal.tips.forEach((t) => ul.append(block(inline(el("li"), plainTips(t)))));
    section("💡 Tips").append(ul);
  }

  if (meal.notes?.trim()) {
    const guide = renderNotes(meal.notes);
    // Each part of the guide is its own block, so pages break between them.
    [...guide.children].forEach((child) => block(child));
    section("📘 Guide").append(guide);
  }

  const links = (meal.links || []).map((l) => ({ l, m: meals.find((x) => x.id === l.id) })).filter((x) => x.m);
  if (links.length) {
    const row = block(el("div", "pdf-chips"));
    links.forEach(({ l, m }) => row.append(el("span", "", `${l.label ? `${l.label}: ` : ""}${m.emoji} ${m.name}`)));
    section("🔗 Goes with").append(row);
  }

  card.append(block(el("footer", "pdf-foot", "Made with What To Eat 🍽 · findamunch.web.app")));
  return card;
}

// Pushes any block that would cross a page edge (or a heading left alone at the bottom)
// down to the next page; returns the number of pages.
function paginate(card) {
  for (const b of card.querySelectorAll(".pdf-block")) {
    const top = b.offsetTop;
    const keepWithNext = b.tagName === "H2" ? 90 : 0;
    const bottom = top + b.offsetHeight + keepWithNext;
    const page = Math.floor(top / PAGE_H);
    const limit = (page + 1) * PAGE_H - MARGIN;
    if (bottom > limit && b.offsetHeight < PAGE_H - 2 * MARGIN) {
      b.style.marginTop = `${(parseFloat(getComputedStyle(b).marginTop) || 0) + (page + 1) * PAGE_H + MARGIN - top}px`;
    }
  }
  const pages = Math.max(1, Math.ceil((card.scrollHeight + 1) / PAGE_H));
  card.style.height = `${pages * PAGE_H}px`;
  return pages;
}

// The pages as JPEG data URLs (A4, 2× resolution).
export async function recipePages(meal, options = {}) {
  for (const src of LIBS) await loadScript(src);
  const card = recipeCard(meal, options);
  const holder = el("div", "pdf-holder");
  holder.append(card);
  document.body.append(holder);
  try {
    await document.fonts?.ready;
    const pages = paginate(card);
    const canvas = await window.html2canvas(card, { scale: 2, backgroundColor: "#fffaf3", logging: false, windowWidth: PAGE_W });
    const slice = document.createElement("canvas");
    slice.width = canvas.width;
    slice.height = Math.round(canvas.height / pages);
    const ctx = slice.getContext("2d");
    return Array.from({ length: pages }, (_, p) => {
      ctx.fillStyle = "#fffaf3";
      ctx.fillRect(0, 0, slice.width, slice.height);
      ctx.drawImage(canvas, 0, p * slice.height, slice.width, slice.height, 0, 0, slice.width, slice.height);
      return slice.toDataURL("image/jpeg", 0.9);
    });
  } finally {
    holder.remove();
  }
}

// The PDF as a Blob.
export async function recipePdf(meal, options = {}) {
  const pages = await recipePages(meal, options);
  const pdf = new window.jspdf.jsPDF({ unit: "mm", format: "a4", compress: true });
  pdf.setProperties({ title: meal.name, creator: "What To Eat" });
  pages.forEach((page, p) => {
    if (p) pdf.addPage();
    pdf.addImage(page, "JPEG", 0, 0, 210, 297);
  });
  return pdf.output("blob");
}

// Phones share files to apps; computers get the PDF in a tab instead.
const isPhone = () =>
  navigator.userAgentData?.mobile ?? (/Android|iPhone|iPad|iPod/i.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1));

const canShareFiles = () => {
  try {
    return Boolean(navigator.canShare?.({ files: [new File([""], "x.pdf", { type: "application/pdf" })] }));
  } catch {
    return false;
  }
};

// Wires a button: makes the PDF, then shares it (phone) or opens it in a new tab (computer).
// Sharing needs a fresh tap: if making the PDF took too long for the browser, the button
// asks for one more tap with the PDF ready.
export function sharePdfButton(button, getMeal) {
  let ready = null; // { file } waiting for a tap on a phone
  const label = button.textContent;
  button.addEventListener("click", async () => {
    const phone = isPhone() && canShareFiles();
    if (ready) {
      const { file } = ready;
      ready = null;
      button.textContent = label;
      return share(file);
    }
    // A computer opens the tab now, inside the click, so pop-up blockers allow it.
    const tab = phone ? null : window.open("", "_blank");
    if (tab) tab.document.write("<p style='font:16px system-ui;padding:24px'>Making the PDF…</p>");
    button.disabled = true;
    button.textContent = "Making the PDF…";
    try {
      const { meal, ...options } = getMeal();
      const blob = await recipePdf(meal, options);
      const file = new File([blob], `${slugify(meal.name) || "recipe"}.pdf`, { type: "application/pdf" });
      if (phone) {
        button.textContent = label;
        try {
          await share(file);
        } catch (err) {
          if (err?.name !== "NotAllowedError") throw err;
          ready = { file };
          button.textContent = "📤 Tap to share the PDF";
        }
      } else {
        const url = URL.createObjectURL(blob);
        if (tab) tab.location.href = url;
        else {
          const a = el("a");
          a.href = url;
          a.download = file.name;
          a.click();
        }
        setTimeout(() => URL.revokeObjectURL(url), 60_000);
        button.textContent = label;
      }
    } catch (err) {
      tab?.close();
      button.textContent = label;
      throw err;
    } finally {
      button.disabled = false;
    }
  });

  async function share(file) {
    try {
      await navigator.share({ files: [file], title: file.name.replace(/\.pdf$/, "") });
    } catch (err) {
      if (err?.name !== "AbortError") throw err; // closing the share sheet isn't an error
    }
  }
}
