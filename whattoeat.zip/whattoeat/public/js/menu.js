// Shared data loading, matching helpers and messages used by every page.
//
// The menu (recipes + questions) comes from Firestore's snapshots/menu document.
// If Firestore can't be reached, the copy saved on this device from the last visit
// is used, and failing that the bundled starter menu, with a visible notice.

export const slugify = (s) =>
  s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");

// A grocery item's id: its name as a slug ("Chicken breast" -> "chicken-breast").
export const itemSlug = (name) => slugify(String(name || "").replace(/\s*\(optional\)/i, "").trim());

// ---------- Messages ----------

export function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

// A short message in the corner. kind: "info" | "error". `action` adds a button to it,
// e.g. { label: "Undo", run: () => … }; such toasts stay a little longer.
export function notify(message, kind = "info", action) {
  let box = document.getElementById("toasts");
  if (!box) {
    box = el("div", "toasts");
    box.id = "toasts";
    box.setAttribute("role", "status");
    box.setAttribute("aria-live", "polite");
    document.body.append(box);
  }
  const toast = el("div", `toast ${kind}`, message);
  if (action) {
    const b = el("button", "toast-action", action.label);
    b.type = "button";
    b.addEventListener("click", () => {
      toast.remove();
      action.run();
    });
    toast.append(b);
  }
  box.append(toast);
  setTimeout(() => toast.remove(), kind === "error" ? 7000 : action ? 6500 : 3500);
}

// A notice across the top of the page, for things that affect the whole page.
export function banner(message, kind = "info") {
  const main = document.querySelector("main");
  if (!main || document.getElementById("banner")) return;
  const b = el("p", `banner ${kind}`, message);
  b.id = "banner";
  main.before(b);
}

// Turns Firestore and network errors into something readable.
export function friendlyError(err) {
  const code = err?.code || "";
  if (code === "conflict") return err.message;
  if (code === "permission-denied") return "Not allowed. Your PIN may have changed: lock and unlock again.";
  if (code === "unavailable" || code === "failed-precondition" || !navigator.onLine) {
    return "You're offline. This needs a connection; try again when you're back online.";
  }
  return err?.message ? `Something went wrong: ${err.message}` : "Something went wrong.";
}

if (typeof window !== "undefined") {
  window.addEventListener("unhandledrejection", (e) => {
    console.error(e.reason);
    notify(friendlyError(e.reason), "error");
  });
}

// Background saves still being stored: leaving the page asks first, so a change made
// just before closing isn't lost. Offline, a save counts as stored after 3 seconds
// (it's queued in the browser by then and syncs when you're back online).
const pendingWrites = new Set();

export function trackWrite(promise) {
  const token = {};
  pendingWrites.add(token);
  const release = () => pendingWrites.delete(token);
  promise.then(release, release);
  setTimeout(release, 3000);
  return promise;
}

if (typeof window !== "undefined") {
  window.addEventListener("beforeunload", (e) => {
    if (!pendingWrites.size) return;
    e.preventDefault();
    e.returnValue = "";
  });
}

// Runs an async action from a button: disables it meanwhile and reports failures.
export async function attempt(button, action) {
  if (button) button.disabled = true;
  try {
    return await action();
  } catch (err) {
    console.error(err);
    notify(friendlyError(err), "error");
    return undefined;
  } finally {
    if (button) button.disabled = false;
  }
}

// ---------- Loading the menu ----------

const CACHE_KEY = "wte-menu";

function loadScript(src) {
  return new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = src;
    s.onload = resolve;
    s.onerror = () => reject(new Error(`Couldn't load ${src}`));
    document.head.appendChild(s);
  });
}

// The starter menu bundled with the site (also what Settings imports).
export async function loadSeed() {
  if (!window.MEALS) await loadScript(new URL("./seed/meals.js", import.meta.url).href);
  if (!window.QUESTIONS) await loadScript(new URL("./seed/questions.js", import.meta.url).href);
  return {
    meals: window.MEALS.map((m) => ({ id: slugify(m.name), ...m })),
    questions: JSON.parse(JSON.stringify(window.QUESTIONS)),
    // Starter recipes taken out of the menu (an update removes them unless you wrote them).
    retired: [...(window.RETIRED_MEALS || [])],
    // starter id -> the id of the same dish you wrote ("koussa-mehshi" -> "mehshi-kousa")
    sameAs: { ...(window.SAME_AS || {}) },
    // labels, prep/cook and ingredient states for recipes written in the app
    patches: { ...(window.RECIPE_PATCHES || {}) },
    // written recipes to remove (you chose another recipe of the same dish)
    remove: [...(window.REMOVE_MEALS || [])]
  };
}

// Starter grocery and household items (Settings adds the missing ones).
export async function loadSeedItems() {
  if (!window.ITEMS) await loadScript(new URL("./seed/items.js", import.meta.url).href);
  return window.ITEMS.map((i) => ({ ...i }));
}

// Shop prices for the starter items (Settings adds the ones newer than yours).
export async function loadSeedPrices() {
  if (!window.SHOP_PRICES) await loadScript(new URL("./seed/prices.js", import.meta.url).href);
  return window.SHOP_PRICES.map((p) => ({ ...p }));
}

function cacheMenu(menu) {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify(menu));
  } catch {
    // Storage full or blocked: there's just no offline copy.
  }
}

function cachedMenu() {
  try {
    return JSON.parse(localStorage.getItem(CACHE_KEY));
  } catch {
    return null;
  }
}

// source: "firestore" | "cache" (offline, last visit) | "seed" (empty database or nothing else)
export async function loadMenu() {
  try {
    const store = await import("./store.js");
    const snapshot = await store.loadSnapshot();
    if (snapshot) {
      cacheMenu(snapshot);
      return { ...snapshot, source: "firestore" };
    }
    banner("The recipe book hasn't been set up yet, so this is the starter menu. Import it in ⚙️ Settings.");
    return { ...(await loadSeed()), source: "seed" };
  } catch (err) {
    console.warn("Couldn't load the recipe book from Firestore.", err);
    const cached = cachedMenu();
    if (cached?.meals?.length) {
      banner("You're offline: showing the recipe book from your last visit.");
      return { ...cached, source: "cache" };
    }
    banner("Couldn't reach the recipe book, so this is the starter menu.", "error");
    return { ...(await loadSeed()), source: "seed" };
  }
}

// ---------- Question matching ----------

export const hasField = (meal, field) => meal[field] !== undefined && meal[field] !== null;
const asList = (v) => (Array.isArray(v) ? v : [v]);

// Does a meal satisfy one option? See js/seed/questions.js for the option format.
export function optionMatches(option, meal, field) {
  if (option.any || !hasField(meal, field)) return true;
  const list = asList(meal[field]);
  if (option.min !== undefined || option.max !== undefined) {
    return list.some(
      (v) => (option.min === undefined || v >= option.min) && (option.max === undefined || v <= option.max)
    );
  }
  const accepted = option.values || [option.value];
  return list.some((v) => accepted.includes(v));
}

// A meal passes a question if it fits any of the chosen options (answers: question id -> option indexes).
export function matches(meal, answers, questions) {
  return questions.every((q) => {
    const chosen = answers[q.id];
    return !chosen || chosen.some((i) => optionMatches(q.options[i], meal, q.field));
  });
}

// A tag for each of the meal's values, labelled like the option it fits best
// (an exact `value` match first, so a vegan dish says "Vegan", not "Vegetarian").
export function mealTags(meal, questions) {
  const tags = [];
  if (typeof meal.minutes === "number") tags.push(`⏱ ${meal.minutes} min`);
  questions.forEach((q) => {
    if (!hasField(meal, q.field)) return;
    const specific = q.options.filter((o) => !o.any);
    asList(meal[q.field]).forEach((v) => {
      const single = { [q.field]: v };
      const opt = specific.find((o) => o.value === v) || specific.find((o) => optionMatches(o, single, q.field));
      const tag = opt && `${opt.emoji} ${opt.label}`;
      if (tag && !tags.includes(tag)) tags.push(tag);
    });
  });
  return tags;
}

// ---------- Ingredients ----------
// An ingredient is a plain string ("Chickpeas") or
// { item, qty, itemId, state, optional, swaps: [{ item, itemId, qty? }] }
// (state: how it's prepared, "diced" or "juiced").
// Swaps are alternatives you can use instead (e.g. Tomatoes or Cherry tomatoes);
// each is its own grocery item. A swap without its own qty uses the main one.

export const ingredientName = (ing) => (typeof ing === "string" ? ing : ing?.item || "");
export const ingredientQty = (ing) => (typeof ing === "string" ? "" : ing?.qty || "");
export const isOptional = (ing) => Boolean(ing?.optional) || /\(optional\)/i.test(ingredientName(ing));

// The main ingredient followed by its swaps, all as { item, itemId, qty }.
export function ingredientOptions(ing) {
  if (typeof ing === "string") return [{ item: ing, qty: "" }];
  const main = { item: ing.item || "", itemId: ing.itemId, qty: ing.qty || "" };
  return [main, ...(ing.swaps || []).map((s) => ({ item: s.item, itemId: s.itemId, qty: s.qty || main.qty }))];
}

// Rough singular form so "tomatoes" and "tomato" compare equal.
const stem = (w) => {
  if (w.length > 4 && w.endsWith("ies")) return w.slice(0, -3) + "y";
  if (w.length > 4 && w.endsWith("oes")) return w.slice(0, -2);
  if (w.length > 3 && w.endsWith("s") && !w.endsWith("ss")) return w.slice(0, -1);
  return w;
};

export const words = (s) =>
  String(s || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/\(.*?\)/g, " ")
    .split(/[^a-z0-9]+/)
    .filter(Boolean)
    .map(stem);

// How well something you have covers one ingredient name:
//   2 = same thing ("tomatoes" / "Tomatoes", or more specific: "cherry tomatoes" covers "Tomatoes")
//   1 = loosely ("oil" for "Sesame oil": probably, but check)
//   0 = no
export function nameMatch(have, name) {
  const h = words(have);
  const w = words(name);
  if (!h.length || !w.length) return 0;
  if (w.every((x) => h.includes(x))) return 2;
  if (h.every((x) => w.includes(x))) return 1;
  return 0;
}

// Best match against an ingredient and all its swaps.
export const ingredientMatch = (have, ing) =>
  Math.max(...ingredientOptions(ing).map((o) => nameMatch(have, o.item)));

export const ingredientMatches = (have, ing) => ingredientMatch(have, ing) > 0;

// ---------- Links ----------

export const recipeUrl = (meal) => `recipe.html?id=${encodeURIComponent(meal.id)}`;

// A recipe by its name (any case) or id, as written in a tip: [[Homemade Caesar Dressing]].
export function findRecipe(meals, ref) {
  const key = ref.trim().toLowerCase();
  return meals.find((m) => m.name.toLowerCase() === key) || meals.find((m) => m.id === slugify(ref));
}

// ---------- Files ----------

export function downloadJson(name, data) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const a = el("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

// Checks an imported recipe and returns { recipe, problems }. It takes the shape
// readRecipeWorkbook() makes from an Excel export, { app: "whattoeat", kind: "recipe", recipe },
// which is also what older .json exports hold (or a bare recipe object).
// The recipe keeps only known fields: the basics, ingredients, steps, tips, links and the
// wheel-tag fields of `questions`; everything is size-limited.
export function readRecipeFile(data, questions = []) {
  if (data?.app === "whattoeat" && Array.isArray(data.meals)) {
    return { problems: ["That's a full backup. Use Restore from backup for it."] };
  }
  const r = data?.app === "whattoeat" ? data.recipe : data;
  if (!r || typeof r !== "object" || Array.isArray(r)) return { problems: ["That file doesn't hold a recipe."] };
  const problems = [];
  const text = (v, max) => typeof v === "string" && v.trim() && v.length <= max;
  const optionalText = (v, max) => v === undefined || v === null || v === "" || (typeof v === "string" && v.length <= max);
  const list = (v, max) => v === undefined || (Array.isArray(v) && v.length <= max);

  if (!text(r.name, 120)) problems.push("It needs a name (up to 120 characters).");
  if (!optionalText(r.emoji, 16)) problems.push("The emoji is too long.");
  if (!optionalText(r.description, 500)) problems.push("The description is longer than 500 characters.");
  if (r.servings !== undefined && !(Number.isInteger(r.servings) && r.servings > 0 && r.servings <= 100)) problems.push("Servings must be a whole number from 1 to 100.");
  // Up to two weeks: a sourdough starter takes days.
  const minutesOk = (v) => v === undefined || (typeof v === "number" && v >= 0 && v <= 20160);
  if (!minutesOk(r.minutes)) problems.push("Minutes must be a number from 0 to 20160.");
  ["prep", "cook", "chill"].forEach((k) => !minutesOk(r[k]) && problems.push(`The ${k} time must be a number of minutes.`));
  if (!optionalText(r.notes, 30000)) problems.push("The guide is longer than 30,000 characters.");
  if (!list(r.ingredients, 100)) problems.push("Ingredients must be a list of up to 100.");
  if (!list(r.steps, 100) || (r.steps || []).some((s) => !text(s, 2000))) problems.push("Steps must be a list of up to 100 texts.");
  if (!list(r.tips, 50) || (r.tips || []).some((s) => !text(s, 2000))) problems.push("Tips must be a list of up to 50 texts.");
  if (!list(r.links, 20) || (r.links || []).some((l) => !text(l?.id, 120))) problems.push("Links must be a list of { id, label }.");

  const option = (o, where) => {
    if (!text(o?.item, 120)) return problems.push(`${where} needs a name.`);
    if (!(typeof o.qty === "number" || optionalText(o.qty, 60))) problems.push(`${where}: the amount must be short text like "200g".`);
    if (!optionalText(o.itemId, 64)) problems.push(`${where}: the item id is too long.`);
  };
  const ingredients = [];
  (Array.isArray(r.ingredients) ? r.ingredients : []).forEach((ing, i) => {
    const where = `Ingredient ${i + 1}`;
    if (typeof ing === "string") return text(ing, 120) ? ingredients.push({ item: ing.trim() }) : problems.push(`${where} is empty or too long.`);
    option(ing, where);
    if (!list(ing?.swaps, 10)) problems.push(`${where}: swaps must be a list of up to 10.`);
    (ing?.swaps || []).forEach((s, j) => option(s, `${where}, swap ${j + 1}`));
    if (!text(ing?.item, 120)) return;
    const pick = (o) => ({ item: o.item.trim(), itemId: o.itemId || undefined, qty: o.qty === undefined || o.qty === null ? undefined : String(o.qty).trim() || undefined });
    ingredients.push({
      ...pick(ing),
      state: optionalText(ing.state, 60) && ing.state?.trim() ? ing.state.trim() : undefined,
      optional: ing.optional === true || undefined,
      swaps: ing.swaps?.length ? ing.swaps.filter((s) => text(s?.item, 120)).map(pick) : undefined
    });
  });
  if (problems.length) return { problems };

  const recipe = {
    name: r.name.trim(),
    emoji: r.emoji?.trim() || "🍽️",
    description: r.description?.trim() || "",
    servings: r.servings,
    minutes: r.minutes,
    prep: r.prep,
    cook: r.cook,
    chill: r.chill,
    notes: r.notes?.trim() || undefined,
    onWheel: r.onWheel !== false,
    ingredients,
    steps: (r.steps || []).map((s) => s.trim()),
    tips: (r.tips || []).map((s) => s.trim()),
    links: (r.links || []).map((l) => ({ id: l.id, label: optionalText(l.label, 60) ? l.label || undefined : undefined, name: optionalText(l.name, 120) ? l.name : undefined }))
  };
  // Wheel tags: a value or a short list of values, for the fields the questions ask about.
  const tagValue = (v) => (typeof v === "string" && v.length <= 60) || typeof v === "number";
  questions.forEach((q) => {
    const v = r[q.field];
    if (q.field in recipe || v === undefined) return;
    if (tagValue(v) || (Array.isArray(v) && v.length <= 20 && v.every(tagValue))) recipe[q.field] = v;
  });
  return { recipe: JSON.parse(JSON.stringify(recipe)), problems };
}

// Tip text without the [[ ]] link markers (for exports).
export const plainTips = (text) => text.replace(/\[\[([^\]]+)\]\]/g, "$1");
export const hasOwnRecipe = (meal) => Array.isArray(meal.steps) && meal.steps.length > 0;
export const searchUrl = (meal) => `https://www.google.com/search?q=${encodeURIComponent(meal.name + " recipe")}`;
