// Kitchen settings: PIN setup, starter menu import, backup/restore, importing one recipe,
// wheel questions editor, snapshot repair.
import {
  loadMenu,
  loadSeed,
  loadSeedItems,
  loadSeedPrices,
  hasOwnRecipe,
  itemSlug,
  readRecipeFile,
  downloadJson,
  findRecipe,
  recipeUrl,
  slugify,
  friendlyError,
  notify,
  el
} from "./menu.js";
import { findItem, guessCategory, LBP_RATE } from "./cost.js";
import { loadSheetJS, readRecipeWorkbook } from "./recipe-excel.js";
import { pinHash, requireUnlock, rememberNewPin, lock } from "./vault.js";

const $ = (id) => document.getElementById(id);
const ANIMATIONS = ["roll", "flicker", "spin", "zap", "flip", "sway", "wiggle", "bounce", "swim", "shake"];

// ---------- Helpers ----------

function card(title, intro) {
  const box = el("section", "card recipe-section");
  box.append(el("h2", "", title));
  if (intro) box.append(el("p", "muted small", intro));
  return box;
}

function button(label, kind = "") {
  const b = el("button", `btn ${kind}`.trim(), label);
  b.type = "button";
  return b;
}

// Runs an action, showing progress and the outcome in `status`.
async function run(btn, status, working, action) {
  btn.disabled = true;
  status.className = "small";
  status.textContent = working;
  try {
    status.textContent = (await action()) || "✓ Done.";
  } catch (err) {
    console.error(err);
    status.className = "small pin-error";
    status.textContent = friendlyError(err);
  }
  btn.disabled = false;
}

// Checks the questions JSON before saving; returns a list of problems.
export function validateQuestions(list) {
  if (!Array.isArray(list)) return ["The JSON must be a list: [ {…}, {…} ]."];
  const problems = [];
  const ids = new Set();
  list.forEach((q, i) => {
    const where = `Question ${i + 1}${q?.title ? ` ("${q.title}")` : ""}`;
    if (!q || typeof q !== "object") return problems.push(`${where} isn't an object.`);
    if (!q.id || typeof q.id !== "string") problems.push(`${where} needs an "id".`);
    else if (ids.has(q.id)) problems.push(`${where}: the id "${q.id}" is used twice.`);
    else ids.add(q.id);
    if (!q.field || typeof q.field !== "string") problems.push(`${where} needs a "field".`);
    if (!q.title) problems.push(`${where} needs a "title".`);
    if (!Array.isArray(q.options) || !q.options.length) return problems.push(`${where} needs at least one option.`);
    q.options.forEach((o, j) => {
      const at = `${where}, option ${j + 1}`;
      if (!o || typeof o !== "object") return problems.push(`${at} isn't an object.`);
      if (!o.label) problems.push(`${at} needs a "label".`);
      const filters = ["value", "values", "any"].filter((k) => o[k] !== undefined).length + (o.min !== undefined || o.max !== undefined ? 1 : 0);
      if (filters !== 1) problems.push(`${at} needs exactly one of value, values, min/max or any.`);
      if (o.values !== undefined && !Array.isArray(o.values)) problems.push(`${at}: "values" must be a list.`);
      if (o.animate && !ANIMATIONS.includes(o.animate)) problems.push(`${at}: animate must be one of ${ANIMATIONS.join(", ")}.`);
    });
  });
  return problems;
}

// A file picker hidden behind a button; calls onFile with the file's data (`parse` turns the
// file into data; JSON by default), or reports a file it can't read.
const readJson = async (file) => JSON.parse(await file.text());
function jsonPicker(label, status, onFile, id, { accept = "application/json,.json", parse = readJson } = {}) {
  const input = el("input");
  input.id = id;
  input.type = "file";
  input.accept = accept;
  input.hidden = true;
  const btn = button(label);
  btn.addEventListener("click", () => input.click());
  input.addEventListener("change", async () => {
    const file = input.files[0];
    input.value = "";
    if (!file) return;
    let data;
    try {
      if (file.size > 2_000_000) throw new Error("too big");
      data = await parse(file);
      if (!data) throw new Error("empty");
    } catch {
      status.className = "small pin-error";
      status.textContent = "That file can't be read (not a What To Eat file, or bigger than 2 MB).";
      return;
    }
    onFile(data, file);
  });
  return [btn, input];
}

// Saves an imported recipe: ingredients are linked to grocery items (by id, else by name,
// else a new item), links to recipes in this book (by id, else by name; others are dropped).
// mode "replace" overwrites the recipe with the same name; "copy" saves it under a new name.
async function saveImportedRecipe(recipe, meals, mode) {
  const items = await store.loadItems();
  const pending = [];
  let newItems = 0;
  const link = (option) => {
    // Item ID: the item's id ("chicken-breast"); in older exports a random id, so the name decides.
    const found = findItem(option, items) || (option.itemId && items.find((i) => itemSlug(i.name) === option.itemId));
    if (found) return found.id;
    const name = option.item.replace(/\s*\(optional\)/i, "").trim();
    const created = store.createItem({ name, category: guessCategory(name), purchaseQty: "", toPurchase: false, packs: 1 }, items);
    items.push({ id: created.id, name });
    pending.push(created.done);
    newItems++;
    return created.id;
  };
  const ingredients = recipe.ingredients.map((ing) => ({
    ...ing,
    itemId: link(ing),
    swaps: ing.swaps?.map((s) => ({ ...s, itemId: link(s) }))
  }));
  let dropped = 0;
  const links = recipe.links
    .map(({ id, label, name }) => {
      const target = meals.find((m) => m.id === id) || (name && findRecipe(meals, name));
      if (!target) dropped++;
      return target && { id: target.id, label };
    })
    .filter(Boolean);

  let { name } = recipe;
  if (mode === "copy") {
    for (let n = 1; meals.some((m) => m.id === slugify(name)); n++) name = `${recipe.name} (imported${n > 1 ? ` ${n}` : ""})`;
  }
  await Promise.all(pending);
  // Replacing was chosen explicitly, so it overwrites whatever is saved under that name now.
  const id = await store.saveMeal({ ...recipe, name, id: slugify(name), ingredients, links }, { force: mode === "replace" });
  return { id, name, newItems, dropped };
}

// Labels for one of your written recipes: the starter recipe with the same id, or the one
// that's the same dish, or the starter list for app-written recipes, else a guess.
function labelsFor(meal, seed) {
  const same = seed.meals.find((s) => s.id === meal.id) || seed.meals.find((s) => seed.sameAs[s.id] === meal.id);
  if (same?.labels?.length) return same.labels;
  if (seed.patches[meal.id]?.labels) return seed.patches[meal.id].labels;
  const name = meal.name.toLowerCase();
  const diet = [].concat(meal.diet || []);
  if (/sauce|dressing|dip|toum|hummus|mayo|glaze/.test(name)) return ["Sauces Dips & Glazes"];
  if (/cake|cookie|pudding|brownie|dessert|sweet|tart/.test(name)) return ["Dessert"];
  if (/pasta|spaghetti|penne|lasagn|macaroni|fettuccine/.test(name)) return ["Pasta Dishes"];
  if (/salad|soup|shorba/.test(name)) return ["Soup & Salad"];
  if (diet.includes("chicken")) return ["Chicken"];
  if (diet.includes("meat")) return ["Beef"];
  return ["Veg Mains"];
}

// What to fill in on one of your written recipes: labels, prep/cook/chill and ingredient
// states, only where they're still empty. Returns {} when there's nothing to add.
function recipePatch(meal, seed) {
  const patch = {};
  if (!meal.labels?.length) patch.labels = labelsFor(meal, seed);
  const extra = seed.patches[meal.id];
  if (!extra) return patch;
  ["prep", "cook", "chill"].forEach((k) => {
    if (extra[k] && !(Number(meal[k]) > 0)) patch[k] = extra[k];
  });
  const states = extra.states || {};
  let changed = false;
  const ingredients = (meal.ingredients || []).map((ing) => {
    const state = typeof ing === "object" && !ing.state && states[ing.item];
    if (!state) return ing;
    changed = true;
    return { ...ing, state };
  });
  if (changed) patch.ingredients = ingredients;
  return patch;
}

// ---------- 1. PIN ----------

const locked = $("locked");
const store = await import("./store.js");

// Two 6-digit fields (new + repeat); resolves the new PIN's hash once they match and are saved.
function pinForm(box, label) {
  const form = el("form", "add-row");
  const field = (aria, placeholder) => {
    const i = el("input", "field pin-input narrow");
    Object.assign(i, { type: "password", inputMode: "numeric", maxLength: 6, placeholder, autocomplete: "new-password" });
    i.setAttribute("aria-label", aria);
    i.addEventListener("input", () => (i.value = i.value.replace(/\D/g, "").slice(0, 6)));
    return i;
  };
  const first = field("New 6-digit PIN", "new");
  const again = field("Repeat the new PIN", "repeat");
  const save = el("button", "btn primary", label);
  save.type = "submit";
  const status = el("p", "small");
  form.append(first, again, save);
  box.append(form, status);
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    status.className = "small pin-error";
    if (!/^\d{6}$/.test(first.value)) return (status.textContent = "Use exactly 6 digits.");
    if (first.value !== again.value) return (status.textContent = "The two PINs don't match.");
    run(save, status, "Saving…", async () => {
      const hash = await pinHash(first.value);
      await store.savePinHash(hash);
      rememberNewPin(hash);
      first.value = again.value = "";
      setTimeout(render, 800);
      return "✓ PIN saved. Use it from now on, on every device.";
    });
  });
}

// The page is built in steps with awaits in between; a newer render() makes an
// older one stop, so two overlapping renders can't interleave their cards.
let renderToken = 0;

async function render() {
  const token = ++renderToken;
  const stale = () => token !== renderToken;
  locked.innerHTML = "";
  const hasPin = (await store.loadPinHash().catch(() => undefined)) !== null;
  if (stale()) return;

  if (!hasPin) {
    const box = card(
      "1. Create your PIN",
      "Choose the 6-digit PIN that unlocks the grocery list, prices, the recipe editor and these settings."
    );
    pinForm(box, "Create PIN");
    locked.append(box);
    return;
  }

  await requireUnlock(locked, "Enter your PIN to manage the recipe book.");
  if (stale()) return;
  locked.innerHTML = "";
  const pinBox = card("1. PIN", "Change the 6-digit PIN. Other devices will ask for the new one next time.");
  pinForm(pinBox, "Change PIN");
  locked.append(pinBox);

  const [{ meals, questions, source }, seed] = await Promise.all([loadMenu(), loadSeed()]);
  if (stale()) return;

  // Starter menu
  const importBox = card(
    "2. Starter menu",
    source === "firestore"
      ? `The recipe book has ${meals.length} recipes and ${questions.length} questions.`
      : source === "cache"
        ? "You're offline, so this can't be checked right now."
        : "The database is empty, so every page is showing the bundled starter menu."
  );
  // Recipes you've written steps for are never overwritten by the starter menu. Only the
  // database's recipes count: with an empty database `meals` is the starter menu itself.
  const own = source === "firestore" ? meals : [];
  const written = new Set(own.filter(hasOwnRecipe).map((m) => m.id));
  const known = new Set(own.map((m) => m.id));
  // A starter recipe that's the same dish as one you wrote under another id isn't added next to it.
  const covered = new Set(Object.entries(seed.sameAs).filter(([, mine]) => written.has(mine)).map(([starter]) => starter));
  const fresh = seed.meals.filter((m) => !known.has(m.id) && !covered.has(m.id));
  const refreshable = seed.meals.filter((m) => known.has(m.id) && !written.has(m.id));
  // Starter recipes taken out of the menu; ones you've written steps for stay.
  // Written recipes you chose to replace go too (and starter ones taken out of the menu).
  const removingOwn = seed.remove.filter((id) => known.has(id));
  const retiring = [...seed.retired.filter((id) => known.has(id) && !written.has(id)), ...removingOwn];
  const keptRetired = seed.retired.filter((id) => written.has(id));
  // Your written recipes get what Notion has and they don't yet: labels, prep/cook, ingredient states.
  // Your own ideas that aren't in the starter menu get labels too (starter ones get theirs on import).
  const seedIds = new Set(seed.meals.map((m) => m.id));
  const labelPatches = Object.fromEntries(
    own
      .filter((m) => (hasOwnRecipe(m) || !seedIds.has(m.id)) && !removingOwn.includes(m.id) && !retiring.includes(m.id))
      .map((m) => [m.id, recipePatch(m, seed)])
      .filter(([, p]) => Object.keys(p).length)
  );
  const labelled = Object.keys(labelPatches).length;
  const changes = [
    fresh.length && `${fresh.length} new`,
    retiring.length && `${retiring.length} to remove`,
    labelled && `extras for ${labelled} of yours`
  ].filter(Boolean);
  const importBtn = button(
    source === "firestore"
      ? `Update from starter menu (${changes.join(", ") || "up to date"})`
      : `Import starter menu (${seed.meals.length} recipes, ${seed.questions.length} questions)`,
    source === "seed" || changes.length ? "primary" : ""
  );
  importBtn.disabled = source === "cache";
  const importStatus = el("p", "small");
  importBtn.addEventListener("click", () => {
    const warning =
      source === "firestore"
        ? [
            `Add ${fresh.length} new recipes, refresh the tags and labels of ${refreshable.length} starter recipes and replace the wheel questions with the starter ones?`,
            retiring.length ? `${retiring.length} starter recipes that were taken out of the menu will be removed (they're marked deleted, so they can be brought back from the Firebase console).` : "",
            removingOwn.length
              ? `Removed because you chose another recipe of the same dish: ${removingOwn.map((id) => meals.find((m) => m.id === id)?.name || id).join(", ")}.`
              : "",
            labelled
              ? `Filled in on ${labelled} of your written recipes (only what was empty): ${Object.entries(labelPatches)
                  .map(([id, p]) => {
                    const bits = [p.labels && `labels ${p.labels.join(", ")}`, (p.prep || p.cook) && `prep ${p.prep || "–"} / cook ${p.cook || "–"} min`, p.ingredients && "ingredient states"].filter(Boolean);
                    return `${meals.find((m) => m.id === id)?.name}: ${bits.join(", ")}`;
                  })
                  .join("; ")}. Change them in the editor any time.`
              : "",
            `Your ${written.size} written recipes are otherwise left alone, and so is anything you've deleted. Download a backup first if you've edited starter recipes or questions.`
          ]
            .filter(Boolean)
            .join("\n\n")
        : "Import the starter menu into the database?";
    if (!confirm(warning)) return;
    run(importBtn, importStatus, "Importing…", async () => {
      const deleted = source === "firestore" ? await store.deletedMealIds() : new Set();
      const incoming = seed.meals.filter((m) => !written.has(m.id) && !deleted.has(m.id) && !covered.has(m.id));
      await store.importMenu(incoming, seed.questions, retiring);
      await store.patchMeals(labelPatches);
      setTimeout(render, 800);
      return `✓ Imported ${incoming.length} recipes${retiring.length ? `, removed ${retiring.length}` : ""}${labelled ? `, filled in ${labelled} of yours` : ""}.`;
    });
  });
  if (source === "firestore" && keptRetired.length) {
    importBox.append(
      el("p", "muted small", `Kept because you wrote them, although they're no longer in the starter menu: ${keptRetired.map((id) => meals.find((m) => m.id === id)?.name || id).join(", ")}.`)
    );
  }
  importBox.append(importBtn, importStatus);

  // Starter grocery and household items, and the shop prices for them
  if (source === "firestore") {
    const [items, starterItems, shopPrices, latest] = await Promise.all([
      store.loadItems(),
      loadSeedItems(),
      loadSeedPrices(),
      store.loadLatestPrices()
    ]);
    if (stale()) return;
    const byName = new Map(items.map((i) => [i.name.trim().toLowerCase(), i]));
    const missing = starterItems.filter((i) => !byName.has(i.name.toLowerCase()));
    // Items you have whose aliases, brand or conversion are still empty get the starter ones;
    // nothing you've filled in is changed.
    const details = items
      .map((i) => {
        const seed = starterItems.find((s) => s.name.toLowerCase() === i.name.trim().toLowerCase());
        const changes = seed && Object.fromEntries(["aliases", "brand", "conversion"].filter((k) => seed[k] && !i[k]).map((k) => [k, seed[k]]));
        return changes && Object.keys(changes).length ? [i.id, changes] : null;
      })
      .filter(Boolean);
    const parts = [missing.length && `add ${missing.length} items`, details.length && `fill in local names and brands on ${details.length}`].filter(Boolean);
    const itemsBtn = button(parts.length ? `Grocery items: ${parts.join(", ")}` : "Grocery items are up to date");
    itemsBtn.disabled = !parts.length;
    const itemsStatus = el("p", "small");
    itemsBtn.addEventListener("click", () =>
      run(itemsBtn, itemsStatus, "Adding…", async () => {
        if (missing.length) await store.createItems(missing.map((i) => ({ ...i, toPurchase: false, packs: 1 })), items);
        if (details.length) await store.updateItems(Object.fromEntries(details));
        setTimeout(render, 800);
        return `✓ Done. Find them in 🛒 Groceries → Items.`;
      })
    );

    // Shop prices: only ones newer than what you have for that item at that shop.
    const when = (p) => new Date(`${p.date}T12:00:00`).getTime();
    const itemFor = (name) => byName.get(name.toLowerCase());
    const newest = new Map(latest.map((p) => [`${p.itemId}|${p.shop.trim().toLowerCase()}`, p.date]));
    const fresh = shopPrices.filter((p) => {
      const item = itemFor(p.item);
      return !item || !(newest.get(`${item.id}|${p.shop.toLowerCase()}`) >= when(p));
    });
    const shops = [...new Set(shopPrices.map((p) => p.shop))];
    const checked = shopPrices[0]?.date ? new Date(`${shopPrices[0].date}T12:00:00`).toLocaleDateString() : "";
    const pricesBtn = button(fresh.length ? `Add ${fresh.length} shop prices (${shops.join(", ")})` : "Shop prices are up to date");
    pricesBtn.disabled = !fresh.length || missing.length > 0;
    const pricesStatus = el("p", "small");
    pricesBtn.addEventListener("click", () =>
      run(pricesBtn, pricesStatus, "Adding prices…", async () => {
        const current = await store.loadItems();
        const find = (name) => current.find((i) => i.name.trim().toLowerCase() === name.toLowerCase());
        const records = fresh
          .map(({ item, date, ...p }) => {
            const target = find(item);
            return target && { ...p, itemId: target.id, item: target.name, date: when({ date }) };
          })
          .filter(Boolean);
        await store.addPrices(records);
        setTimeout(render, 800);
        return `✓ Added ${records.length} prices. See them in 🛒 Groceries → Prices.`;
      })
    );

    importBox.append(
      el("p", "muted small", `Starter grocery list: ${starterItems.length - missing.length} of ${starterItems.length} common items are already in your groceries (Lebanese pantry, spices, cleaning and personal care).`),
      itemsBtn,
      itemsStatus,
      el(
        "p",
        "muted small",
        `Shop prices checked ${checked}: ${shops.map((s) => `${shopPrices.filter((p) => p.shop === s).length} at ${s}`).join(", ")}, in dollars at ${LBP_RATE.toLocaleString()} LBP. Faddoul only shows prices in its phone app, so add those on the Prices tab as you shop.${missing.length ? " Add the grocery items first." : ""}`
      ),
      pricesBtn,
      pricesStatus
    );
  }
  locked.append(importBox);

  // Backup
  const backupBox = card(
    "3. Backup",
    "The free plan has no automatic backups. Download one now and then, and before big changes. A backup holds every recipe, the questions, your grocery items and all prices."
  );
  const backupStatus = el("p", "small");
  const exportBtn = button("⬇ Download backup", "primary");
  exportBtn.addEventListener("click", () =>
    run(exportBtn, backupStatus, "Preparing…", async () => {
      const data = await store.exportAll();
      downloadJson(`whattoeat-backup-${new Date().toISOString().slice(0, 10)}.json`, data);
      return `✓ Downloaded ${data.meals.length} recipes, ${data.items.length} items and ${data.prices.length} prices.`;
    })
  );
  const [restoreBtn, fileInput] = jsonPicker("⬆ Restore from backup", backupStatus, (data) => {
    if (data?.kind === "recipe") {
      backupStatus.className = "small pin-error";
      backupStatus.textContent = "That's a single recipe. Use 4. Import a recipe below.";
      return;
    }
    const counts = `${data.meals?.length || 0} recipes, ${data.items?.length || 0} items and ${data.prices?.length || 0} prices`;
    if (!confirm(`Restore ${counts} from ${data.exportedAt || "this file"}? Recipes, items and prices with the same id are overwritten; nothing else is deleted.`)) return;
    run(restoreBtn, backupStatus, "Restoring…", async () => {
      await store.restoreAll(data);
      setTimeout(render, 800);
      return `✓ Restored ${counts}.`;
    });
  }, "backupFile");
  const backupActions = el("div", "recipe-actions");
  backupActions.append(exportBtn, restoreBtn, fileInput);
  backupBox.append(backupActions, backupStatus);
  locked.append(backupBox);

  // Import one recipe (exported from a recipe page, here or in another recipe book)
  const recipeBox = card(
    "4. Import a recipe",
    "Pick a recipe's Excel file (⬇ Excel on any recipe page saves one; older .json exports work too). Its ingredients are linked to your grocery items by Item ID or name, and new names become items; prices aren't included."
  );
  const recipeStatus = el("p", "small");
  const preview = el("div");
  const [pickRecipe, recipeInput] = jsonPicker("⬆ Choose a recipe file", recipeStatus, (data) => {
    preview.innerHTML = "";
    recipeStatus.className = "small";
    recipeStatus.textContent = "";
    const { recipe, problems } = readRecipeFile(data, questions);
    if (problems.length) {
      recipeStatus.className = "small pin-error";
      recipeStatus.textContent = `Not imported: ${problems.slice(0, 5).join(" ")}${problems.length > 5 ? ` (+${problems.length - 5} more)` : ""}`;
      return;
    }
    const clash = meals.find((m) => m.id === slugify(recipe.name));
    const summary = `${recipe.emoji} ${recipe.name}: ${recipe.ingredients.length} ingredients, ${recipe.steps.length} steps${recipe.servings ? `, serves ${recipe.servings}` : ""}.`;
    preview.append(el("p", "", summary));
    if (clash) preview.append(el("p", "muted small", `You already have “${clash.name}”${hasOwnRecipe(clash) ? " (written)" : ""}. Replace it, or keep both?`));
    const actions = el("div", "recipe-actions");
    const go = (label, mode, kind) => {
      const b = button(label, kind);
      b.addEventListener("click", async () => {
        const buttons = [...actions.querySelectorAll("button")];
        buttons.forEach((x) => (x.disabled = true));
        recipeStatus.className = "small";
        recipeStatus.textContent = "Importing…";
        try {
          const r = await saveImportedRecipe(recipe, meals, mode);
          if (!meals.some((m) => m.id === r.id)) meals.push({ ...recipe, id: r.id, name: r.name });
          preview.innerHTML = "";
          const a = el("a", "", `${recipe.emoji} ${r.name}`);
          a.href = recipeUrl({ id: r.id });
          recipeStatus.replaceChildren(
            "✓ Imported ",
            a,
            `${r.newItems ? ` · ${r.newItems} new grocery item${r.newItems === 1 ? "" : "s"}` : ""}${r.dropped ? ` · ${r.dropped} linked recipe${r.dropped === 1 ? "" : "s"} not in this book, left out` : ""}.`
          );
        } catch (err) {
          console.error(err);
          recipeStatus.className = "small pin-error";
          recipeStatus.textContent = friendlyError(err);
          buttons.forEach((x) => (x.disabled = false));
        }
      });
      actions.append(b);
    };
    if (clash) {
      go(`Replace “${clash.name}”`, "replace", "primary");
      go("Keep both", "copy");
    } else {
      go("Import", "copy", "primary");
    }
    preview.append(actions);
  }, "recipeFile", {
    accept: ".xlsx,.json,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/json",
    // Excel exports, and the older .json ones.
    parse: async (file) =>
      /\.json$/i.test(file.name) ? readJson(file) : readRecipeWorkbook(await loadSheetJS(), await file.arrayBuffer(), questions)
  });
  pickRecipe.disabled = source !== "firestore";
  if (source !== "firestore") recipeBox.append(el("p", "muted small", "Import the starter menu first (2.)."));
  recipeBox.append(pickRecipe, recipeInput, preview, recipeStatus);
  locked.append(recipeBox);

  // Questions
  const qBox = card(
    "5. Wheel questions",
    "The questions as JSON, in the order they're asked. Each option filters on the question's field with one of value, values, min/max or any (see the README). Tag recipes with new fields in the recipe editor."
  );
  const area = el("textarea", "field code");
  area.rows = 24;
  area.spellcheck = false;
  area.value = JSON.stringify(questions, null, 2);
  area.setAttribute("aria-label", "Questions JSON");
  const saveQ = button("Save questions", "primary");
  const qStatus = el("p", "small");
  saveQ.addEventListener("click", () => {
    let parsed;
    try {
      parsed = JSON.parse(area.value);
    } catch (err) {
      qStatus.className = "small pin-error";
      qStatus.textContent = `Not saved: the JSON has a mistake (${err.message}).`;
      return;
    }
    const problems = validateQuestions(parsed);
    if (problems.length) {
      qStatus.className = "small pin-error";
      qStatus.textContent = `Not saved: ${problems.slice(0, 5).join(" ")}${problems.length > 5 ? ` (+${problems.length - 5} more)` : ""}`;
      return;
    }
    run(saveQ, qStatus, "Saving…", async () => {
      await store.saveQuestions(parsed, questions.map((q) => q.id));
      return "✓ Saved.";
    });
  });
  qBox.append(area, saveQ, qStatus);
  locked.append(qBox);

  // Repair + lock
  const toolsBox = card(
    "6. Maintenance",
    "Pages read the whole recipe book, and the latest price of each item at each shop, from two snapshot documents. If either ever looks out of date, rebuild them from the individual recipes and prices."
  );
  const rebuildBtn = button("Rebuild snapshots");
  const rebuildStatus = el("p", "small");
  rebuildBtn.addEventListener("click", () =>
    run(rebuildBtn, rebuildStatus, "Rebuilding…", async () => {
      const [r, latest] = await Promise.all([store.rebuildSnapshot(), store.rebuildPriceSummary()]);
      return `✓ Rebuilt with ${r.meals} recipes, ${r.questions} questions and ${latest} latest prices.`;
    })
  );
  const idsBtn = button("Give items readable ids");
  idsBtn.addEventListener("click", () => {
    if (!confirm("Give every grocery item its name as its id (\"chicken-breast\"), and update the recipes and prices that use it? Download a backup first.")) return;
    run(idsBtn, rebuildStatus, "Updating…", async () => {
      const r = await store.migrateItemIds();
      return r.items
        ? `✓ ${r.items} items now have readable ids (${r.recipes} recipes and ${r.prices} prices updated).`
        : "✓ Every item already has a readable id.";
    });
  });
  const lockBtn = button("🔒 Lock this device", "ghost");
  lockBtn.addEventListener("click", () => {
    lock();
    notify("Locked.");
    location.reload();
  });
  const toolsActions = el("div", "recipe-actions");
  toolsActions.append(rebuildBtn, idsBtn, lockBtn);
  toolsBox.append(toolsActions, rebuildStatus);
  locked.append(toolsBox);
}

render();
