// "Use it up": rank dishes by the ingredients you already have and list what's missing.
import {
  loadMenu,
  ingredientName,
  ingredientQty,
  ingredientOptions,
  ingredientMatch,
  isOptional,
  words,
  hasOwnRecipe,
  recipeUrl,
  searchUrl,
  el
} from "./menu.js";

// Treated as "in the cupboard" when the basics box is ticked.
const STAPLES = ["salt", "flaky salt", "black pepper", "olive oil", "vegetable oil", "oil", "water", "sugar"].map((s) =>
  words(s).join(" ")
);
const isStaple = (ing) => STAPLES.includes(words(ingredientName(ing)).join(" "));

const STORAGE_KEY = "wte-pantry";

const $ = (id) => document.getElementById(id);
const els = {
  form: $("addForm"),
  input: $("ingredient"),
  datalist: $("ingredientList"),
  haveList: $("haveList"),
  basics: $("basics"),
  maxMissing: $("maxMissing"),
  clearAll: $("clearAll"),
  summary: $("summary"),
  results: $("results")
};

const state = {
  meals: [],
  have: loadSaved(),
  basics: true,
  maxMissing: 3
};

// Your list is remembered in this browser only.
function loadSaved() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
  } catch {
    return [];
  }
}

function save() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state.have));
  } catch {
    // Storage blocked (private mode etc.): the list just isn't remembered.
  }
}

const key = (s) => words(s).join(" ");

function addItems(text) {
  text
    .split(",")
    .map((s) => s.trim())
    .filter((s) => key(s))
    .forEach((item) => {
      if (!state.have.some((h) => key(h) === key(item))) state.have.push(item);
    });
  save();
  render();
}

function removeItem(index) {
  state.have.splice(index, 1);
  save();
  render();
}

// For each ingredient of a dish (or any of its swaps): do you have it, probably have it
// (a loose match like "oil" for "Sesame oil"), is it a basic, optional, or missing?
function analyse(meal) {
  const rows = (meal.ingredients || []).map((ing) => {
    let by = null;
    let level = 0;
    state.have.forEach((h) => {
      const m = ingredientMatch(h, ing);
      if (m > level) [by, level] = [h, m];
    });
    let status = "miss";
    if (level === 2) status = "have";
    else if (level === 1) status = "maybe";
    else if (state.basics && isStaple(ing)) status = "basic";
    else if (isOptional(ing)) status = "optional";
    return { ing, status, by };
  });
  return {
    meal,
    rows,
    used: [...new Set(rows.filter((r) => r.by).map((r) => r.by))],
    missing: rows.filter((r) => r.status === "miss")
  };
}

function renderHave() {
  els.haveList.innerHTML = "";
  state.have.forEach((item, i) => {
    const li = el("li", "chip have", item);
    const remove = el("button", "", "×");
    remove.type = "button";
    remove.setAttribute("aria-label", `Remove ${item}`);
    remove.addEventListener("click", () => removeItem(i));
    li.appendChild(remove);
    els.haveList.appendChild(li);
  });
}

function resultCard({ meal, rows, used, missing }) {
  const card = el("article", "card pantry-result");

  const head = el("div", "pr-head");
  head.append(el("span", "pr-emoji", meal.emoji));
  const titles = el("div");
  titles.append(el("h3", "", meal.name));
  titles.append(
    missing.length
      ? el("p", "badge", `Missing ${missing.length}`)
      : el("p", "badge ready", "✓ Ready to cook")
  );
  head.append(titles);
  card.append(head);

  card.append(el("p", "muted small", `Uses your ${used.join(", ")}`));

  const chips = el("ul", "chips");
  rows.forEach(({ ing, status, by }) => {
    const names = ingredientOptions(ing).map((o) => o.item).join(" / ");
    const label = [ingredientQty(ing), names].filter(Boolean).join(" ");
    const cls = { have: "have", basic: "have", maybe: "maybe", miss: "miss" }[status] || "";
    const mark = { have: "✓ ", basic: "✓ ", maybe: "≈ ", miss: "✗ " }[status] || "";
    const chip = el("li", `chip ${cls}`, mark + label);
    if (status === "optional") chip.title = "Optional";
    if (status === "maybe") chip.title = `You said "${by}". Check it's the right one.`;
    chips.append(chip);
  });
  card.append(chips);

  // A recipe without steps is one you don't have yet: search for it instead.
  const actions = el("div", "pr-actions");
  if (hasOwnRecipe(meal)) {
    const link = el("a", "btn small", "📖 My own recipe");
    link.href = recipeUrl(meal);
    actions.append(link);
  } else {
    const search = el("a", "btn small", "Find a recipe ↗");
    search.href = searchUrl(meal);
    search.target = "_blank";
    search.rel = "noopener";
    const details = el("a", "btn ghost small", "Details");
    details.href = recipeUrl(meal);
    actions.append(search, details);
  }
  card.append(actions);
  return card;
}

function renderResults() {
  els.results.innerHTML = "";
  if (!state.have.length) {
    els.summary.textContent = "Add a few ingredients to see what you can make.";
    return;
  }

  const results = state.meals
    .map(analyse)
    .filter((r) => r.used.length && (state.maxMissing < 0 || r.missing.length <= state.maxMissing))
    .sort(
      (a, b) =>
        a.missing.length - b.missing.length || b.used.length - a.used.length || a.meal.name.localeCompare(b.meal.name)
    );

  const ready = results.filter((r) => !r.missing.length).length;
  els.summary.textContent = results.length
    ? `${results.length} dish${results.length === 1 ? "" : "es"} use your ingredients · ${ready} ready to cook`
    : "Nothing uses those ingredients within that limit. Try allowing more missing items.";
  results.forEach((r) => els.results.append(resultCard(r)));
}

function render() {
  renderHave();
  renderResults();
}

// Suggestions: every ingredient name on the menu, once each.
function fillSuggestions() {
  const seen = new Map();
  state.meals.forEach((m) =>
    (m.ingredients || []).forEach((ing) =>
      ingredientOptions(ing).forEach((o) => {
        const name = o.item.replace(/\s*\(.*?\)/g, "");
        if (key(name) && !seen.has(key(name))) seen.set(key(name), name);
      })
    )
  );
  els.datalist.innerHTML = "";
  [...seen.values()]
    .sort((a, b) => a.localeCompare(b))
    .forEach((name) => {
      const opt = document.createElement("option");
      opt.value = name;
      els.datalist.append(opt);
    });
}

els.form.addEventListener("submit", (e) => {
  e.preventDefault();
  addItems(els.input.value);
  els.input.value = "";
  els.input.focus();
});

els.basics.addEventListener("change", () => {
  state.basics = els.basics.checked;
  renderResults();
});

els.maxMissing.addEventListener("change", () => {
  state.maxMissing = Number(els.maxMissing.value);
  renderResults();
});

els.clearAll.addEventListener("click", () => {
  state.have = [];
  save();
  render();
});

const menu = await loadMenu();
state.meals = menu.meals;
fillSuggestions();
render();
