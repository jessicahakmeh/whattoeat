// Firestore reads and writes.
//
// The PIN is checked in the browser only (see vault.js); the database itself is
// open to the app (see firestore.rules).
//
//   settings/pin      { hash } = SHA-256 of "whattoeat:" + PIN, checked by the PIN screen
//   snapshots/menu    every recipe + the questions in one document, so a page
//                     visit costs 1 read instead of ~200 (kept in sync on every save)
//   meals/{id}        recipes, one per document (the source the snapshot is built from)
//   questions/{id}    wheel questions, ordered by `order`
//   items/{id}        grocery + household items; the id is the name as a slug ("chicken-breast",
//                     "-2" if taken) and stays the same when the item is renamed
//   prices/{priceId}  price records: itemId, item, price, shop, qty, date (the full history)
//   snapshots/prices  { latest: { "<itemId>|<shop>": record } }: the latest price of each
//                     item at each shop, so lists and costs cost 1 read instead of 1 per price
//   plans/{YYYY-MM}   { days: { "YYYY-MM-DD": { breakfast | lunch | dinner: { id, servings } } } }:
//                     the meal plan, one document per month (a week costs 1-2 reads)
import { db } from "./firebase.js";
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  deleteField,
  writeBatch,
  runTransaction,
  query,
  where
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { slugify, itemSlug } from "./menu.js";

// Firestore rejects `undefined` values; a JSON round trip drops them.
const clean = (data) => JSON.parse(JSON.stringify(data));

// A single document holds at most 1 MiB.
const SNAPSHOT_LIMIT = 900_000;
const snapshotRef = () => doc(db, "snapshots", "menu");
const pinRef = () => doc(db, "settings", "pin");

export class ConflictError extends Error {
  constructor() {
    super("Someone else saved this recipe after you opened it.");
    this.code = "conflict";
  }
}

// ---------- PIN ----------

// The stored PIN hash, or null if no PIN has been set yet.
export async function loadPinHash() {
  const snap = await getDoc(pinRef());
  return snap.exists() ? snap.data().hash : null;
}

export const savePinHash = (hash) => setDoc(pinRef(), { hash });

// ---------- Menu snapshot ----------

function parseSnapshot(snap) {
  if (!snap.exists()) return null;
  const { meals, questions } = JSON.parse(snap.data().data);
  return { meals: Object.entries(meals).map(([id, m]) => ({ ...m, id })), questions };
}

function snapshotPayload(mealsById, questions) {
  const data = JSON.stringify({ meals: mealsById, questions });
  if (data.length > SNAPSHOT_LIMIT) throw new Error("The recipe book is too big for one snapshot (about 1 MB).");
  return { data, version: Date.now() };
}

const asMap = (meals) => Object.fromEntries(meals.map(({ id, ...m }) => [id, m]));
const stripQuestion = ({ order, deleted, ...q }) => q;

export async function loadSnapshot() {
  return parseSnapshot(await getDoc(snapshotRef()));
}

// ---------- Recipes and questions ----------

export async function saveMeal(meal, { expectedUpdatedAt, force = false } = {}) {
  const { id, updatedAt, ...data } = meal;
  const mealId = id || slugify(meal.name);
  const mealRef = doc(db, "meals", mealId);
  const stamp = Date.now();

  await runTransaction(db, async (tx) => {
    const [snapDoc, current] = await Promise.all([tx.get(snapshotRef()), tx.get(mealRef)]);
    if (!snapDoc.exists()) throw new Error("Import the starter menu in Settings before adding recipes.");
    if (!force && current.exists() && !current.data().deleted && (current.data().updatedAt ?? null) !== (expectedUpdatedAt ?? null)) {
      throw new ConflictError();
    }
    const snapshot = parseSnapshot(snapDoc);
    const meals = asMap(snapshot.meals);
    meals[mealId] = clean({ ...data, updatedAt: stamp });
    tx.set(mealRef, clean({ ...data, updatedAt: stamp }));
    tx.set(snapshotRef(), snapshotPayload(meals, snapshot.questions));
  });
  return mealId;
}

// Recipes are hidden (`deleted: true`) rather than erased, so a mistake can be undone in the console.
export async function deleteMeal(id) {
  await runTransaction(db, async (tx) => {
    const snapshot = parseSnapshot(await tx.get(snapshotRef()));
    const meals = asMap(snapshot?.meals || []);
    delete meals[id];
    tx.set(doc(db, "meals", id), { deleted: true, updatedAt: Date.now() }, { merge: true });
    tx.set(snapshotRef(), snapshotPayload(meals, snapshot?.questions || []));
  });
}

// Replaces the whole question list and marks any left out as deleted.
export async function saveQuestions(questions, previousIds = []) {
  const keep = new Set(questions.map((q) => q.id));
  await runTransaction(db, async (tx) => {
    const snapshot = parseSnapshot(await tx.get(snapshotRef()));
    if (!snapshot) throw new Error("Import the starter menu in Settings first.");
    questions.forEach((q, order) => {
      const { id, ...data } = q;
      tx.set(doc(db, "questions", id), clean({ ...data, order }));
    });
    previousIds
      .filter((id) => !keep.has(id))
      .forEach((id) => tx.set(doc(db, "questions", id), { deleted: true }, { merge: true }));
    tx.set(snapshotRef(), snapshotPayload(asMap(snapshot.meals), clean(questions)));
  });
}

// Firestore batches hold at most 500 writes.
async function commitInChunks(writes, chunkSize = 400) {
  for (let i = 0; i < writes.length; i += chunkSize) {
    const batch = writeBatch(db);
    writes.slice(i, i + chunkSize).forEach((write) => write(batch));
    await batch.commit();
  }
}

// Writes recipes and questions (starter menu import, or a restore from backup).
// Recipes with the same id are overwritten; other recipes are kept, except the ids in
// `retire` (starter recipes taken out of the menu), which are marked deleted.
export async function importMenu(meals, questions, retire = []) {
  const stamp = Date.now();
  const incoming = meals.map((m) => ({ ...m, id: m.id || slugify(m.name), updatedAt: m.updatedAt || stamp }));
  const existing = await loadSnapshot();
  const previousQuestions = existing ? (await getDocs(collection(db, "questions"))).docs.map((d) => d.id) : [];
  const keepQ = new Set(questions.map((q) => q.id));
  const incomingIds = new Set(incoming.map((m) => m.id));
  const retiring = retire.filter((id) => !incomingIds.has(id));

  await commitInChunks([
    ...incoming.map(({ id, ...m }) => (batch) => batch.set(doc(db, "meals", id), clean(m))),
    ...retiring.map((id) => (batch) => batch.set(doc(db, "meals", id), { deleted: true, updatedAt: stamp }, { merge: true })),
    ...questions.map(({ id, ...q }, order) => (batch) => batch.set(doc(db, "questions", id), clean({ ...q, order }))),
    ...previousQuestions
      .filter((id) => !keepQ.has(id))
      .map((id) => (batch) => batch.set(doc(db, "questions", id), { deleted: true }, { merge: true }))
  ]);

  const merged = { ...asMap(existing?.meals || []), ...asMap(incoming) };
  retiring.forEach((id) => delete merged[id]);
  await setDoc(snapshotRef(), snapshotPayload(clean(merged), clean(questions)));
}

// Adds fields to existing recipes without touching the rest (labels for written recipes):
// `patches` is { id: { labels } }. The snapshot is updated in the same transaction.
export async function patchMeals(patches) {
  const ids = Object.keys(patches);
  if (!ids.length) return 0;
  await runTransaction(db, async (tx) => {
    const snapshot = parseSnapshot(await tx.get(snapshotRef()));
    if (!snapshot) throw new Error("Import the starter menu in Settings first.");
    const meals = asMap(snapshot.meals);
    ids.forEach((id) => {
      if (!meals[id]) return;
      meals[id] = { ...meals[id], ...clean(patches[id]) };
      tx.set(doc(db, "meals", id), clean(patches[id]), { merge: true });
    });
    tx.set(snapshotRef(), snapshotPayload(meals, snapshot.questions));
  });
  return ids.length;
}

// Ids of recipes deleted in the app, so a starter-menu import doesn't bring them back.
export async function deletedMealIds() {
  const snap = await getDocs(query(collection(db, "meals"), where("deleted", "==", true)));
  return new Set(snap.docs.map((d) => d.id));
}

// Rebuilds the snapshot from the meals and questions collections (repair tool).
export async function rebuildSnapshot() {
  const [mealDocs, questionDocs] = await Promise.all([getDocs(collection(db, "meals")), getDocs(collection(db, "questions"))]);
  const meals = Object.fromEntries(mealDocs.docs.filter((d) => !d.data().deleted).map((d) => [d.id, d.data()]));
  const questions = questionDocs.docs
    .map((d) => ({ ...d.data(), id: d.id }))
    .filter((q) => !q.deleted)
    .sort((a, b) => a.order - b.order)
    .map(stripQuestion);
  await setDoc(snapshotRef(), snapshotPayload(meals, questions));
  return { meals: Object.keys(meals).length, questions: questions.length };
}

// ---------- Grocery items and prices ----------

export async function loadItems() {
  const snap = await getDocs(collection(db, "items"));
  return snap.docs.map((d) => ({ ...d.data(), id: d.id })).sort((a, b) => a.name.localeCompare(b.name));
}

// The id for a new item named `name`: its slug, or slug-2, slug-3… if one of `taken` has it.
function newItemId(name, taken) {
  const base = itemSlug(name) || "item";
  let id = base;
  for (let n = 2; taken.has(id); n++) id = `${base}-${n}`;
  return id;
}

// New items get their id straight away (even offline); the write syncs when it can.
// `known` is the item list the page has, so a name already used gets "-2".
export function createItem(item, known = []) {
  const ref = doc(db, "items", newItemId(item.name, new Set(known.map((i) => i.id))));
  const done = setDoc(ref, clean(item));
  return { id: ref.id, done };
}

// Many new items at once (starter items); returns their ids in the same order.
export async function createItems(items, known = []) {
  const taken = new Set(known.map((i) => i.id));
  const ids = items.map((item) => {
    const id = newItemId(item.name, taken);
    taken.add(id);
    return id;
  });
  await commitInChunks(items.map((item, i) => (batch) => batch.set(doc(db, "items", ids[i]), clean(item))));
  return ids;
}

const isSlug = (id) => /^[a-z0-9]+(-[a-z0-9]+)*$/.test(id);
const sameName = (a, b) => itemSlug(a.name) === itemSlug(b.name);

// Gives every item whose id isn't a slug (made before ids were names, or restored from an
// older backup) its name as its id, and moves the references in recipes and prices with it.
// An item whose slug is already used by one with the same name is merged into it. Safe to
// run again; old item documents are deleted last, so a run that stops halfway can be redone.
export async function migrateItemIds() {
  const [items, prices, mealDocs] = await Promise.all([loadItems(), loadPrices(), getDocs(collection(db, "meals"))]);
  const byId = new Map(items.map((i) => [i.id, i]));
  const taken = new Set(items.filter((i) => isSlug(i.id)).map((i) => i.id));
  const claimed = new Set();
  const moves = new Map();
  items
    .filter((i) => !isSlug(i.id))
    .forEach((item) => {
      const base = itemSlug(item.name) || "item";
      let id = base;
      const free = (x) => !taken.has(x) || (!claimed.has(x) && byId.has(x) && sameName(byId.get(x), item));
      for (let n = 2; !free(id); n++) id = `${base}-${n}`;
      taken.add(id);
      claimed.add(id);
      moves.set(item.id, id);
    });
  if (!moves.size) return { items: 0, prices: 0, recipes: 0 };

  const moved = (option) => (option?.itemId && moves.has(option.itemId) ? { ...option, itemId: moves.get(option.itemId) } : option);
  const touches = (option) => Boolean(option?.itemId && moves.has(option.itemId));
  const mealWrites = mealDocs.docs
    .filter((d) => (d.data().ingredients || []).some((ing) => touches(ing) || (ing.swaps || []).some(touches)))
    .map((d) => {
      const ingredients = d.data().ingredients.map((ing) => ({ ...moved(ing), ...(ing.swaps ? { swaps: ing.swaps.map(moved) } : {}) }));
      return (batch) => batch.update(d.ref, clean({ ingredients }));
    });
  const priceWrites = prices
    .filter((p) => moves.has(p.itemId))
    .map((p) => (batch) => batch.update(doc(db, "prices", p.priceId), { itemId: moves.get(p.itemId) }));

  await commitInChunks([
    ...[...moves].map(([from, to]) => {
      const { id, ...data } = byId.get(from);
      return (batch) => batch.set(doc(db, "items", to), clean(data));
    }),
    ...priceWrites,
    ...mealWrites
  ]);
  await Promise.all([rebuildSnapshot(), rebuildPriceSummary()]);
  await commitInChunks([...moves.keys()].map((from) => (batch) => batch.delete(doc(db, "items", from))));
  return { items: moves.size, prices: priceWrites.length, recipes: mealWrites.length };
}

export const updateItem = (id, changes) => updateDoc(doc(db, "items", id), clean(changes));

// Several item changes as one write (all or nothing), e.g. "Done shopping".
export function updateItems(changesById) {
  const batch = writeBatch(db);
  Object.entries(changesById).forEach(([id, changes]) => batch.update(doc(db, "items", id), clean(changes)));
  return batch.commit();
}

export const deleteItem = (id) => deleteDoc(doc(db, "items", id));

// The full price history (1 read per price): only the Prices tab and backups need it.
export async function loadPrices() {
  const snap = await getDocs(collection(db, "prices"));
  return snap.docs.map((d) => ({ ...d.data(), priceId: d.id })).sort((a, b) => b.date - a.date);
}

const priceSummaryRef = () => doc(db, "snapshots", "prices");
// Same grouping as cheapestPrices() in cost.js; encoded so any shop name is a safe map key.
export const shopKey = (p) => `${p.itemId}|${encodeURIComponent(p.shop.trim().toLowerCase()).replace(/\./g, "%2E")}`;

function summarise(prices) {
  const latest = {};
  prices.forEach((p) => {
    const k = shopKey(p);
    if (!latest[k] || p.date > latest[k].date) latest[k] = p;
  });
  return latest;
}

// Writes the summary from the full history (first use, after a restore, or as a repair).
export async function rebuildPriceSummary() {
  const latest = summarise(await loadPrices());
  await setDoc(priceSummaryRef(), clean({ latest }));
  return Object.keys(latest).length;
}

// The latest price of each item at each shop (1 read). Built from the history the first time.
export async function loadLatestPrices() {
  let snap = await getDoc(priceSummaryRef());
  if (!snap.exists()) {
    await rebuildPriceSummary();
    snap = await getDoc(priceSummaryRef());
  }
  return Object.values(snap.data().latest || {});
}

// Saves a price and, unless an even newer one is already there for that item and shop
// (`latest`, a list like the one loadLatestPrices returns), puts it in the summary.
// One batch, so it also works offline.
export function addPrice(price, latest = []) {
  const ref = doc(collection(db, "prices"));
  const record = clean({ qty: "", ...price, date: price.date || Date.now() });
  const entry = { ...record, priceId: ref.id };
  const current = latest.find((p) => shopKey(p) === shopKey(entry));
  const newest = !current || entry.date >= current.date;
  const batch = writeBatch(db);
  batch.set(ref, record);
  if (newest) batch.set(priceSummaryRef(), { latest: { [shopKey(entry)]: entry } }, { merge: true });
  return { entry, newest, done: batch.commit() };
}

// Saves many prices at once (the starter shop prices) and puts each in the summary.
// `records` already have itemId; callers leave out ones older than what's there.
export async function addPrices(records) {
  const latest = {};
  const writes = records.map((r) => {
    const ref = doc(collection(db, "prices"));
    const record = clean({ qty: "", ...r });
    const k = shopKey(record);
    if (!latest[k] || record.date >= latest[k].date) latest[k] = { ...record, priceId: ref.id };
    return (batch) => batch.set(ref, record);
  });
  await commitInChunks(writes);
  if (Object.keys(latest).length) await setDoc(priceSummaryRef(), clean({ latest }), { merge: true });
  return Object.values(latest);
}

// Deletes a price; if it was the summary's latest for its item and shop, the next newest
// in `history` (the remaining full history) takes its place.
export function deletePrice(price, history = []) {
  const k = shopKey(price);
  const next = history.filter((p) => p.priceId !== price.priceId && shopKey(p) === k).sort((a, b) => b.date - a.date)[0];
  const batch = writeBatch(db);
  batch.delete(doc(db, "prices", price.priceId));
  batch.set(priceSummaryRef(), { latest: { [k]: next ? clean(next) : deleteField() } }, { merge: true });
  return batch.commit();
}

// ---------- Meal plan ----------

const planRef = (month) => doc(db, "plans", month);

// The planned days of the given months ("2026-10"), merged into one { date: { slot: entry } }.
export async function loadPlan(months) {
  const snaps = await Promise.all([...new Set(months)].map((m) => getDoc(planRef(m))));
  return Object.assign({}, ...snaps.map((s) => (s.exists() ? s.data().days || {} : {})));
}

// Puts a recipe in one slot of a day ({ id, servings }), or empties it (null). Each slot is
// its own field, so two phones planning at once don't overwrite each other; works offline.
export function setPlanSlot(date, slot, entry) {
  return setDoc(planRef(date.slice(0, 7)), { days: { [date]: { [slot]: entry ? clean(entry) : deleteField() } } }, { merge: true });
}

// ---------- Backup ----------

export async function exportAll() {
  const [snapshot, items, prices, plans] = await Promise.all([
    loadSnapshot(),
    loadItems(),
    loadPrices(),
    getDocs(collection(db, "plans"))
  ]);
  return {
    app: "whattoeat",
    version: 2,
    exportedAt: new Date().toISOString(),
    meals: snapshot?.meals || [],
    questions: snapshot?.questions || [],
    items,
    prices,
    plans: Object.fromEntries(plans.docs.map((d) => [d.id, d.data().days || {}]))
  };
}

// Restores a backup. Same ids are overwritten; nothing else is deleted. Items from an
// older backup (random ids) are then given name ids, merging into the item of the same name.
export async function restoreAll(backup) {
  if (backup?.app !== "whattoeat" || !Array.isArray(backup.meals)) throw new Error("That isn't a What To Eat backup file.");
  if (backup.meals.length && backup.questions?.length) await importMenu(backup.meals, backup.questions);
  await commitInChunks([
    ...(backup.items || []).map(({ id, ...item }) => (batch) => batch.set(doc(db, "items", id), clean(item))),
    ...(backup.prices || []).map(({ priceId, ...p }) => (batch) => batch.set(doc(db, "prices", priceId), clean(p))),
    ...Object.entries(backup.plans || {}).map(([month, days]) => (batch) => batch.set(planRef(month), clean({ days })))
  ]);
  const { items } = await migrateItemIds();
  if (backup.prices?.length && !items) await rebuildPriceSummary();
}
