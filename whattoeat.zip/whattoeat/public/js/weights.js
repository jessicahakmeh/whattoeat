// Kitchen weights: how much a cup, spoon or piece of an ingredient weighs, so amounts written
// as "1 tbsp tomato paste" or "2 onions" can be priced against packs sold by weight.
//
// Values are typical weights from USDA FoodData Central portion data and standard baking
// charts. A US cup is 236.6 ml (16 tbsp, 48 tsp); the app reads "1 cup" as 240 ml, which
// is within 1.5%. Names are matched longest first, so "tomato paste" wins over "tomato"
// and "brown sugar" over "sugar". Words are compared in their singular form.
//
// Add your own: a grocery item's "Conversion" field ("1 cup = 200g", "1 pc = 150g") beats
// anything here.

// Grams per US cup. Spoons follow from it: 1 tbsp = cup / 16, 1 tsp = cup / 48.
export const GRAMS_PER_CUP = {
  // Flours, starches, crumbs
  flour: 125, "all purpose flour": 125, "plain flour": 125, "bread flour": 127, "whole wheat flour": 120,
  "self raising flour": 125, semolina: 167, cornflour: 128, cornstarch: 128, "corn starch": 128, "potato starch": 160,
  "rice flour": 158, "tempura flour": 120, breadcrumb: 108, panko: 50, cornmeal: 157, "baking powder": 220,
  "baking soda": 220, "bicarbonate of soda": 220, yeast: 150, "instant yeast": 150, cocoa: 86, "cocoa powder": 86,
  "milk powder": 128, "powdered milk": 128,

  // Sugars and syrups
  sugar: 200, "white sugar": 200, "caster sugar": 225, "brown sugar": 213, "icing sugar": 120, "powdered sugar": 120,
  honey: 340, "maple syrup": 315, syrup: 330, molasse: 337, "pomegranate molasse": 320, "date syrup": 330,
  "grape molasse": 330, jam: 320, nutella: 300, "chocolate spread": 300, "chocolate chip": 170,

  // Fats and oils
  oil: 218, "olive oil": 216, "extra virgin olive oil": 216, "sunflower oil": 218, "vegetable oil": 218,
  "sesame oil": 218, "corn oil": 218, "coconut oil": 218, "truffle oil": 216, "chili oil": 218, ghee: 218,
  butter: 227, "vegan butter": 227, margarine: 227, tahini: 240, "sesame paste": 240, "peanut butter": 258,

  // Dairy
  milk: 245, buttermilk: 245, cream: 238, "cooking cream": 238, "heavy cream": 238, "whipping cream": 238,
  "sour cream": 230, yogurt: 245, yoghurt: 245, laban: 245, "greek yogurt": 285, labneh: 270,
  "cream cheese": 232, ricotta: 246, "cottage cheese": 226, mascarpone: 240,
  parmesan: 100, pecorino: 100, cheddar: 113, mozzarella: 112, cheese: 113, gruyere: 108, feta: 150,
  halloumi: 150, akkawi: 150, shanklish: 150, "goat cheese": 130, "blue cheese": 135,

  // Grains, pasta, pulses (dry)
  rice: 185, "white rice": 185, "basmati rice": 185, "egyptian rice": 200, "short grain rice": 200,
  "arborio rice": 200, "risotto rice": 200, "paella rice": 200, "sushi rice": 200, "brown rice": 190,
  "cooked rice": 160, bulgur: 140, burghul: 140, "fine bulgur": 160, "fine burghul": 160, "coarse bulgur": 150,
  freekeh: 160, couscous: 173, moughrabieh: 170, moghrabieh: 170, quinoa: 170, oat: 90, "rolled oat": 90,
  granola: 120, lentil: 192, "red lentil": 192, "brown lentil": 192, "cooked lentil": 198, "split pea": 197,
  chickpea: 164, "dried chickpea": 200, "soaked chickpea": 165, bean: 180, "kidney bean": 180, "black bean": 172,
  "white bean": 180, "cannellini bean": 180, "fava bean": 170, "dried fava bean": 190, edamame: 155,
  vermicelli: 100, "small pasta": 170, orzo: 170, macaroni: 105, pasta: 100, penne: 100, noodle: 80,

  // Nuts and seeds
  nut: 140, almond: 143, "sliced almond": 92, "flaked almond": 92, walnut: 117, "pine nut": 135, pistachio: 123,
  peanut: 146, cashew: 137, hazelnut: 135, "sesame seed": 144, sesame: 144, "nigella seed": 140,
  "pumpkin seed": 129, "sunflower seed": 140, "chia seed": 170, raisin: 145, date: 147, apricot: 130,
  "dried apricot": 130, "desiccated coconut": 85, "shredded coconut": 85,

  // Ground spices and dried herbs (a teaspoon weighs cup / 48)
  salt: 292, "table salt": 292, "fine salt": 292, "sea salt": 240, "coarse salt": 240, "kosher salt": 240,
  "flaky salt": 120, "black pepper": 110, pepper: 110, "white pepper": 115, cumin: 96, "cumin seed": 100,
  paprika: 110, "smoked paprika": 110, cinnamon: 125, turmeric: 144, "seven spice": 91, allspice: 91,
  baharat: 96, sumac: 120, zaatar: 96, "za atar": 96, "dried mint": 24, "dried oregano": 48, oregano: 48,
  "dried thyme": 48, "dried basil": 34, "herbes de provence": 40, "bay leaf": 10, "chili flake": 86,
  "red pepper flake": 86, "aleppo pepper": 90, "chili powder": 130, cayenne: 86, "garlic powder": 149,
  "onion powder": 115, ginger: 96, "ground ginger": 86, "curry powder": 96, "garam masala": 96,
  "ras el hanout": 96, "shawarma spice": 96, "kabsa spice": 96, "mandi spice": 96, "biryani spice": 96,
  "cajun spice": 96, "fajita spice": 96, "tikka spice": 96, berbere: 96, coriander: 30, "ground coriander": 86,
  "coriander seed": 86, cardamom: 96, nutmeg: 106, clove: 101, "fennel seed": 96, caraway: 101,
  "sichuan pepper": 90, saffron: 30, "nutritional yeast": 60, spice: 96, "spice mix": 96, "stock cube": 170,
  "stock powder": 170, "vanilla extract": 202, vanilla: 202,

  // Sauces, pastes and condiments
  "tomato paste": 262, "tomato puree": 250, "tomato passata": 245, passata: 245, "tomato sauce": 245,
  "chopped tomato": 240, "crushed tomato": 245, ketchup: 272, mayonnaise: 220, mayo: 220, aioli: 220,
  mustard: 250, "dijon mustard": 250, "honey mustard": 260, "soy sauce": 255, "fish sauce": 288,
  "oyster sauce": 288, hoisin: 290, "bbq sauce": 290, "hot sauce": 240, sriracha: 270, "chili crisp": 220,
  "sweet chili sauce": 300, pesto: 256, harissa: 260, "curry paste": 250, "green curry paste": 250,
  "miso paste": 275, gochujang: 300, "garlic paste": 270, toum: 230, hummus: 246, tzatziki: 240,
  salsa: 260, "salsa verde": 240, "tartare sauce": 230, "caesar dressing": 240, tamarind: 290,
  "mango chutney": 320, "peanut sauce": 260, "enchilada sauce": 245, vinegar: 238, "white vinegar": 238,
  "rice vinegar": 238, "red wine vinegar": 238, "sherry vinegar": 238, balsamic: 255, "lemon juice": 244,
  "lime juice": 244, juice: 248, "orange juice": 248, "coconut milk": 240, "coconut cream": 240,
  stock: 240, broth: 240, "veg stock": 240, water: 236, wine: 235, "white wine": 235, "red wine": 235,
  beer: 236, mirin: 290, "rose water": 236, "orange blossom water": 236, "pickle juice": 240,

  // Fresh herbs and vegetables, chopped
  parsley: 60, mint: 40, "fresh mint": 40, dill: 30, basil: 40, "thai basil": 40, chive: 48, rosemary: 40,
  thyme: 40, sage: 30, "spring onion": 100, onion: 160, "red onion": 160, shallot: 160, garlic: 136,
  tomato: 180, "cherry tomato": 150, cucumber: 133, carrot: 128, "grated carrot": 110, "bell pepper": 150,
  "green pepper": 150, "red pepper": 150, chili: 95, jalapeno: 90, mushroom: 70, spinach: 30, rocket: 20,
  lettuce: 47, cabbage: 70, "red cabbage": 89, kale: 67, celery: 101, courgette: 124, zucchini: 124,
  kousa: 124, aubergine: 82, eggplant: 82, potato: 150, "sweet potato": 133, pumpkin: 116,
  "butternut squash": 140, broccoli: 91, cauliflower: 107, "green bean": 100, pea: 145, "frozen pea": 134,
  corn: 154, sweetcorn: 154, "sweet corn": 154, okra: 100, radish: 116, beetroot: 136, leek: 89,
  olive: 135, "green olive": 135, pickle: 143, gherkin: 143, caper: 137, "sun dried tomato": 55,
  "roasted pepper": 150, "pomegranate seed": 174, berry: 150, grape: 151, mango: 165, apple: 125,
  banana: 225, avocado: 150, "vine leaf": 60, "bean sprout": 104, "mloukhieh leaf": 40, "swiss chard": 36,
  "dandelion green": 55,

  // Meat and fish
  "minced beef": 225, "lean minced beef": 225, "minced lamb": 225, "lamb mince": 225, "minced pork": 225,
  "chicken mince": 225, "turkey mince": 225, mince: 225, "cooked chicken": 140, chicken: 140, tuna: 154,
  "canned tuna": 154, "tinned tuna": 154, "crab meat": 135, "lobster meat": 145, prawn: 145, shrimp: 145,
  bacon: 140, "bacon lardon": 140, chorizo: 130, awarma: 225, "sausage meat": 225
};

// Grams per piece ("2 onions", "1 lemon"). Weights are for a medium one, as bought.
export const GRAMS_PER_PIECE = {
  egg: 60, "egg white": 33, "egg yolk": 17, tomato: 150, "ripe tomato": 150, "cherry tomato": 15,
  onion: 150, "red onion": 150, "pearl onion": 15, shallot: 40, "spring onion": 15, garlic: 50,
  potato: 200, "baby potato": 40, "new potato": 60, "baking potato": 300, "sweet potato": 200,
  lemon: 100, lime: 65, orange: 180, "dried lime": 8, apple: 180, banana: 120, pear: 180, peach: 150,
  apricot: 40, plum: 65, kiwi: 75, mango: 300, pomegranate: 300, avocado: 200, fig: 50, date: 8,
  cucumber: 100, carrot: 70, courgette: 150, zucchini: 200, kousa: 120, aubergine: 300, eggplant: 300,
  "baby aubergine": 80, "bell pepper": 150, pepper: 150, "green pepper": 150, "red pepper": 150,
  capsicum: 150, chili: 15, chilli: 15, jalapeno: 15, "dried chilli": 1, mushroom: 20,
  "portobello mushroom": 80, lettuce: 400, romaine: 500, "romaine lettuce": 500, "little gem lettuce": 150,
  iceberg: 700, cabbage: 1000, "red cabbage": 900, cauliflower: 800, broccoli: 400, "pak choi": 150,
  beetroot: 150, radish: 10, turnip: 120, daikon: 400, artichoke: 200, corn: 250, "corn on the cob": 250,
  okra: 10, olive: 4, celery: 40, leek: 90, fennel: 230, pumpkin: 3000, "butternut squash": 1200,
  watermelon: 4000, cantaloupe: 1200, melon: 1200, lemongrass: 20, "lime leaf": 0.3, "bay leaf": 0.2,
  "chicken breast": 200, "chicken thigh": 120, "chicken leg": 250, "chicken wing": 90, "whole chicken": 1300,
  "chicken liver": 30, "lamb chop": 80, "pork chop": 200, "ribeye steak": 300, steak: 250, sirloin: 250,
  "skirt steak": 250, "cod fillet": 150, "salmon fillet": 150, "white fish fillet": 140, "sea bass": 400,
  "tuna steak": 170, sardine: 40, whitebait: 5, prawn: 15, shrimp: 15, mussel: 15, clam: 10, squid: 150,
  calamari: 150, sausage: 60, "makanek sausage": 15, sujuk: 40, "fish finger": 28, "veggie patty": 100,
  falafel: 17, tortilla: 45, "corn tortilla": 26, tostada: 15, pita: 80, "pita bread": 80,
  "lebanese bread": 110, "baladi bread": 110, "markouk bread": 60, "taboon bread": 150, flatbread: 90,
  bread: 80, baguette: 250, bun: 60, "brioche bun": 60, "brioche roll": 50, "hoagie roll": 90, bagel: 100,
  croissant: 60, "pizza dough": 250, "lasagna sheet": 20, "rice paper": 9, nori: 3, "filo pastry": 15,
  "puff pastry": 275, "brik pastry": 20, cracker: 5, "stock cube": 10, "chicken stock cube": 10, bacon: 20,
  "chicken gyoza": 20, "cardamom pod": 0.3, cardamom: 0.3, "crab stick": 17, taro: 150, kolkas: 150,
  "artichoke heart": 50, kitkat: 42, biscuit: 8, "tea biscuit": 6
};

// Grams in one counted unit (a clove, a bunch…), by the ingredient ("bunch:parsley").
// "*" is the fallback for any ingredient.
export const GRAMS_PER_COUNT = {
  clove: { "*": 5 },
  slice: { "*": 25, cheese: 20, cheddar: 20, bread: 30, toast: 30, ham: 15, salami: 8, bacon: 20, lemon: 8, tomato: 20 },
  bunch: { "*": 80, parsley: 100, mint: 50, coriander: 60, dill: 50, basil: 40, spinach: 300, "spring onion": 100, radish: 200, rocket: 80, "swiss chard": 400, chive: 30 },
  head: { "*": 400, garlic: 50, lettuce: 400, romaine: 500, cauliflower: 800, broccoli: 400, cabbage: 1000 },
  stick: { "*": 10, butter: 113, cinnamon: 3, celery: 40 },
  stalk: { "*": 40, celery: 40, lemongrass: 20 },
  rib: { "*": 40, celery: 40 },
  sprig: { "*": 1, rosemary: 1, thyme: 0.5, mint: 1 },
  leaf: { "*": 0.5, bay: 0.2, basil: 0.5, mint: 0.3, sage: 1, "vine leaf": 3, "lime leaf": 0.3, lettuce: 15 },
  cube: { "*": 10, stock: 10, ice: 25 },
  fillet: { "*": 120, anchovy: 4, salmon: 150, cod: 150, "sea bass": 120, chicken: 200 },
  scoop: { "*": 30 },
  can: { "*": 400, tuna: 185, sardine: 125, corn: 340, "tomato paste": 140, "coconut milk": 400 },
  tin: { "*": 400, tuna: 185, sardine: 125 },
  jar: { "*": 350 },
  sheet: { "*": 20, nori: 3, "puff pastry": 275, "filo pastry": 15, lasagna: 20, "rice paper": 9 },
  ear: { "*": 250 },
  loaf: { "*": 400, "lebanese bread": 110, pita: 80 },
  knob: { "*": 15 }
};

// Rough amounts for words that aren't a measure ("a handful of spinach", "a drizzle of oil").
// They're marked ≈ so you can see they're guesses.
// { unit, amount, byName: { ingredient: amount in that unit } }
export const VAGUE_AMOUNTS = {
  handful: {
    unit: "g",
    amount: 30,
    byName: { spinach: 30, rocket: 20, lettuce: 30, parsley: 15, mint: 10, coriander: 15, basil: 10, dill: 10, herb: 15, olive: 40, nut: 30, cashew: 30, walnut: 30, almond: 30, "hemp seed": 15, seed: 15, raisin: 30, "tortilla chip": 25, cheese: 30 }
  },
  drizzle: { unit: "ml", amount: 15 },
  splash: { unit: "ml", amount: 15 },
  glug: { unit: "ml", amount: 20 },
  dollop: { unit: "ml", amount: 30 },
  squeeze: { unit: "ml", amount: 10 },
  knob: { unit: "g", amount: 15 },
  few: { unit: "pcs", amount: 3 },
  couple: { unit: "pcs", amount: 2 },
  // Seasoning "to taste" or "as needed": about half a teaspoon.
  "to taste": { unit: "ml", amount: 2.5 },
  "as needed": { unit: "ml", amount: 2.5 },
  "as required": { unit: "ml", amount: 2.5 }
};

// Millilitres of juice per gram of fruit, for "4 tbsp lemon, juiced" (a 100g lemon gives about 35ml).
export const JUICE_PER_GRAM = { lemon: 0.35, lime: 0.4, orange: 0.45, grapefruit: 0.45, pomegranate: 0.35 };

// Words that make a vague or spoon amount bigger or smaller ("a big splash", "1 heaped tsp").
export const SIZE_WORDS = { big: 1.5, large: 1.5, generous: 1.5, heaped: 1.5, heaping: 1.5, good: 1.25, small: 0.6, scant: 0.8, level: 1 };

// Seasonings and condiments that recipes often list without an amount ("Salt", "Spices");
// they're costed at a typical amount instead of the whole pack.
export const TYPICAL_AMOUNTS = {
  salt: "1 tsp", pepper: "1/2 tsp", "black pepper": "1/2 tsp", "white pepper": "1/2 tsp", spice: "1 tsp",
  "seven spice": "1 tsp", allspice: "1 tsp", cumin: "1 tsp", paprika: "1 tsp", cinnamon: "1/2 tsp",
  turmeric: "1/2 tsp", sumac: "1 tsp", zaatar: "1 tbsp", "za atar": "1 tbsp", oregano: "1 tsp",
  "dried mint": "1 tsp", "chili flake": "1/2 tsp", "chili powder": "1/2 tsp", cayenne: "1/4 tsp",
  "garlic powder": "1/2 tsp", "curry powder": "1 tbsp", "garam masala": "1 tsp", baharat: "1 tsp",
  "ras el hanout": "1 tsp", saffron: "a pinch", "bay leaf": "2 leaves", oil: "2 tbsp", "olive oil": "2 tbsp",
  "sunflower oil": "2 tbsp", "vegetable oil": "2 tbsp", "sesame oil": "1 tbsp", butter: "1 tbsp",
  vinegar: "1 tbsp", "soy sauce": "2 tbsp", "fish sauce": "1 tbsp", "hot sauce": "1 tsp", ketchup: "2 tbsp",
  mayonnaise: "2 tbsp", mustard: "1 tbsp", honey: "1 tbsp", sugar: "1 tbsp", "lemon juice": "2 tbsp",
  "tomato paste": "1 tbsp", "pomegranate molasse": "1 tbsp", tahini: "3 tbsp", "flaky salt": "1/2 tsp",
  "sea salt": "1 tsp", "stock cube": "1 cube", stock: "500ml", "veg stock": "500ml", "sesame seed": "1 tbsp",
  "nigella seed": "1 tsp", herbs: "1 tbsp", "herbes de provence": "1 tsp", thyme: "1 tsp", rosemary: "1 sprig"
};
