// Write or edit a recipe (PIN required). The wheel tags are built from the
// questions, so a new question automatically shows up here.
import { loadMenu, slugify, ingredientOptions, isOptional, recipeUrl, friendlyError, trackWrite, el } from "./menu.js";
import { requireUnlock } from "./vault.js";
import { findItem, guessCategory, watchQty } from "./cost.js";
import { stepsToText, stepsFromText } from "./notes.js";

const LINK_LABELS = ["Dressing", "Sauce", "Side dish", "Bread", "Dip", "Dessert", "Drink", "Starter"];
const STATES = ["chopped", "diced", "minced", "sliced", "grated", "shredded", "crushed", "juiced", "zested", "cubed", "pitted", "peeled", "soaked overnight", "melted", "softened", "cooked", "toasted"];

const app = document.getElementById("app");
const id = new URLSearchParams(location.search).get("id");

await requireUnlock(app, "Enter your PIN to edit recipes.");
app.innerHTML = '<p class="result-summary">Loading…</p>';
const store = await import("./store.js");
const [{ meals, questions, source }, items] = await Promise.all([loadMenu(), store.loadItems()]);
const original = id ? meals.find((m) => m.id === id) : null;
const meal = original ? structuredClone(original) : { ingredients: [], steps: [], tips: [], links: [] };

// For each question, the values a recipe can be tagged with.
// Questions with min/max (like time) are covered by the minutes field instead.
function tagChoices() {
  return questions
    .filter((q) => !q.options.some((o) => o.min !== undefined || o.max !== undefined))
    .map((q) => {
      const choices = [];
      const add = (value, label) => {
        if (!choices.some((c) => c.value === value)) choices.push({ value, label });
      };
      q.options.forEach((o) => !o.any && o.value !== undefined && add(o.value, `${o.emoji} ${o.label}`));
      q.options.forEach((o) => !o.any && (o.values || []).forEach((v) => add(v, `${o.emoji} ${o.label}`)));
      return { q, choices };
    });
}

const asList = (v) => (Array.isArray(v) ? v : v === undefined || v === null ? [] : [v]);
const cleanName = (s) => s.replace(/\s*\(optional\)/i, "").trim();

function labelled(text, control, hint) {
  const label = el("label", "form-field");
  label.append(el("span", "form-label", text), control);
  if (hint) label.append(el("small", "muted", hint));
  return label;
}

function input(value, attrs = {}) {
  const i = el("input", "field");
  Object.assign(i, attrs);
  i.value = value ?? "";
  return i;
}

function textarea(lines, placeholder) {
  const t = el("textarea", "field");
  t.rows = Math.max(4, lines.length + 1);
  t.placeholder = placeholder;
  t.value = lines.join("\n");
  return t;
}

const fromLines = (text) =>
  text
    .split("\n")
    .map((s) => s.trim())
    .filter(Boolean);

function removeButton(row) {
  const b = el("button", "icon-btn", "×");
  b.type = "button";
  b.setAttribute("aria-label", "Remove");
  b.addEventListener("click", () => row.remove());
  return b;
}

// Shows whether a name matches an existing grocery item or will create a new one.
function linkStatus(nameInput, status) {
  const update = () => {
    const names = nameInput.value.split(",").map((s) => s.trim()).filter(Boolean);
    if (!names.length) {
      status.textContent = "";
      return;
    }
    const found = names.map((n) => [n, findItem({ item: n }, items)]);
    const fresh = found.filter(([, i]) => !i).map(([n]) => n);
    // Say which item a name links to when it isn't the same name ("Rice" -> Egyptian rice).
    const via = found.filter(([n, i]) => i && i.name.toLowerCase() !== n.toLowerCase()).map(([, i]) => i.name);
    status.textContent = fresh.length
      ? `＋ new grocery item: ${fresh.join(", ")}`
      : `✓ linked to ${via.length ? via.join(", ") : "your grocery items"}`;
    status.className = `link-status small ${fresh.length ? "new" : "linked"}`;
  };
  nameInput.addEventListener("input", update);
  update();
}

function ingredientRow(ing = {}) {
  const [main, ...swaps] = ingredientOptions(ing);
  const row = el("div", "edit-row ingredient-row");
  // Swaps' own amounts have no field here; they're kept when the swap stays.
  row.swapQty = new Map((ing.swaps || []).filter((s) => s.qty).map((s) => [s.item.trim().toLowerCase(), s.qty]));

  const qty = watchQty(input(main.qty, { placeholder: "200g" }));
  qty.dataset.role = "qty";
  qty.setAttribute("aria-label", "Amount");

  const name = input(cleanName(main.item), { placeholder: "Ingredient" });
  name.dataset.role = "item";
  name.setAttribute("list", "itemList");
  name.setAttribute("aria-label", "Ingredient");

  const state = input(ing.state, { placeholder: "diced, juiced…" });
  state.dataset.role = "state";
  state.setAttribute("list", "stateList");
  state.setAttribute("aria-label", "How it's prepared (diced, juiced…)");

  const swap = input(swaps.map((s) => s.item).join(", "), { placeholder: "or… (e.g. Cherry tomatoes)" });
  swap.dataset.role = "swaps";
  swap.setAttribute("list", "itemList");
  swap.setAttribute("aria-label", "Swaps, separated by commas");

  const optional = el("label", "small");
  const box = el("input");
  box.type = "checkbox";
  box.checked = typeof ing === "object" && isOptional(ing);
  box.dataset.role = "optional";
  optional.append(box, " optional");

  const status = el("small", "link-status");
  const swapStatus = el("small", "link-status");
  row.append(qty, name, state, swap, optional, removeButton(row), el("span"), status, el("span"), swapStatus);
  linkStatus(name, status);
  linkStatus(swap, swapStatus);
  return row;
}

function linkRow(link = {}) {
  const row = el("div", "edit-row link-row");
  const label = input(link.label, { placeholder: "Dressing / Side dish" });
  label.dataset.role = "label";
  label.setAttribute("list", "linkLabels");
  label.setAttribute("aria-label", "What it is");
  const select = el("select", "field");
  select.dataset.role = "recipe";
  select.setAttribute("aria-label", "Linked recipe");
  select.append(el("option", "", "Choose a recipe…"));
  select.firstChild.value = "";
  meals
    .filter((m) => m.id !== meal.id)
    .sort((a, b) => a.name.localeCompare(b.name))
    .forEach((m) => {
      const opt = el("option", "", `${m.emoji} ${m.name}`);
      opt.value = m.id;
      select.append(opt);
    });
  select.value = link.id || "";
  row.append(label, select, removeButton(row));
  return row;
}

// Finds the grocery item for a name, creating it (with a guessed category) if needed.
// New items are awaited before the recipe is saved (see pendingItems).
const pendingItems = [];
function linkItem(name) {
  const existing = findItem({ item: name }, items);
  if (existing) return existing.id;
  const created = store.createItem({ name, category: guessCategory(name), purchaseQty: "", toPurchase: false, packs: 1 }, items);
  pendingItems.push(trackWrite(created.done));
  items.push({ id: created.id, name });
  return created.id;
}

function render() {
  app.innerHTML = "";
  const head = el("div", "page-head");
  head.append(el("h1", "", original ? `Edit ${original.name}` : "New recipe"));
  if (original) {
    const view = el("a", "btn ghost", "View recipe");
    view.href = recipeUrl(original);
    head.append(view);
  }
  app.append(head);

  const form = el("form", "editor");
  form.noValidate = true;

  // Datalists for ingredient names and link labels.
  const itemList = el("datalist");
  itemList.id = "itemList";
  items.forEach((i) => {
    const o = el("option");
    o.value = i.name;
    itemList.append(o);
  });
  const options = (listId, values) => {
    const list = el("datalist");
    list.id = listId;
    values.forEach((v) => {
      const o = el("option");
      o.value = v;
      list.append(o);
    });
    return list;
  };
  // Preparation states already used in the book come first.
  const usedStates = meals.flatMap((m) => (m.ingredients || []).map((i) => i?.state).filter(Boolean));
  form.append(
    itemList,
    options("linkLabels", LINK_LABELS),
    options("stateList", [...new Set([...usedStates, ...STATES])])
  );

  // Basics
  const basics = el("section", "card recipe-section");
  basics.append(el("h2", "", "Basics"));
  const name = input(meal.name, { required: true, placeholder: "Mujaddara" });
  const emoji = input(meal.emoji, { placeholder: "🍲", maxLength: 8 });
  const description = input(meal.description, { placeholder: "One-line pitch" });
  const servings = input(meal.servings, { type: "number", min: 1, placeholder: "4" });
  const minutes = input(meal.minutes, { type: "number", min: 0, placeholder: "30" });
  const prep = input(meal.prep, { type: "number", min: 0, placeholder: "10" });
  const cook = input(meal.cook, { type: "number", min: 0, placeholder: "20" });
  const chill = input(meal.chill, { type: "number", min: 0, placeholder: "0" });
  // The total follows the parts unless you type your own.
  const parts = [prep, cook, chill];
  let ownTotal = meal.minutes !== undefined && meal.minutes !== parts.reduce((s, p) => s + (Number(p.value) || 0), 0);
  minutes.addEventListener("input", () => (ownTotal = minutes.value !== ""));
  parts.forEach((p) =>
    p.addEventListener("input", () => {
      if (!ownTotal) minutes.value = parts.reduce((s, x) => s + (Number(x.value) || 0), 0) || "";
    })
  );
  const grid = el("div", "form-grid");
  grid.append(
    labelled("Name", name),
    labelled("Emoji", emoji),
    labelled("Servings", servings, "How many portions it makes"),
    labelled("Prep (min)", prep),
    labelled("Cook / bake (min)", cook),
    labelled("Chill / rest (min)", chill),
    labelled("Total minutes", minutes, "Prep + cook + chill, unless you change it")
  );
  const onWheel = el("input");
  onWheel.type = "checkbox";
  onWheel.checked = meal.onWheel !== false;
  const onWheelLabel = el("label", "check-line");
  onWheelLabel.append(onWheel, " 🎡 Show on the spin wheel");
  basics.append(grid, labelled("Description", description), onWheelLabel);
  form.append(basics);

  // Wheel tags
  const tagsBox = el("section", "card recipe-section");
  tagsBox.append(
    el("h2", "", "Labels & wheel tags"),
    el("p", "muted small", "The first group is the recipe's labels (as in Notion); the rest are the wheel's questions. Pick every value that fits; leave a question empty to match any answer.")
  );
  const tagInputs = [];
  tagChoices().forEach(({ q, choices }) => {
    const group = el("fieldset", "tag-group");
    group.append(el("legend", "", q.title));
    const current = asList(meal[q.field]);
    choices.forEach((c) => {
      const label = el("label", "chip toggle");
      const box = el("input");
      box.type = "checkbox";
      box.checked = current.includes(c.value);
      label.append(box, c.label);
      group.append(label);
      tagInputs.push({ field: q.field, value: c.value, box });
    });
    tagsBox.append(group);
  });
  form.append(tagsBox);

  // Ingredients
  const ingBox = el("section", "card recipe-section");
  ingBox.append(
    el("h2", "", "Ingredients"),
    el(
      "p",
      "muted small",
      "Amount used (200g, 2 tbsp, 1/2 cup, 3 cloves, 2 eggs; a dashed box means costs can't use it), the grocery item, and optional swaps you can use instead (each swap is its own grocery item, e.g. Tomatoes or Cherry tomatoes). New names become grocery items when you save."
    )
  );
  const ingRows = el("div", "edit-rows");
  (meal.ingredients || []).forEach((ing) => ingRows.append(ingredientRow(ing)));
  if (!meal.ingredients?.length) ingRows.append(ingredientRow());
  const addIng = el("button", "btn small", "＋ Ingredient");
  addIng.type = "button";
  addIng.addEventListener("click", () => {
    const row = ingredientRow();
    ingRows.append(row);
    row.querySelector('[data-role="item"]').focus();
  });
  ingBox.append(ingRows, addIng);
  form.append(ingBox);

  // Method and tips
  const methodBox = el("section", "card recipe-section");
  methodBox.append(el("h2", "", "Method"));
  const steps = textarea(stepsToText(meal.steps).split("\n"), "One step per line\n- a line starting with a dash is a sub-step of the step above");
  const tips = textarea(meal.tips || [], "One tip per line");
  const notes = textarea(String(meal.notes || "").split("\n"), "# Day 1\n- what you need\n1. first step\n**bold**, *italic*, | tables |");
  notes.rows = Math.min(20, Math.max(4, notes.rows));
  methodBox.append(
    labelled("Steps", steps, "One step per line. Start a line with - to make it a sub-step of the step above. **Bold** works."),
    labelled("Tips", tips, "One tip per line. Link another recipe with its name in double brackets: [[Homemade Caesar Dressing]]"),
    labelled("Guide (optional)", notes, "A longer write-up shown under the method, like a multi-day bread timeline. Simple Markdown: # headings, - lists, 1. numbered, **bold**, | tables |.")
  );
  form.append(methodBox);

  // Linked recipes
  const linkBox = el("section", "card recipe-section");
  linkBox.append(el("h2", "", "Linked recipes"), el("p", "muted small", "A dressing, sauce or suggested side that has its own recipe."));
  const linkRows = el("div", "edit-rows");
  (meal.links || []).forEach((l) => linkRows.append(linkRow(l)));
  const addLink = el("button", "btn small", "＋ Link a recipe");
  addLink.type = "button";
  addLink.addEventListener("click", () => linkRows.append(linkRow()));
  linkBox.append(linkRows, addLink);
  form.append(linkBox);

  // Save / delete
  const status = el("p", "pin-error");
  status.setAttribute("role", "alert");
  const bar = el("div", "save-bar");
  const save = el("button", "btn primary", "Save recipe");
  save.type = "submit";
  bar.append(save);
  if (original) {
    const del = el("button", "btn ghost danger", "Delete");
    del.type = "button";
    del.addEventListener("click", async () => {
      if (!confirm(`Delete ${original.name}? It disappears from the wheel and the recipe book.`)) return;
      del.disabled = true;
      try {
        await store.deleteMeal(original.id);
        location.href = "recipes.html";
      } catch (err) {
        status.textContent = friendlyError(err);
        del.disabled = false;
      }
    });
    bar.append(del);
  }
  bar.append(status);
  form.append(bar);

  function collect() {
    const result = { ...meal, name: name.value.trim() };
    result.emoji = emoji.value.trim() || "🍽️";
    result.description = description.value.trim();
    result.servings = Number(servings.value) || undefined;
    result.minutes = minutes.value === "" ? undefined : Number(minutes.value);
    result.prep = Number(prep.value) || undefined;
    result.cook = Number(cook.value) || undefined;
    result.chill = Number(chill.value) || undefined;
    result.onWheel = onWheel.checked;

    // Tags: none = match anything, one = plain value, several = list.
    tagChoices().forEach(({ q }) => {
      const chosen = tagInputs.filter((t) => t.field === q.field && t.box.checked).map((t) => t.value);
      result[q.field] = chosen.length === 0 ? undefined : chosen.length === 1 ? chosen[0] : chosen;
    });

    // Ingredients, each name linked to a grocery item (created when new).
    result.ingredients = [];
    ingRows.querySelectorAll(".ingredient-row").forEach((row) => {
      const item = row.querySelector('[data-role="item"]').value.trim();
      if (!item) return;
      const ing = { item, itemId: linkItem(item), qty: row.querySelector('[data-role="qty"]').value.trim() || undefined };
      const swaps = row
        .querySelector('[data-role="swaps"]')
        .value.split(",")
        .map((s) => s.trim())
        .filter((s) => s && s.toLowerCase() !== item.toLowerCase());
      if (swaps.length) ing.swaps = swaps.map((s) => ({ item: s, itemId: linkItem(s), qty: row.swapQty.get(s.toLowerCase()) }));
      const prepared = row.querySelector('[data-role="state"]').value.trim();
      if (prepared) ing.state = prepared;
      if (row.querySelector('[data-role="optional"]').checked) ing.optional = true;
      result.ingredients.push(ing);
    });

    result.steps = stepsFromText(steps.value);
    result.tips = fromLines(tips.value);
    result.notes = notes.value.trim() || undefined;
    result.links = [...linkRows.querySelectorAll(".link-row")]
      .map((row) => ({
        id: row.querySelector('[data-role="recipe"]').value,
        label: row.querySelector('[data-role="label"]').value.trim() || undefined
      }))
      .filter((l) => l.id);
    return result;
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    status.textContent = "";
    if (!name.value.trim()) {
      status.textContent = "Give the recipe a name.";
      name.focus();
      return;
    }
    const newId = original ? original.id : slugify(name.value.trim());
    if (!newId) {
      status.textContent = "Use at least one letter or number in the name.";
      return;
    }
    if (!original && meals.some((m) => m.id === newId)) {
      status.textContent = "A recipe with this name already exists.";
      return;
    }

    save.disabled = true;
    save.textContent = "Saving…";
    const result = { ...collect(), id: newId };
    try {
      await Promise.all(pendingItems.splice(0));
      let savedId;
      try {
        savedId = await store.saveMeal(result, { expectedUpdatedAt: original?.updatedAt });
      } catch (err) {
        if (err.code !== "conflict") throw err;
        if (!confirm(`${err.message} Save yours anyway and replace their changes?`)) throw err;
        savedId = await store.saveMeal(result, { force: true });
      }
      location.href = recipeUrl({ id: savedId });
    } catch (err) {
      console.error(err);
      status.textContent = friendlyError(err);
      save.disabled = false;
      save.textContent = "Save recipe";
    }
  });

  app.append(form);
}

if (source !== "firestore") {
  app.innerHTML = "";
  app.append(el("h1", "", "Can't edit right now"));
  app.append(
    el(
      "p",
      "lede",
      source === "seed"
        ? "The recipe book hasn't been imported into the database yet. Import the starter menu in Settings first."
        : "You're offline. Recipes can only be edited with a connection."
    )
  );
  const go = el("a", "btn", "⚙️ Settings");
  go.href = "settings.html";
  app.append(go);
} else if (id && !original) {
  app.innerHTML = "";
  app.append(el("h1", "", "Recipe not found"));
} else {
  render();
}
