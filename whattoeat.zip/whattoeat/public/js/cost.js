// Grocery helpers: quantities, categories, prices and recipe costs.
import { ingredientOptions, isOptional, words } from "./menu.js";
import { parseQty, convert, unitPrice, qtyProblem, typicalQty, formatAmount, asPacks } from "./units.js";

// Change this to your currency symbol. Prices are kept in this currency.
export const CURRENCY = "$";
export const money = (n) => `${CURRENCY}${n.toFixed(2)}`;

// Lebanese pounds per dollar, for typing a shelf price in LBP (the official rate since 2024).
export const LBP_RATE = 89500;
export const fromLbp = (lbp) => Math.round((lbp / LBP_RATE) * 100) / 100;

// The shops you buy from, suggested in the shop fields (others can be typed).
export const SHOPS = ["Le Charcutier", "Carrefour", "Faddoul"];

// ---------- Categories ----------
// Suggested categories, in shopping order. You can also type your own.
export const CATEGORIES = [
  { name: "Produce", emoji: "🥬", kind: "food" },
  { name: "Meat & fish", emoji: "🥩", kind: "food" },
  { name: "Dairy & eggs", emoji: "🧀", kind: "food" },
  { name: "Bakery", emoji: "🍞", kind: "food" },
  { name: "Pantry", emoji: "🥫", kind: "food" },
  { name: "Spices & condiments", emoji: "🧂", kind: "food" },
  { name: "Baking", emoji: "🧁", kind: "food" },
  { name: "Frozen", emoji: "🧊", kind: "food" },
  { name: "Drinks", emoji: "🥤", kind: "food" },
  { name: "Snacks", emoji: "🍫", kind: "food" },
  { name: "Cleaning", emoji: "🧽", kind: "household" },
  { name: "Laundry", emoji: "🧺", kind: "household" },
  { name: "Paper & wraps", emoji: "🧻", kind: "household" },
  { name: "Personal care", emoji: "🧴", kind: "household" },
  { name: "Other", emoji: "📦", kind: "household" }
];

export const categoryInfo = (name) =>
  CATEGORIES.find((c) => c.name.toLowerCase() === String(name || "").toLowerCase()) || {
    name: name || "Other",
    emoji: "📦",
    kind: "other"
  };

// Shopping order: suggested categories first, then your own alphabetically.
export function categoryOrder(a, b) {
  const ia = CATEGORIES.findIndex((c) => c.name === categoryInfo(a).name);
  const ib = CATEGORIES.findIndex((c) => c.name === categoryInfo(b).name);
  if (ia !== -1 || ib !== -1) return (ia === -1 ? 99 : ia) - (ib === -1 ? 99 : ib);
  return String(a).localeCompare(String(b));
}

// A first guess for new items created from recipes (you can change it later).
const GUESSES = [
  ["Frozen", "frozen"],
  ["Laundry", "laundry softener fabric"],
  ["Cleaning", "detergent bleach javel cleaner sponge sponges scourer dishwasher dishwashing wipes disinfectant degreaser garbage trash bin dettol"],
  ["Paper & wraps", "toilet tissue tissues towel towels napkin napkins foil cling film wrap ziplock zipper"],
  ["Personal care", "shampoo conditioner toothpaste toothbrush shower deodorant razor blade lotion soap handwash floss mousse pads"],
  ["Drinks", "water juice coffee tea soda cola nescafe"],
  ["Snacks", "chips crisps chocolate biscuit biscuits cookies popcorn kitkat"],
  ["Baking", "yeast baking vanilla vanillin cocoa starch icing gelatin mahlab"],
  ["Spices & condiments", "salt pepper cumin paprika sumac zaatar za cinnamon spice spices chili flake turmeric curry garam masala oregano thyme dried mustard vinegar sauce soy ketchup mayonnaise honey molasse tahini paste stock cube anise caraway cardamom nutmeg clove bay"],
  ["Dairy & eggs", "milk cheese yogurt yoghurt labneh laban butter cream egg halloumi feta mozzarella parmesan akkawi shanklish cheddar kashkaval ricotta"],
  ["Meat & fish", "chicken beef lamb pork mince minced steak sausage bacon ham fish salmon tuna prawn shrimp cod mussel squid kafta awarma basterma chorizo turkey"],
  ["Bakery", "bread pita baguette bun bagel tortilla markouk dough pastry croissant"],
  ["Produce", "tomato potato onion garlic lemon lime parsley mint coriander lettuce cucumber carrot spinach aubergine eggplant courgette zucchini kousa pepper avocado apple banana mushroom cabbage radish herb okra bean dill basil ginger"],
  ["Pantry", "rice pasta spaghetti noodle lentil chickpea flour sugar oil can tinned burghul bulgur freekeh vermicelli oat quinoa couscous nut almond pine walnut peanut cashew semolina"]
];

const PHRASES = {
  "black pepper": "Spices & condiments",
  "white pepper": "Spices & condiments",
  "chili flake": "Spices & condiments",
  "olive oil": "Pantry",
  "dish soap": "Cleaning",
  "washing up": "Cleaning",
  "baking paper": "Paper & wraps",
  "tortilla chips": "Snacks",
  "coconut water": "Drinks",
  "light bulb": "Other",
  "tomato paste": "Pantry",
  "baking powder": "Baking",
  "baking soda": "Baking",
  "corn starch": "Baking",
  "eau de javel": "Cleaning"
};

export function guessCategory(name) {
  const w = words(name);
  const phrase = Object.keys(PHRASES).find((p) => w.join(" ").includes(p));
  if (phrase) return PHRASES[phrase];
  for (const [category, list] of GUESSES) {
    const keys = list.split(" ");
    if (w.some((x) => keys.includes(x))) return category;
  }
  return "Other";
}

// ---------- Quantities (see units.js) ----------

export { parseQty, scaleQty, unitPrice, qtyProblem, formatAmount } from "./units.js";

// Marks an amount / pack-size input whose text can't be measured (dashed border + tooltip).
export function watchQty(input) {
  const check = () => {
    const problem = qtyProblem(input.value);
    input.classList.toggle("unclear", Boolean(problem));
    input.title = problem;
  };
  input.addEventListener("input", check);
  check();
  return input;
}

// ---------- Prices ----------

// Most recent price record per item id.
export function latestPrices(prices) {
  const latest = new Map();
  prices.forEach((p) => {
    if (!latest.has(p.itemId) || p.date > latest.get(p.itemId).date) latest.set(p.itemId, p);
  });
  return latest;
}

// For each item, the latest price at each shop; then the cheapest of those.
export function cheapestPrices(prices) {
  const perShop = new Map();
  prices.forEach((p) => {
    const k = `${p.itemId}|${p.shop.toLowerCase()}`;
    if (!perShop.has(k) || p.date > perShop.get(k).date) perShop.set(k, p);
  });
  const cheapest = new Map();
  perShop.forEach((p) => {
    const best = cheapest.get(p.itemId);
    const cost = (r) => unitPrice(r)?.value ?? r.price;
    if (!best || cost(p) < cost(best)) cheapest.set(p.itemId, p);
  });
  return cheapest;
}

// The latest price of each item at one shop.
export function shopPrices(prices, shop) {
  const key = String(shop || "").trim().toLowerCase();
  return latestPrices(prices.filter((p) => p.shop.trim().toLowerCase() === key));
}

// Which price an item is costed at: "" the latest anywhere, "cheapest", or a shop's name
// (falling back to the latest anywhere when that shop has no price for it).
// Returns a function itemId -> price record.
export function pricePicker(prices, mode = "") {
  const latest = latestPrices(prices);
  if (!mode) return (id) => latest.get(id);
  if (mode === "cheapest") {
    const cheapest = cheapestPrices(prices);
    return (id) => cheapest.get(id);
  }
  const atShop = shopPrices(prices, mode);
  return (id) => atShop.get(id) || latest.get(id);
}

// The price mode chosen on the Groceries page, remembered on this device.
export function savedPriceMode() {
  try {
    return localStorage.getItem("wte-price-mode") || "";
  } catch {
    return "";
  }
}
export function savePriceMode(mode) {
  try {
    localStorage.setItem("wte-price-mode", mode);
  } catch {
    // Not remembered on this device; that's fine.
  }
}
export const priceModeLabel = (mode) => (!mode ? "latest prices" : mode === "cheapest" ? "the cheapest shop" : mode);

// ---------- Recipe ingredients -> grocery items ----------

// Recipe names that mean a differently named grocery item (by the words of the name).
const ALIASES = {
  yogurt: "Laban", yoghurt: "Laban", "plain yogurt": "Laban", prawn: "Frozen shrimp", shrimp: "Frozen shrimp",
  pepper: "Bell peppers", "red pepper": "Bell peppers", "green pepper": "Bell peppers", "sweet pepper": "Bell peppers",
  courgette: "Kousa (courgettes)", zucchini: "Kousa (courgettes)", mint: "Fresh mint", rice: "Egyptian rice",
  "olive oil": "Extra virgin olive oil", oil: "Vegetable oil", chickpea: "Canned chickpeas",
  "soaked chickpea": "Dried chickpeas", bulgur: "Fine bulgur", burghul: "Fine bulgur", "fine burghul": "Fine bulgur",
  "coarse burghul": "Coarse bulgur", "minced lamb": "Lamb mince", pita: "Lebanese bread", "pita bread": "Lebanese bread",
  flatbread: "Lebanese bread", "baladi bread": "Lebanese bread", bread: "Toast bread", toast: "Toast bread",
  lettuce: "Iceberg lettuce", romaine: "Romaine lettuce", chili: "Green chillies", chilli: "Green chillies",
  stock: "Chicken stock cubes", "veg stock": "Vegetable stock cubes", "lemon juice": "Lemons", "garlic paste": "Toum",
  fish: "White fish fillets", "white fish": "White fish fillets", aubergine: "Aubergines", eggplant: "Aubergines",
  "cooked chicken": "Chicken breast", "rotisserie chicken": "Whole chicken", chicken: "Whole chicken",
  "chicken piece": "Whole chicken", "lean minced beef": "Minced beef", lamb: "Lamb shoulder", "beef cube": "Beef cubes",
  "stewing beef": "Beef cubes", herb: "Parsley", sweetcorn: "Sweet corn", corn: "Sweet corn", tortilla: "Tortilla wraps",
  "tinned tuna": "Canned tuna", tuna: "Canned tuna", "tomato sauce": "Tomato sauce", mustard: "Yellow mustard",
  "sesame seed": "Sesame seeds", sesame: "Sesame seeds", noodle: "Egg noodles", cheese: "Mozzarella",
  pasta: "Penne", "small pasta": "Vermicelli", "seven spice": "Seven spices", spices: "Seven spices", jalapeno: "Jalapeños",
  "vine leaves": "Vine leaves", "fava beans": "Canned fava beans", "dried fava beans": "Dried fava beans", "white beans": "White beans",
  "mloukhieh leaves": "Frozen mloukhieh", moughrabieh: "Moghrabieh", "kabsa spice": "Kabsa spices", "shawarma spices": "Shawarma spices",
  pickles: "Pickled cucumbers", gherkins: "Pickled cucumbers", radish: "Radishes", "sea bass": "White fish fillets",
  "cod or haddock": "White fish fillets", "makanek sausages": "Makanek", cornflour: "Corn starch", cayenne: "Chili powder",
  "smoked paprika": "Paprika", "baby potatoes": "Potatoes", "new potatoes": "Potatoes", "baking potatoes": "Potatoes",
  "cooked rice": "Egyptian rice", "tomato passata": "Tomato sauce", passata: "Tomato sauce", "cannellini beans": "White beans",
  "lamb cubes": "Lamb shoulder", "beef or lamb": "Beef cubes", "chicken or lamb": "Whole chicken", "chicken or meat": "Whole chicken",
  "lamb or chicken": "Whole chicken", "chicken or steak": "Chicken breast", "flaky salt": "Coarse salt", "sea salt": "Coarse salt",
  "salad leaves": "Iceberg lettuce", "mixed leaves": "Iceberg lettuce", "cooked lentils": "Brown lentils", "taboon bread": "Lebanese bread",
  "very fresh lean lamb": "Lamb mince", "ribeye steak": "Beef steak", "beef strips": "Beef steak", steak: "Beef steak",
  "pearl onions": "Onions", "roasted red peppers": "Bell peppers"
};
const key = (s) => words(String(s || "").replace(/\(.*?\)/g, "")).join(" ");
const aliasMap = new Map(Object.entries(ALIASES).map(([k, v]) => [key(k), key(v)]));

// The grocery item an ingredient option refers to: its linked id, else the same name, else
// a known alias ("Yogurt" is Laban), else the one item whose name ends with it ("Olive oil"
// is "Extra virgin olive oil"; the shortest wins when several do).
export function findItem(option, items) {
  if (option.itemId) {
    const linked = items.find((i) => i.id === option.itemId);
    if (linked) return linked;
  }
  const k = key(option.item);
  if (!k) return undefined;
  const byKey = (x) => items.find((i) => key(i.name) === x);
  const exact = byKey(k);
  if (exact) return exact;
  const alias = aliasMap.get(k);
  if (alias && byKey(alias)) return byKey(alias);
  const w = k.split(" ");
  return items
    .filter((i) => {
      const iw = key(i.name).split(" ");
      return iw.length > w.length && w.every((x, n) => iw[iw.length - w.length + n] === x);
    })
    .sort((a, b) => a.name.length - b.name.length)[0];
}

// ---------- Recipe costs ----------

// making:  the packs you'd buy for this recipe: enough of each item to cover every amount
//          that uses it (1.5kg of courgettes sold by the kilo is 2 packs), at least one each
// portion: the share of each pack the recipe uses, divided by the servings
// lines:   one per ingredient: what it is, the amount, how it compares with the pack
//          ("1 tbsp ≈ 17 g of a 300 g jar"), its cost, and a note when it's a guess
// `choices` maps ingredient index -> which option (0 = main, 1+ = swaps) is used;
// `mode` is the price to use (see pricePicker).
// Ingredients without an item or a price are listed in `unpriced`. Amounts compared
// through a typical weight (a cup of flour against a bag sold by weight) are listed in
// `estimated`; amounts that couldn't be compared at all, so the full pack price was used,
// in `fullPrice`. `approx` is set for either, or when servings are missing.
export function mealCost(meal, items, prices, choices = {}, mode = "") {
  const pick = pricePicker(prices, mode);
  const servings = Number(meal.servings) > 0 ? Number(meal.servings) : 1;
  const perItem = new Map(); // item id -> { cost, pack, needed }
  let used = 0;
  const unpriced = [];
  const estimated = [];
  const fullPrice = [];
  const lines = [];

  (meal.ingredients || []).forEach((ing, index) => {
    const options = ingredientOptions(ing);
    const option = options[choices[index] || 0] || options[0];
    const line = { name: option.item, state: ing?.state || "", qty: option.qty || "", optional: isOptional(ing) };
    lines.push(line);
    if (line.optional) {
      line.note = "optional, not counted";
      return;
    }
    const item = findItem(option, items);
    const price = item && pick(item.id);
    line.item = item;
    if (!price || !Number.isFinite(Number(price.price))) {
      unpriced.push(option.item);
      line.note = item ? "no price yet" : "not a grocery item yet";
      return;
    }
    const cost = Number(price.price);
    const packText = price.qty || item.purchaseQty;
    const pack = parseQty(packText);
    line.price = price;
    line.pack = packText;
    if (!perItem.has(item.id)) perItem.set(item.id, { cost, pack, needed: 0 });
    const entry = perItem.get(item.id);

    // No amount written: seasonings and oils are costed at a typical amount.
    const typical = !option.qty && typicalQty(option.item || item.name);
    const qtyText = option.qty || typical || "";
    // The recipe's wording first ("Cardamon"), then the grocery item's name ("Cardamom pods").
    const needFor = (name) => convert(parseQty(qtyText, name), pack.unit, name, item, line.state);
    const need = pack && pack.amount > 0 ? (option.item && needFor(option.item)) || needFor(item.name) || asPacks(parseQty(qtyText), pack) : null;
    if (!need) {
      used += cost;
      line.cost = cost;
      entry.needed += pack?.amount || 0;
      fullPrice.push(option.item);
      line.note = qtyText ? `“${qtyText}” can't be compared with a ${packText || "pack"}, so the whole pack is counted` : "no amount, so the whole pack is counted";
      return;
    }
    const share = need.amount / pack.amount;
    used += cost * share;
    entry.needed += need.amount;
    line.cost = cost * share;
    line.used = `${need.approx ? "≈ " : ""}${formatAmount(need.amount, pack.unit)}`;
    line.share = share;
    if (typical) line.note = `no amount written; counted as ${typical}`;
    if (need.approx || typical) estimated.push(option.item);
  });

  let making = 0;
  perItem.forEach(({ cost, pack, needed }) => {
    const packs = pack && pack.amount > 0 ? Math.max(1, Math.ceil(needed / pack.amount - 1e-9)) : 1;
    making += cost * packs;
  });

  const approx = !(Number(meal.servings) > 0) || estimated.length > 0 || fullPrice.length > 0;
  return { making, portion: used / servings, servings, approx, unpriced, estimated, fullPrice, lines };
}
