// Meal plan (PIN required): a week at a time, up to three meals a day (breakfast, lunch,
// dinner), each with its own number of servings. "Build grocery list" turns the week into
// packs to buy, which you can tick off before they go on the grocery list.
//
// plan.html?add=<recipe id> (from a recipe page or the wheel) asks for a slot to put it in;
// plan.html?week=YYYY-MM-DD opens the week of that day.
import { loadMenu, el, notify, friendlyError, trackWrite, recipeUrl, words } from "./menu.js";
import { requireUnlock } from "./vault.js";
import { money } from "./cost.js";
import { SLOTS, isoDate, parseDate, addDays, mondayOf, weekDays, entriesOf, planGroceries } from "./mealplan.js";

const app = document.getElementById("app");
await requireUnlock(app, "Enter your PIN to plan meals.");
const store = await import("./store.js");
const { meals } = await loadMenu();

const params = new URLSearchParams(location.search);
const state = {
  monday: mondayOf(parseDate(params.get("week")) || new Date()),
  plan: {}, // date -> slot -> { id, servings }
  months: new Set(), // months already loaded
  adding: meals.find((m) => m.id === params.get("add")) || null,
  shopping: null, // grocery rows built from the week, waiting to be ticked
  added: "" // message after the rows went on the grocery list
};

const mealById = (id) => meals.find((m) => m.id === id);
const servingsOf = (meal) => (Number(meal?.servings) > 0 ? Number(meal.servings) : 2);
const dayLabel = (d, long = false) =>
  d.toLocaleDateString("en-GB", { weekday: long ? "long" : "short", day: "numeric", month: "short" });
const week = () => weekDays(state.monday).map(isoDate);

function remember() {
  const url = new URL(location.href);
  url.searchParams.set("week", isoDate(state.monday));
  if (state.adding) url.searchParams.set("add", state.adding.id);
  else url.searchParams.delete("add");
  history.replaceState(null, "", url);
}

// Loads the months the shown week touches (1-2 reads, each once per visit).
async function loadWeek() {
  const months = [...new Set(week().map((d) => d.slice(0, 7)))].filter((m) => !state.months.has(m));
  if (!months.length) return;
  try {
    Object.assign(state.plan, await store.loadPlan(months));
    months.forEach((m) => state.months.add(m));
  } catch (err) {
    notify(friendlyError(err), "error");
  }
}

// Saves one slot in the background (works offline; syncs later).
function setSlot(date, slot, entry) {
  state.plan[date] ||= {};
  if (entry) state.plan[date][slot] = entry;
  else delete state.plan[date][slot];
  state.shopping = null;
  state.added = "";
  trackWrite(store.setPlanSlot(date, slot, entry)).catch((err) => {
    console.error(err);
    notify(friendlyError(err), "error");
  });
  render();
}

// ---------- Choosing a recipe ----------

const dialog = el("dialog", "picker");
dialog.setAttribute("aria-label", "Choose a recipe");
document.body.append(dialog);

function openPicker(date, slot) {
  const info = SLOTS.find((s) => s.id === slot);
  dialog.innerHTML = "";
  const head = el("div", "page-head");
  head.append(el("h2", "", `${info.emoji} ${info.label} · ${dayLabel(parseDate(date), true)}`));
  const close = el("button", "icon-btn", "×");
  close.type = "button";
  close.setAttribute("aria-label", "Close");
  close.addEventListener("click", () => dialog.close());
  head.append(close);

  const search = el("input", "field");
  search.type = "search";
  search.placeholder = "Search recipes";
  search.setAttribute("aria-label", "Search recipes");
  const surprise = el("button", "btn small", "🎲 Surprise me");
  surprise.type = "button";
  const tools = el("div", "toolbar");
  tools.append(search, surprise);
  const list = el("ul", "picker-list");

  // Breakfast lists small bites first; written recipes come before the rest.
  const preferred = (m) => (slot === "breakfast" ? [].concat(m.type ?? []).includes("small") : [].concat(m.type ?? []).includes("full"));
  const ranked = [...meals].sort(
    (a, b) => preferred(b) - preferred(a) || (b.steps?.length > 0) - (a.steps?.length > 0) || a.name.localeCompare(b.name)
  );
  const choose = (meal) => {
    dialog.close();
    setSlot(date, slot, { id: meal.id, servings: servingsOf(meal) });
  };
  const show = () => {
    list.innerHTML = "";
    const terms = words(search.value);
    const found = ranked.filter((m) => {
      const hay = words(`${m.name} ${m.description || ""} ${m.cuisine || ""}`);
      return terms.every((t) => hay.some((w) => w.startsWith(t)));
    });
    found.slice(0, 40).forEach((m) => {
      const li = el("li");
      const b = el("button", "", `${m.emoji} `);
      b.type = "button";
      b.append(el("strong", "", m.name));
      if (typeof m.minutes === "number") b.append(el("span", "muted small", ` · ${m.minutes} min`));
      b.addEventListener("click", () => choose(m));
      li.append(b);
      list.append(li);
    });
    if (!found.length) list.append(el("li", "muted", "No recipe matches."));
  };
  search.addEventListener("input", show);
  surprise.addEventListener("click", () => {
    const pool = ranked.filter((m) => m.onWheel !== false && preferred(m));
    const from = pool.length ? pool : ranked;
    choose(from[Math.floor(Math.random() * from.length)]);
  });
  dialog.append(head, tools, list);
  show();
  dialog.showModal();
  search.focus();
}

// ---------- The week ----------

function slotRow(date, slot) {
  const row = el("div", "plan-slot");
  row.append(el("span", "slot-label", `${slot.emoji} ${slot.label}`));
  const entry = state.plan[date]?.[slot.id];
  const meal = entry && mealById(entry.id);
  if (entry) {
    const link = el("a", "meal", meal ? `${meal.emoji} ${meal.name}` : "A deleted recipe");
    if (meal) link.href = recipeUrl(meal);
    const stepper = el("span", "stepper");
    const minus = el("button", "icon-btn", "−");
    const plus = el("button", "icon-btn", "+");
    minus.type = plus.type = "button";
    minus.setAttribute("aria-label", "Fewer servings");
    plus.setAttribute("aria-label", "More servings");
    minus.disabled = entry.servings <= 1;
    minus.addEventListener("click", () => setSlot(date, slot.id, { ...entry, servings: Math.max(1, entry.servings - 1) }));
    plus.addEventListener("click", () => setSlot(date, slot.id, { ...entry, servings: entry.servings + 1 }));
    stepper.append(minus, el("span", "count", `${entry.servings}🍽`), plus);
    const remove = el("button", "icon-btn", "×");
    remove.type = "button";
    remove.setAttribute("aria-label", `Remove ${meal?.name || "this meal"}`);
    remove.addEventListener("click", () => setSlot(date, slot.id, null));
    row.append(link, stepper, remove);
  } else if (state.adding) {
    const put = el("button", "btn small primary", "＋ Put here");
    put.type = "button";
    put.addEventListener("click", () => {
      const meal = state.adding;
      state.adding = null;
      remember();
      setSlot(date, slot.id, { id: meal.id, servings: servingsOf(meal) });
      notify(`📅 ${meal.name} planned for ${dayLabel(parseDate(date), true)}.`);
    });
    row.append(put);
  } else {
    const add = el("button", "btn small ghost", "＋ Add");
    add.type = "button";
    add.setAttribute("aria-label", `Add ${slot.label.toLowerCase()} on ${dayLabel(parseDate(date), true)}`);
    add.addEventListener("click", () => openPicker(date, slot.id));
    row.append(add);
  }
  return row;
}

// The week as a WhatsApp message.
function weekText() {
  const days = weekDays(state.monday);
  const lines = [`*📅 Meal plan ${dayLabel(days[0])} – ${dayLabel(days[6])}*`];
  days.forEach((d) => {
    const planned = SLOTS.filter((s) => state.plan[isoDate(d)]?.[s.id]);
    if (!planned.length) return;
    lines.push("", `*${dayLabel(d, true)}*`);
    planned.forEach((s) => {
      const e = state.plan[isoDate(d)][s.id];
      const m = mealById(e.id);
      lines.push(`${s.emoji} ${m ? `${m.emoji} ${m.name}` : "?"} (${e.servings})`);
    });
  });
  return lines.join("\n");
}

// ---------- Groceries for the week ----------

async function buildShopping(button) {
  button.disabled = true;
  button.textContent = "Working it out…";
  try {
    const [items, latest] = await Promise.all([store.loadItems(), store.loadLatestPrices()]);
    const rows = planGroceries(entriesOf(state.plan, week()), meals, items, latest);
    state.shopping = rows.map((r) => ({ ...r, take: true }));
    state.items = items;
    state.added = "";
  } catch (err) {
    notify(friendlyError(err), "error");
  }
  render();
}

async function addShopping(button) {
  const chosen = state.shopping.filter((r) => r.take);
  button.disabled = true;
  try {
    const changes = Object.fromEntries(
      chosen
        .filter((r) => r.item)
        .map((r) => {
          const current = r.item.toPurchase && Number(r.item.packs) > 0 ? Number(r.item.packs) : 0;
          return [r.item.id, { toPurchase: true, inCart: false, packs: Math.max(current, r.packs) }];
        })
    );
    const fresh = chosen
      .filter((r) => !r.item)
      .map((r) => ({ name: r.name, category: r.category, purchaseQty: "", toPurchase: true, packs: r.packs }));
    await trackWrite(Promise.all([Object.keys(changes).length && store.updateItems(changes), fresh.length && store.createItems(fresh, state.items)]));
    state.shopping = null;
    state.added = `✓ ${chosen.length} item${chosen.length === 1 ? "" : "s"} on the grocery list${fresh.length ? ` (${fresh.length} new)` : ""}.`;
  } catch (err) {
    notify(friendlyError(err), "error");
  }
  render();
}

function shoppingCard() {
  const card = el("section", "card recipe-section plan-shopping");
  card.append(el("h2", "", "🛒 Groceries for this week"));
  const planned = entriesOf(state.plan, week());
  if (state.added) {
    const done = el("p", "", state.added);
    const go = el("a", "", " Open the list →");
    go.href = "groceries.html#list";
    done.append(go);
    card.append(done);
  }
  if (!state.shopping) {
    card.append(el("p", "muted small", planned.length ? `${planned.length} meal${planned.length === 1 ? "" : "s"} planned this week.` : "Plan some meals first."));
    const build = el("button", "btn primary", "Build grocery list");
    build.type = "button";
    build.disabled = !planned.length;
    build.addEventListener("click", () => buildShopping(build));
    card.append(build);
    return card;
  }

  card.append(
    el("p", "muted small", "Everything the week's recipes need, in packs, scaled to the servings you planned. Untick what you already have. Ingredients without an amount count as one pack.")
  );
  const ul = el("ul", "grocery-list");
  const footer = el("div", "list-footer");
  const total = el("strong");
  const addBtn = el("button", "btn primary");
  addBtn.type = "button";
  addBtn.addEventListener("click", () => addShopping(addBtn));
  const update = () => {
    const chosen = state.shopping.filter((r) => r.take);
    const priced = chosen.filter((r) => r.cost !== null);
    total.textContent = `≈ ${money(priced.reduce((s, r) => s + r.cost, 0))}${priced.length < chosen.length ? ` + ${chosen.length - priced.length} without a price` : ""}`;
    addBtn.textContent = `Add ${chosen.length} to the grocery list`;
    addBtn.disabled = !chosen.length;
  };
  state.shopping.forEach((r) => {
    const li = el("li");
    const label = el("label");
    const box = el("input");
    box.type = "checkbox";
    box.checked = r.take;
    box.addEventListener("change", () => {
      r.take = box.checked;
      update();
    });
    label.append(box, el("strong", "", r.name), el("span", "muted", ` ×${r.packs}`));
    if (!r.item) label.append(el("span", "badge", "new item"));
    if (r.item?.toPurchase) label.append(el("span", "muted small", ` · on the list ×${r.item.packs || 1}`));
    li.append(label, el("span", "muted small", `${r.cost !== null ? `${money(r.cost)} · ` : ""}for ${r.uses.join(", ")}`));
    ul.append(li);
  });
  footer.append(total, addBtn);
  card.append(ul, footer);
  update();
  return card;
}

// ---------- Page ----------

function render() {
  app.innerHTML = "";
  const head = el("div", "page-head");
  head.append(el("h1", "", "Meal plan"));
  const share = el("a", "btn ghost small", "💬 Share week");
  share.target = "_blank";
  share.rel = "noopener";
  share.addEventListener("click", () => (share.href = `https://wa.me/?text=${encodeURIComponent(weekText())}`));
  head.append(share);
  app.append(head, el("p", "lede", "Up to three meals a day. The week becomes a grocery list at the bottom."));

  if (state.adding) {
    const bar = el("div", "card plan-adding");
    bar.append(el("span", "", `Pick a free slot for ${state.adding.emoji} `), el("strong", "", state.adding.name));
    const cancel = el("button", "btn small ghost", "Cancel");
    cancel.type = "button";
    cancel.addEventListener("click", () => {
      state.adding = null;
      remember();
      render();
    });
    bar.append(cancel);
    app.append(bar);
  }

  const days = weekDays(state.monday);
  const nav = el("div", "plan-nav");
  nav.append(el("h2", "", `${dayLabel(days[0])} – ${dayLabel(days[6])} ${days[6].getFullYear()}`));
  const go = (label, aria, monday) => {
    const b = el("button", "btn small ghost", label);
    b.type = "button";
    b.setAttribute("aria-label", aria);
    b.addEventListener("click", async () => {
      state.monday = monday;
      state.shopping = null;
      state.added = "";
      remember();
      await loadWeek();
      render();
    });
    nav.append(b);
  };
  go("‹", "Previous week", addDays(state.monday, -7));
  go("This week", "This week", mondayOf(new Date()));
  go("›", "Next week", addDays(state.monday, 7));
  app.append(nav);

  const today = isoDate(new Date());
  const grid = el("div", "plan-week");
  days.forEach((d) => {
    const date = isoDate(d);
    const day = el("section", `card plan-day${date === today ? " today" : ""}`);
    day.dataset.date = date;
    day.append(el("h3", "", `${dayLabel(d, true)}${date === today ? " · today" : ""}`));
    SLOTS.forEach((slot) => day.append(slotRow(date, slot)));
    grid.append(day);
  });
  app.append(grid, shoppingCard());
}

remember();
await loadWeek();
render();
