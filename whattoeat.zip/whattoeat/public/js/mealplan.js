// Meal plan helpers: dates, the three slots of a day, and the shopping a plan needs.
// Dates are local calendar days as "YYYY-MM-DD"; weeks start on Monday.
import { ingredientOptions, isOptional, words } from "./menu.js";
import { findItem, pricePicker, savedPriceMode, guessCategory, categoryOrder } from "./cost.js";
import { parseQty, convert, typicalQty, asPacks } from "./units.js";

export const SLOTS = [
  { id: "breakfast", label: "Breakfast", emoji: "🌅" },
  { id: "lunch", label: "Lunch", emoji: "☀️" },
  { id: "dinner", label: "Dinner", emoji: "🌙" }
];

const pad = (n) => String(n).padStart(2, "0");
export const isoDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

export function parseDate(text) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text || "");
  const d = m && new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  return d && isoDate(d) === text ? d : null;
}

export function addDays(date, n) {
  const d = new Date(date);
  d.setDate(d.getDate() + n);
  return d;
}

export function mondayOf(date) {
  const d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  return addDays(d, -((d.getDay() + 6) % 7));
}

export const weekDays = (monday) => Array.from({ length: 7 }, (_, i) => addDays(monday, i));

// The planned meals of some days as a flat list: [{ date, slot, id, servings }].
export function entriesOf(plan, dates) {
  return dates.flatMap((date) =>
    SLOTS.filter((s) => plan[date]?.[s.id]?.id).map((s) => ({ date, slot: s.id, ...plan[date][s.id] }))
  );
}

// What planned meals need from the shop: one row per grocery item (or, for ingredients
// with no item yet, per name), with the packs to buy. Amounts are scaled to the planned
// servings and added up across meals; an ingredient without a comparable amount counts
// as one pack. Optional ingredients are left out; the main ingredient is used, not swaps.
//   -> [{ item?, name, category, packs, uses: [recipe names], cost?, loose }]
export function planGroceries(entries, meals, items, prices = []) {
  // Priced the way the Groceries page is set (latest, cheapest or one shop).
  const pick = pricePicker(prices, savedPriceMode());
  const rows = new Map();
  entries.forEach(({ id, servings }) => {
    const meal = meals.find((m) => m.id === id);
    if (!meal) return;
    const base = Number(meal.servings) > 0 ? Number(meal.servings) : null;
    const factor = base && Number(servings) > 0 ? Number(servings) / base : 1;
    (meal.ingredients || []).forEach((ing) => {
      if (isOptional(ing)) return;
      const option = ingredientOptions(ing)[0];
      const item = findItem(option, items);
      const name = item?.name || option.item.replace(/\s*\(.*?\)/g, "").trim();
      if (!name) return;
      const key = item ? item.id : `new:${words(name).join(" ")}`;
      if (!rows.has(key)) {
        const price = item && pick(item.id);
        rows.set(key, { item, name, price, pack: parseQty(price?.qty || item?.purchaseQty), needed: 0, loose: false, uses: new Set() });
      }
      const row = rows.get(key);
      row.uses.add(meal.name);
      const qty = option.qty || typicalQty(option.item);
      // The recipe's wording first, then the grocery item's name.
      const needFor = (n) => convert(parseQty(qty, n), row.pack.unit, n, item, ing?.state);
      const need = row.pack?.amount > 0 ? (option.item && needFor(option.item)) || needFor(name) || asPacks(parseQty(qty), row.pack) : null;
      if (need) row.needed += need.amount * factor;
      else row.loose = true;
    });
  });
  return [...rows.values()]
    .map(({ item, name, price, pack, needed, loose, uses }) => {
      const packs = Math.max(1, pack?.amount > 0 ? Math.ceil(needed / pack.amount - 1e-9) : 1);
      return {
        item,
        name,
        category: item?.category || guessCategory(name),
        packs,
        uses: [...uses],
        cost: price ? Number(price.price) * packs : null,
        loose
      };
    })
    .sort((a, b) => categoryOrder(a.category, b.category) || a.name.localeCompare(b.name));
}
