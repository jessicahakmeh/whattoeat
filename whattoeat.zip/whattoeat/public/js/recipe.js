// A single recipe: ingredients (with swaps and a servings scaler), steps, tips,
// linked recipes, costs, and a grocery-list button per ingredient.
// Costs and the grocery list need the PIN.
import {
  loadMenu,
  mealTags,
  ingredientOptions,
  isOptional,
  hasOwnRecipe,
  findRecipe,
  recipeUrl,
  searchUrl,
  attempt,
  notify,
  friendlyError,
  trackWrite,
  slugify,
  el
} from "./menu.js";
import { inline, stepItem, renderNotes } from "./notes.js";
import { sharePdfButton } from "./recipe-pdf.js";
import { loadSheetJS, recipeWorkbook } from "./recipe-excel.js";
import { isUnlocked, requireUnlock } from "./vault.js";
import { mealCost, findItem, money, scaleQty, guessCategory, savedPriceMode, savePriceMode } from "./cost.js";

const root = document.getElementById("recipe");
const id = new URLSearchParams(location.search).get("id");
const { meals, questions } = await loadMenu();
const meal = meals.find((m) => m.id === id);

const baseServings = Number(meal?.servings) > 0 ? Number(meal.servings) : null;
const state = {
  servings: baseServings || 1,
  choices: {}, // ingredient index -> chosen option (0 = main, 1+ = swaps)
  unlocked: false,
  items: [],
  prices: [],
  priceMode: savedPriceMode()
};

const factor = () => (baseServings ? state.servings / baseServings : 1);
const chosenOption = (ing, index) => {
  const options = ingredientOptions(ing);
  return options[state.choices[index] || 0] || options[0];
};

function section(title) {
  const s = el("section", "card recipe-section");
  s.append(el("h2", "", title));
  return s;
}

function linkCard(target, label) {
  const a = el("a", "link-card");
  a.href = recipeUrl(target);
  a.append(el("span", "pr-emoji", target.emoji));
  const text = el("span");
  if (label) text.append(el("small", "muted", label));
  text.append(el("strong", "", target.name));
  a.append(text);
  return a;
}

// ---------- PIN-only data ----------

// Asks for the PIN once (later callers wait for the same unlock), then loads items and prices.
let unlocking = null;
function unlock(area, message) {
  unlocking ||= (async () => {
    await requireUnlock(area, message);
    const store = await import("./store.js");
    [state.items, state.prices] = await Promise.all([store.loadItems(), store.loadLatestPrices()]);
    state.unlocked = true;
    renderIngredients();
    renderCost();
  })().catch((err) => {
    unlocking = null;
    throw err;
  });
  return unlocking;
}

// ---------- Ingredients ----------

const ingBox = section("Ingredients");
const ingList = el("ul", "ingredient-list");
const ingLock = el("div", "lock-area");

// Puts the chosen option of one ingredient on the grocery list, or takes it off.
async function toggleGrocery(index, button) {
  const ing = meal.ingredients[index];
  await unlock(ingLock, "Enter your PIN to use the grocery list.");
  const store = await import("./store.js");
  const option = chosenOption(ing, index);
  let item = findItem(option, state.items);
  await attempt(button, async () => {
    if (!item) {
      const name = option.item.replace(/\s*\(.*?\)/g, "");
      const created = store.createItem({ name, category: guessCategory(name), purchaseQty: "", toPurchase: true, packs: 1 }, state.items);
      item = { id: created.id, name, toPurchase: true };
      state.items.push(item);
      trackWrite(created.done).catch((err) => notify(`Couldn't save ${name}: ${friendlyError(err)}`, "error"));
      notify(`🛒 ${name} added to the grocery list (new item).`);
    } else {
      item.toPurchase = !item.toPurchase;
      trackWrite(store.updateItem(item.id, { toPurchase: item.toPurchase, inCart: false })).catch((err) =>
        notify(friendlyError(err), "error")
      );
      notify(item.toPurchase ? `🛒 ${item.name} added to the grocery list.` : `${item.name} taken off the grocery list.`);
    }
    renderIngredients();
  });
}

// The recipe's cost at the servings shown and the chosen prices (PIN only).
function currentCost() {
  const scaled = { ...meal, ingredients: (meal.ingredients || []).map((ing) => scaledIngredient(ing)) };
  return mealCost(scaled, state.items, state.prices, state.choices, state.priceMode);
}

// Where to add a missing price: the item's price history, or a new item by name.
const priceLink = (line) =>
  line.item ? `groceries.html?price=${encodeURIComponent(line.item.id)}#prices` : `groceries.html?item=${encodeURIComponent(line.name)}#prices`;

// An ingredient's cost on its line: "$0.10", or a warning with a link to add the price.
function linePrice(line) {
  if (!line || line.optional) return null;
  if (line.cost === undefined) {
    const a = el("a", "line-price missing screen-only", "⚠️ no price · add");
    a.href = priceLink(line);
    a.title = `${line.note || "No price yet"}: add one on the Groceries page`;
    return a;
  }
  const span = el("span", `line-price screen-only${line.note ? " whole" : ""}`, money(line.cost));
  span.title = [line.used && `${line.used} of ${line.pack}`, line.price && `${money(line.price.price)} at ${line.price.shop}`, line.note].filter(Boolean).join(" · ");
  return span;
}

function renderIngredients() {
  ingList.innerHTML = "";
  const lines = state.unlocked ? currentCost().lines : [];
  (meal.ingredients || []).forEach((ing, index) => {
    const options = ingredientOptions(ing);
    const option = chosenOption(ing, index);
    const li = el("li");

    const label = el("label");
    const box = el("input");
    box.type = "checkbox";
    box.setAttribute("aria-label", "Done");
    label.append(box);
    const qty = scaleQty(option.qty, factor());
    if (qty) label.append(el("strong", "", `${qty} `));
    const nameText = el("span", "", option.item);
    if (ing.state) nameText.append(el("span", "muted", `, ${ing.state}`));
    label.append(nameText);
    if (isOptional(ing) && !/optional/i.test(option.item)) label.append(el("span", "muted small", " (optional)"));
    li.append(label);

    // Swap between the main ingredient and its alternatives.
    if (options.length > 1) {
      const select = el("select", "field small swap");
      select.setAttribute("aria-label", `Swap ${options[0].item}`);
      options.forEach((o, i) => {
        const opt = el("option", "", i === 0 ? o.item : `↔ ${o.item}`);
        opt.value = i;
        select.append(opt);
      });
      select.value = state.choices[index] || 0;
      select.addEventListener("change", () => {
        state.choices[index] = Number(select.value);
        renderIngredients();
        renderCost();
      });
      const others = options.filter((o) => o !== option).map((o) => o.item);
      li.append(select, el("span", "muted small print-only", `(or ${others.join(" / ")})`));
    }

    const item = state.unlocked ? findItem(option, state.items) : null;
    const onList = Boolean(item?.toPurchase);
    const cart = el("button", `icon-btn cart${onList ? " on" : ""}`, onList ? "✓🛒" : "＋🛒");
    cart.type = "button";
    cart.title = onList ? "On the grocery list (click to remove)" : "Add to the grocery list";
    cart.setAttribute("aria-label", `${cart.title}: ${option.item}`);
    cart.addEventListener("click", () => toggleGrocery(index, cart));
    const price = linePrice(lines[index]);
    if (price) {
      li.append(price);
      if (lines[index].cost === undefined) li.classList.add("unpriced");
    }
    li.append(cart);
    ingList.append(li);
  });
}

// ---------- Cost ----------

const costBox = el("section", "card recipe-section screen-only");

function renderCost() {
  costBox.innerHTML = "";
  costBox.append(el("h2", "", "💰 Cost"));
  if (!state.unlocked) {
    const area = el("div");
    const show = el("button", "btn small", "🔒 Show costs");
    show.type = "button";
    show.addEventListener("click", () => {
      show.remove();
      unlock(area, "Enter your PIN to see prices.");
    });
    costBox.append(el("p", "muted small", "Prices are private."), show, area);
    return;
  }

  // Priced the way the Groceries page is set: latest, cheapest, or one shop.
  const mode = state.priceMode;
  const cost = currentCost();
  // Missing prices first, so a partial cost is never mistaken for the whole.
  const counted = cost.lines.filter((l) => !l.optional);
  if (cost.unpriced.length) {
    const warn = el("div", "notice warn");
    warn.append(
      el("strong", "", `⚠️ Partial cost: ${cost.unpriced.length} of ${counted.length} ingredients have no price`),
      el("span", "", ` (${[...new Set(cost.unpriced)].join(", ")}), so the real cost is higher. `)
    );
    const add = el("a", "", "Add their prices →");
    add.href = priceLink(cost.lines.find((l) => !l.optional && l.cost === undefined));
    warn.append(add);
    costBox.append(warn);
  }
  const figures = el("div", "cost-figures");
  const making = el("div", "cost");
  // "+" after a figure means missing prices would add to it.
  const plus = cost.unpriced.length ? " +" : "";
  making.append(el("strong", "", `${money(cost.making)}${plus}`), el("span", "muted small", `to make ${state.servings} (packs to buy)`));
  const portion = el("div", "cost");
  portion.append(
    el("strong", "", `${cost.approx ? "≈ " : ""}${money(cost.portion * (cost.servings / state.servings || 1))}${plus}`),
    el("span", "muted small", cost.unpriced.length ? "per portion, without the missing prices" : "per portion")
  );
  figures.append(making, portion);
  costBox.append(figures);

  // Which prices: the same choice as on the Groceries page (remembered on this device).
  const shops = [...new Set(state.prices.map((p) => p.shop))].sort((a, b) => a.localeCompare(b));
  const select = el("select", "field small");
  select.setAttribute("aria-label", "Prices from");
  [["", "Latest prices"], ["cheapest", "Cheapest shop"], ...shops.map((s) => [s, `At ${s}`])].forEach(([v, t]) => {
    const o = el("option", "", t);
    o.value = v;
    select.append(o);
  });
  select.value = shops.includes(mode) || !mode || mode === "cheapest" ? mode : "";
  select.addEventListener("change", () => {
    state.priceMode = select.value;
    savePriceMode(select.value);
    renderIngredients();
    renderCost();
  });
  const row = el("div", "cost-mode");
  row.append(el("span", "muted small", "Prices:"), select);
  costBox.append(row);

  costBox.append(el("p", "muted small", "Each ingredient's cost is on its line above."));
  if (cost.approx) {
    costBox.append(el("p", "muted small", "≈ Some amounts are converted with typical kitchen weights (a tablespoon of tomato paste is about 17 g). The breakdown shows each one."));
  }
  if (!(Number(meal.servings) > 0)) costBox.append(el("p", "muted small", "≈ Servings aren't set, so the portion is the whole recipe."));

  // Line by line: how each amount compares with its pack, and what it costs.
  const details = el("details", "cost-breakdown");
  details.append(el("summary", "", "How it's worked out"));
  const table = el("table", "price-table");
  table.innerHTML = "<thead><tr><th>Ingredient</th><th>Amount</th><th>Of the pack</th><th>Cost</th></tr></thead>";
  const body = el("tbody");
  cost.lines.forEach((line) => {
    const tr = el("tr", line.optional ? "muted" : "");
    const name = el("td");
    name.append(line.name + (line.state ? `, ${line.state}` : ""));
    if (line.item && line.item.name !== line.name) name.append(el("small", "muted", ` (${line.item.name})`));
    const of = el("td");
    if (line.used) of.append(`${line.used} of ${line.pack}`);
    else if (line.pack) of.append(`whole ${line.pack}`);
    if (line.price) of.append(el("small", "muted", ` · ${money(line.price.price)} at ${line.price.shop}`));
    if (line.note) of.append(el("div", "muted small", line.note));
    const price = el("td", "num");
    if (line.cost !== undefined) price.append(money(line.cost));
    else if (!line.optional) price.append(linePrice(line));
    tr.append(name, el("td", "", line.qty || "—"), of, price);
    body.append(tr);
  });
  table.append(body);
  const wrap = el("div", "table-wrap");
  wrap.append(table);
  details.append(
    wrap,
    el("p", "muted small", "Wrong conversion? Set your own on the grocery item (Groceries → Items → ✏️ → Conversion, e.g. “1 tbsp = 18g”).")
  );
  costBox.append(details);

  const manage = el("a", "small", "Update prices →");
  manage.href = "groceries.html#prices";
  costBox.append(manage);
}

// An ingredient at the servings shown (so the breakdown matches the amounts on the page).
function scaledIngredient(ing) {
  if (typeof ing !== "object" || factor() === 1) return ing;
  return { ...ing, qty: scaleQty(ing.qty, factor()), swaps: ing.swaps?.map((s) => ({ ...s, qty: s.qty && scaleQty(s.qty, factor()) })) };
}

// [[Recipe name]] in a step or tip: a link to that recipe (or the plain name if it's not in the book).
function recipeLink(name) {
  const target = findRecipe(meals, name);
  if (!target) return name;
  const a = el("a", "", `${target.emoji} ${target.name}`);
  a.href = recipeUrl(target);
  return a;
}

// A tip as a list item, with **bold** and [[Recipe name]] links.
const withRecipeLinks = (text) => inline(el("li"), text, recipeLink);

// "Prep 10 · Cook 60 · Chill 60 min" when the recipe has the parts of its time.
function timeLine() {
  const parts = [
    ["Prep", meal.prep],
    ["Cook", meal.cook],
    ["Chill", meal.chill]
  ].filter(([, v]) => Number(v) > 0);
  if (!parts.length) return null;
  const fmt = (m) => (m >= 120 ? `${Math.round((m / 60) * 10) / 10} h` : `${m} min`);
  return parts.map(([label, v]) => `${label} ${fmt(Number(v))}`).join(" · ");
}

// ---------- Page ----------

function render() {
  root.innerHTML = "";
  document.title = meal.name;

  const head = el("div", "recipe-head");
  head.append(el("span", "recipe-emoji", meal.emoji));
  const titles = el("div");
  titles.append(el("h1", "", meal.name));
  if (meal.description) titles.append(el("p", "lede", meal.description));
  const tags = el("ul", "tags left");
  mealTags(meal, questions).forEach((t) => tags.append(el("li", "", t)));
  if (meal.onWheel === false) tags.append(el("li", "", "Not on the wheel"));
  if (!hasOwnRecipe(meal)) tags.append(el("li", "idea", "💡 Idea: not written yet"));
  titles.append(tags);
  const times = timeLine();
  if (times) titles.append(el("p", "muted small", `⏱ ${times}`));
  head.append(titles);
  root.append(head);

  const actions = el("div", "recipe-actions");
  const edit = el("a", "btn", "✏️ Edit");
  edit.href = `editor.html?id=${encodeURIComponent(meal.id)}`;
  actions.append(edit);
  if (!hasOwnRecipe(meal)) {
    const search = el("a", "btn ghost", "Find a recipe ↗");
    search.href = searchUrl(meal);
    search.target = "_blank";
    search.rel = "noopener";
    actions.append(search);
  }
  const plan = el("a", "btn ghost", "📅 Plan");
  plan.href = `plan.html?add=${encodeURIComponent(meal.id)}`;
  plan.title = "Put this recipe in the meal plan";

  // A PDF at the servings chosen below: shared to an app on a phone, opened in a tab on a computer.
  const share = el("button", "btn primary", "📤 Share PDF");
  share.type = "button";
  share.title = "Make a PDF of this recipe to send (WhatsApp…), download or print";
  sharePdfButton(share, () => ({ meal, meals, questions, factor: factor() }));

  // The recipe as an Excel workbook: readable on its own, and Settings → Import a recipe reads it back.
  const exportBtn = el("button", "btn ghost", "⬇ Excel");
  exportBtn.type = "button";
  exportBtn.title = "Download this recipe as an Excel file (you can also import it in Settings)";
  exportBtn.addEventListener("click", () =>
    attempt(exportBtn, async () => {
      const XLSX = await loadSheetJS();
      XLSX.writeFile(recipeWorkbook(XLSX, meal, meals, questions, location.origin), `${slugify(meal.name) || "recipe"}.xlsx`);
      notify(`⬇ ${meal.name} downloaded as Excel.`);
    })
  );
  actions.append(share, plan, exportBtn);
  root.append(actions);

  const layout = el("div", "recipe-layout");
  const side = el("div", "recipe-side");
  const main = el("div", "recipe-main");

  // Servings scaler (only when the recipe says how many it makes).
  if (baseServings) {
    const scaler = el("div", "servings");
    const minus = el("button", "icon-btn", "−");
    const plus = el("button", "icon-btn", "+");
    minus.type = plus.type = "button";
    minus.setAttribute("aria-label", "Fewer servings");
    plus.setAttribute("aria-label", "More servings");
    const count = el("strong", "", "");
    const update = () => {
      count.textContent = `🍽 ${state.servings} serving${state.servings === 1 ? "" : "s"}`;
      minus.disabled = state.servings <= 1;
      renderIngredients();
      if (state.unlocked) renderCost();
    };
    minus.addEventListener("click", () => {
      state.servings = Math.max(1, state.servings - 1);
      update();
    });
    plus.addEventListener("click", () => {
      state.servings += 1;
      update();
    });
    scaler.append(minus, count, plus);
    ingBox.append(scaler);
    update();
  }
  ingBox.append(ingList, el("p", "muted small screen-only", "＋🛒 puts an ingredient on your grocery list."), ingLock);
  renderIngredients();
  side.append(ingBox, costBox);
  renderCost();

  // Method and tips.
  const method = section("Method");
  if (hasOwnRecipe(meal)) {
    const ol = el("ol", "steps");
    meal.steps.forEach((s) => ol.append(stepItem(s, recipeLink)));
    method.append(ol);
  } else {
    method.append(el("p", "muted", "You haven't written this one yet."));
    const write = el("a", "btn small", "✏️ Write it");
    write.href = edit.href;
    method.append(write);
  }
  main.append(method);

  // A longer guide (like the sourdough timeline), written in simple Markdown.
  if (meal.notes?.trim()) {
    const guide = section("📘 Guide");
    guide.append(renderNotes(meal.notes, recipeLink));
    main.append(guide);
  }

  if (meal.tips?.length) {
    const tips = section("💡 Tips");
    const ul = el("ul", "tips");
    meal.tips.forEach((t) => ul.append(withRecipeLinks(t)));
    tips.append(ul);
    main.append(tips);
  }

  // Linked recipes both ways: what this uses, and what uses this.
  const links = (meal.links || []).map((l) => ({ ...l, target: meals.find((m) => m.id === l.id) })).filter((l) => l.target);
  const usedBy = meals.filter((m) => m.id !== meal.id && (m.links || []).some((l) => l.id === meal.id));
  if (links.length || usedBy.length) {
    const box = section("🔗 Goes with");
    const grid = el("div", "link-grid");
    links.forEach((l) => grid.append(linkCard(l.target, l.label)));
    usedBy.forEach((m) => grid.append(linkCard(m, "Used in")));
    box.append(grid);
    main.append(box);
  }

  layout.append(side, main);
  root.append(layout);

  // Already unlocked on this device: show costs and list state straight away.
  isUnlocked().then((yes) => yes && unlock(ingLock, "Enter your PIN to use the grocery list."));
}

if (meal) {
  render();
} else {
  root.innerHTML = "";
  root.append(el("h1", "", "Recipe not found"));
  const back = el("a", "btn", "← All recipes");
  back.href = "recipes.html";
  root.append(back);
}
