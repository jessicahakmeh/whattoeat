// Grocery list, grocery/household items, price history and a kitchen converter (PIN required).
//
// An item is on the list when `toPurchase` is true, with `packs` = how many to buy.
// While shopping, ticking an item sets `inCart`; "Done shopping" takes everything in the
// cart off the list (and counts it in `timesBought`, for "Buy again"). Changes show
// straight away and sync in the background, so the list keeps working with a weak signal.
// Prices follow the choice at the top (latest, cheapest, or one shop), remembered on this
// device and shared with recipe costs and the meal plan.
import { el, words, notify, friendlyError, trackWrite } from "./menu.js";
import { requireUnlock, lock } from "./vault.js";
import {
  CATEGORIES,
  SHOPS,
  LBP_RATE,
  fromLbp,
  categoryInfo,
  categoryOrder,
  guessCategory,
  latestPrices,
  cheapestPrices,
  shopPrices,
  pricePicker,
  savedPriceMode,
  savePriceMode,
  priceModeLabel,
  findItem,
  unitPrice,
  watchQty,
  money
} from "./cost.js";
import { parseQty, convert, splitAmount, formatAmount, conversionProblem, countedByPiece } from "./units.js";

const app = document.getElementById("app");
await requireUnlock(app, "Enter your PIN to open the grocery list.");
const store = await import("./store.js");

const pref = (k, fallback = "") => {
  try {
    return localStorage.getItem(k) ?? fallback;
  } catch {
    return fallback;
  }
};
const setPref = (k, v) => {
  try {
    localStorage.setItem(k, v);
  } catch {
    // Not remembered on this device; that's fine.
  }
};

const TABS = ["list", "items", "prices", "convert"];
// A recipe's "add price" link: ?price=<item id> or ?item=<name of an item you don't have yet>.
const params = new URLSearchParams(location.search);
let arrivedForPrice = params.has("price") || params.has("item");
const state = {
  items: [],
  latest: [], // latest price of each item at each shop (the summary: 1 read)
  history: null, // every price, loaded when the Prices tab opens
  tab: params.has("price") || params.has("item") ? "prices" : TABS.includes(location.hash.slice(1)) ? location.hash.slice(1) : "list",
  search: "",
  // Category chip per tab: "" = all, "kind:food" / "kind:household", or a category name.
  category: { list: "", items: "" },
  priceItem: params.get("price") || "", // item id the price history is filtered to
  newPriceName: params.get("item") || "", // a name to start the price form with
  mode: savedPriceMode(), // "" latest, "cheapest", or a shop
  hideTicked: pref("wte-hide-ticked") === "1",
  convertText: ""
};
let pick = () => undefined; // itemId -> price record, for the chosen mode (set in render)

async function reload() {
  try {
    [state.items, state.latest] = await Promise.all([store.loadItems(), store.loadLatestPrices()]);
    state.history = null;
  } catch (err) {
    notify(friendlyError(err), "error");
  }
  render();
}

let loadingHistory = null;
function loadHistory() {
  loadingHistory ||= store
    .loadPrices()
    .then((prices) => {
      state.history = prices;
    })
    .catch((err) => notify(friendlyError(err), "error"))
    .finally(() => {
      loadingHistory = null;
      if (state.tab === "prices") render();
    });
}

// Keeps the summary in step with a price added or deleted on this page.
function setLatest(key, record) {
  state.latest = state.latest.filter((p) => store.shopKey(p) !== key);
  if (record) state.latest.push(record);
}

// Saves in the background; on failure, says so and reloads the real state.
function sync(promise) {
  trackWrite(promise).catch((err) => {
    console.error(err);
    notify(friendlyError(err), "error");
    reload();
  });
}

const key = (s) => words(s).join(" ");
// An item by its name, else by one of its other names ("dish soap" is Dishwashing liquid).
const findByName = (name) => {
  const k = key(name);
  if (!k) return undefined;
  return state.items.find((i) => key(i.name) === k) || state.items.find((i) => String(i.aliases || "").split(",").some((a) => key(a) === k));
};
const itemById = (id) => state.items.find((i) => i.id === id);
const packs = (item) => (Number(item.packs) > 0 ? Number(item.packs) : 1);
const onList = () => state.items.filter((i) => i.toPurchase);
const shopsKnown = () => [...new Set([...SHOPS, ...state.latest.map((p) => p.shop)])].sort((a, b) => a.localeCompare(b));

function update(item, changes) {
  Object.assign(item, changes);
  sync(store.updateItem(item.id, changes));
}

// Changes several items as one write, with an Undo that puts them back.
function updateMany(list, changes, message) {
  const before = list.map((i) => [i, Object.fromEntries(Object.keys(changes(i)).map((k) => [k, i[k] ?? null]))]);
  const all = Object.fromEntries(list.map((i) => [i.id, changes(i)]));
  list.forEach((i) => Object.assign(i, all[i.id]));
  sync(store.updateItems(all));
  render();
  notify(message, "info", {
    label: "Undo",
    run: () => {
      const back = Object.fromEntries(before.map(([i, old]) => [i.id, old]));
      before.forEach(([i, old]) => Object.assign(i, old));
      sync(store.updateItems(back));
      render();
    }
  });
}

function create(data) {
  const created = store.createItem(data, state.items);
  state.items.push({ ...data, id: created.id });
  state.items.sort((a, b) => a.name.localeCompare(b.name));
  sync(created.done);
  return created.id;
}

function datalist(id, values) {
  const list = el("datalist");
  list.id = id;
  [...new Set(values.filter(Boolean))].forEach((v) => {
    const o = el("option");
    o.value = v;
    list.append(o);
  });
  return list;
}

function field(attrs = {}, value = "") {
  const i = el("input", "field");
  Object.assign(i, attrs);
  i.value = value;
  return i;
}

function categoryField(value = "") {
  const i = field({ placeholder: "Category" }, value);
  i.setAttribute("list", "allCategories");
  i.setAttribute("aria-label", "Category");
  i.classList.add("narrow");
  return i;
}

const categoryLabel = (name) => {
  const c = categoryInfo(name);
  return `${c.emoji} ${c.name}`;
};

// "$1.40 · Le Charcutier" (and per kg / L when it helps), or "no price yet".
function priceLabel(item, count = 1) {
  const p = pick(item.id);
  if (!p) return "no price yet";
  const per = unitPrice(p);
  const fallback = state.mode && state.mode !== "cheapest" && p.shop.toLowerCase() !== state.mode.toLowerCase();
  return [
    count > 1 ? `${money(p.price * count)} (${count} × ${money(p.price)})` : money(p.price),
    `${fallback ? "only at " : ""}${p.shop}`,
    p.qty && per && !/^1\s?(kg|l|pc)$/i.test(p.qty.replace(/\s/g, "")) ? `${p.qty} · ${money(per.value)}/${per.label}` : p.qty
  ]
    .filter(Boolean)
    .join(" · ");
}

// ---------- Prices from (shared by every tab) ----------

function priceModeBar(onChange) {
  const bar = el("div", "price-mode");
  bar.append(el("span", "muted small", "Prices from"));
  const select = el("select", "field small");
  select.setAttribute("aria-label", "Prices from");
  [["", "Latest anywhere"], ["cheapest", "Cheapest shop"], ...shopsKnown().map((s) => [s, s])].forEach(([v, t]) => {
    const o = el("option", "", t);
    o.value = v;
    select.append(o);
  });
  select.value = state.mode;
  select.addEventListener("change", () => {
    state.mode = select.value;
    savePriceMode(state.mode);
    onChange();
  });
  bar.append(select);
  return bar;
}

// ---------- Search and category chips ----------

const norm = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
// "tomatoes" also finds "tomato", "boxes" finds "box".
const stem = (t) => (t.length > 3 ? t.replace(/(es|s)$/, "") : t);

// How well an item fits the search: 0 name starts with it, 1 a word starts with it,
// 2 found in its other names or brand, 3 found anywhere (category, "food"/"household"); -1 no match.
function searchRank(item, query) {
  const terms = norm(query).split(/[^a-z0-9']+/).filter(Boolean).map(stem);
  if (!terms.length) return 0;
  const name = norm(item.name);
  const other = norm(`${item.aliases || ""} ${item.brand || ""}`);
  const info = categoryInfo(item.category);
  const hay = `${name} ${other} ${norm(info.name)} ${info.kind}`;
  if (!terms.every((t) => hay.includes(t))) return -1;
  if (name.startsWith(terms[0])) return 0;
  if (name.split(/[^a-z0-9']+/).some((w) => w.startsWith(terms[0]))) return 1;
  return other.includes(terms[0]) ? 2 : 3;
}

function search(list, query) {
  return list
    .map((item) => [item, searchRank(item, query)])
    .filter(([, rank]) => rank >= 0)
    .sort(([a, ra], [b, rb]) => ra - rb || a.name.localeCompare(b.name))
    .map(([item]) => item);
}

const activeCategory = () => state.category[state.tab] || "";

function inCategory(item, filter) {
  if (!filter) return true;
  const info = categoryInfo(item.category);
  return filter.startsWith("kind:") ? (info.kind === "household" ? "household" : "food") === filter.slice(5) : info.name === filter;
}

// All · Food · Household · one chip per category in `list`, with counts.
function categoryChips(list, onChange) {
  const row = el("div", "chips cat-chips");
  row.setAttribute("role", "group");
  row.setAttribute("aria-label", "Filter by category");
  const kinds = [
    ["", "All"],
    ["kind:food", "🍎 Food"],
    ["kind:household", "🏠 Household"]
  ];
  const cats = groupByCategory(list).map(([name, group]) => [name, categoryLabel(name), group.length]);
  const current = activeCategory();
  if (current && !kinds.some(([v]) => v === current) && !cats.some(([v]) => v === current)) state.category[state.tab] = "";
  [...kinds.map(([v, label]) => [v, label, list.filter((i) => inCategory(i, v)).length]), ...cats].forEach(([value, label, n]) => {
    if (value.startsWith("kind:") && !n) return;
    const chip = el("button", "chip", `${label} ${n}`);
    chip.type = "button";
    chip.setAttribute("aria-pressed", activeCategory() === value);
    chip.addEventListener("click", () => {
      state.category[state.tab] = activeCategory() === value && value ? "" : value;
      onChange();
    });
    row.append(chip);
  });
  return row;
}

function groupByCategory(list) {
  const groups = new Map();
  list.forEach((i) => {
    const name = categoryInfo(i.category).name;
    if (!groups.has(name)) groups.set(name, []);
    groups.get(name).push(i);
  });
  return [...groups.entries()].sort(([a], [b]) => categoryOrder(a, b));
}

// ---------- List tab ----------

// "2 milk" or "2x milk" -> 2 packs of milk; a name that starts with a number ("7up") stays whole.
function readAdd(text) {
  const t = text.trim();
  if (findByName(t)) return { count: 1, name: t };
  const m = t.match(/^(\d{1,2})\s*(?:x|×)?\s+(.+)$/i);
  return m ? { count: Number(m[1]), name: m[2].trim() } : { count: 1, name: t };
}

function addToList(item, count = 1, extra = {}) {
  const already = item.toPurchase;
  update(item, {
    toPurchase: true,
    inCart: false,
    packs: already ? packs(item) + count : count,
    category: item.category || guessCategory(item.name),
    ...extra
  });
  return already;
}

const refocus = () => app.querySelector(".add-row input")?.focus();

function chipFor(item, onAdd) {
  const chip = el("button", `chip${item.toPurchase ? " on" : ""}`, `＋ ${item.name}`);
  chip.type = "button";
  if (item.purchaseQty) chip.append(el("span", "muted", ` ${item.purchaseQty}`));
  const p = pick(item.id);
  if (p) chip.append(el("span", "muted", ` · ${money(p.price)}`));
  if (item.toPurchase) chip.append(el("span", "muted", ` · on list ×${packs(item)}`));
  chip.addEventListener("click", () => onAdd(item));
  return chip;
}

function renderList(panel) {
  // One box: type a name (with an optional count first), pick a match or press Add.
  const form = el("form", "add-row quick-add");
  const name = field({ placeholder: "Add… try “2 milk” or “dish soap”", required: true, autocomplete: "off" });
  name.setAttribute("aria-label", "Item to add (you can start with how many)");
  const add = el("button", "btn primary", "Add");
  add.type = "submit";
  form.append(name, add);

  // Pack size and category only when you want them (new items get a guessed category).
  const more = el("details", "add-more");
  more.append(el("summary", "small muted", "Pack size & category"));
  const qty = watchQty(field({ placeholder: "Pack size (1L, 500g)" }));
  qty.classList.add("narrow");
  qty.setAttribute("aria-label", "Pack size");
  const cat = categoryField();
  const moreRow = el("div", "add-row");
  moreRow.append(qty, cat);
  more.append(moreRow);

  const suggestions = el("div", "chips suggestions");
  suggestions.setAttribute("aria-label", "Matching items");
  const quickAdd = (item, count = 1) => {
    const again = addToList(item, count);
    notify(`🛒 ${item.name} ${again ? `×${packs(item)}` : "added"}`);
    render();
    refocus();
  };
  const suggest = () => {
    suggestions.innerHTML = "";
    const { count, name: text } = readAdd(name.value);
    const exact = findByName(text);
    add.textContent = !text || exact ? "Add" : "＋ New item";
    if (!text) return renderQuick();
    search(state.items, text)
      .slice(0, 8)
      .forEach((item) => suggestions.append(chipFor(item, (i) => quickAdd(i, count))));
  };
  // With nothing typed: what you buy most often (and aren't getting yet).
  const renderQuick = () => {
    const again = state.items
      .filter((i) => !i.toPurchase && Number(i.timesBought) > 0)
      .sort((a, b) => Number(b.timesBought) - Number(a.timesBought) || (b.lastBought || 0) - (a.lastBought || 0))
      .slice(0, 10);
    if (!again.length) return;
    suggestions.append(el("span", "muted small", "Buy again:"));
    again.forEach((item) => suggestions.append(chipFor(item, (i) => quickAdd(i))));
  };
  name.addEventListener("input", suggest);
  name.addEventListener("change", () => {
    const existing = findByName(readAdd(name.value).name);
    if (existing) {
      cat.value = existing.category || "";
      if (!qty.value) qty.value = existing.purchaseQty || "";
    } else if (!cat.value) {
      cat.value = guessCategory(readAdd(name.value).name);
    }
  });
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const { count, name: text } = readAdd(name.value);
    if (!text) return;
    const existing = findByName(text);
    if (existing) {
      const extra = {};
      if (qty.value.trim()) extra.purchaseQty = qty.value.trim();
      if (cat.value.trim()) extra.category = cat.value.trim();
      quickAdd(existing, count);
      if (Object.keys(extra).length) update(existing, extra);
      return;
    }
    create({ name: text, purchaseQty: qty.value.trim(), category: cat.value.trim() || guessCategory(text), toPurchase: true, packs: count });
    notify(`🛒 ${text} added (new item)`);
    render();
    refocus();
  });
  panel.append(form, more, suggestions);
  suggest();

  const list = onList();
  if (!list.length) {
    panel.append(el("p", "muted", "Your list is empty. Type above to find an item, use ＋🛒 next to an ingredient on a recipe, or build it from the 📅 meal plan."));
    return;
  }

  // Progress while shopping, and the option to hide what's already in the cart.
  const ticked = list.filter((i) => i.inCart).length;
  const progress = el("div", "list-progress");
  const bar = el("div", "progress");
  bar.setAttribute("role", "progressbar");
  bar.setAttribute("aria-valuemin", "0");
  bar.setAttribute("aria-valuemax", String(list.length));
  bar.setAttribute("aria-valuenow", String(ticked));
  bar.setAttribute("aria-label", "In the cart");
  const fill = el("span");
  fill.style.width = `${Math.round((ticked / list.length) * 100)}%`;
  bar.append(fill);
  const hide = el("label", "small");
  const hideBox = el("input");
  hideBox.type = "checkbox";
  hideBox.checked = state.hideTicked;
  hideBox.addEventListener("change", () => {
    state.hideTicked = hideBox.checked;
    setPref("wte-hide-ticked", state.hideTicked ? "1" : "0");
    render();
  });
  hide.append(hideBox, " Hide what's in the cart");
  progress.append(el("strong", "", `${ticked} of ${list.length} in the cart`), bar, hide);
  panel.append(progress, categoryChips(list, render));

  const shown = list.filter((i) => inCategory(i, activeCategory()) && !(state.hideTicked && i.inCart));
  if (!shown.length) panel.append(el("p", "muted", state.hideTicked ? "Everything here is in the cart. 🎉" : "Nothing in this category."));
  groupByCategory(shown).forEach(([category, group]) => {
    const done = group.filter((i) => i.inCart).length;
    panel.append(el("h2", "group-title", `${categoryLabel(category)}${done ? ` · ${done}/${group.length}` : ""}`));
    const ul = el("ul", "grocery-list");
    // Still to get first; ticked ones sink to the bottom of their aisle.
    [...group].sort((a, b) => Number(Boolean(a.inCart)) - Number(Boolean(b.inCart)) || a.name.localeCompare(b.name)).forEach((item) => ul.append(listRow(item)));
    panel.append(ul);
  });

  const footer = el("div", "list-footer");
  footer.id = "listFooter";
  panel.append(footer);
  renderFooter(footer);
}

function listRow(item) {
  const li = el("li", item.inCart ? "in-cart" : "");
  const label = el("label");
  const box = el("input");
  box.type = "checkbox";
  box.checked = Boolean(item.inCart);
  box.setAttribute("aria-label", `${item.name} is in the cart`);
  box.addEventListener("change", () => {
    update(item, { inCart: box.checked });
    // Let the tick show before the row moves.
    setTimeout(render, state.hideTicked ? 250 : 400);
  });
  const text = el("span", "item-text");
  text.append(el("strong", "", item.name));
  const sub = [item.purchaseQty, item.brand].filter(Boolean).join(" · ");
  if (sub) text.append(el("span", "muted small", ` ${sub}`));
  label.append(box, text);
  li.append(label);

  // How many packs to buy.
  const stepper = el("span", "stepper");
  const minus = el("button", "icon-btn", "−");
  const plus = el("button", "icon-btn", "+");
  minus.type = plus.type = "button";
  minus.setAttribute("aria-label", `Fewer ${item.name}`);
  plus.setAttribute("aria-label", `More ${item.name}`);
  const count = el("span", "count", `×${packs(item)}`);
  minus.disabled = packs(item) <= 1;
  minus.addEventListener("click", () => {
    update(item, { packs: Math.max(1, packs(item) - 1) });
    render();
  });
  plus.addEventListener("click", () => {
    update(item, { packs: packs(item) + 1 });
    render();
  });
  stepper.append(minus, count, plus);
  li.append(stepper, el("span", "muted small price-note", priceLabel(item, packs(item))));

  const remove = el("button", "icon-btn", "×");
  remove.type = "button";
  remove.setAttribute("aria-label", `Take ${item.name} off the list`);
  remove.addEventListener("click", () => updateMany([item], () => ({ toPurchase: false, inCart: false, packs: 1 }), `${item.name} taken off the list.`));
  li.append(remove);
  return li;
}

// The list as text, by aisle, for WhatsApp or the clipboard.
function listText() {
  const lines = ["🛒 Grocery list"];
  groupByCategory(onList().filter((i) => !i.inCart)).forEach(([category, group]) => {
    lines.push("", categoryLabel(category));
    group.forEach((i) => lines.push(`• ${i.name}${packs(i) > 1 ? ` ×${packs(i)}` : ""}${i.purchaseQty ? ` (${i.purchaseQty})` : ""}`));
  });
  return lines.join("\n");
}

async function shareList() {
  const text = listText();
  if (navigator.share) {
    try {
      await navigator.share({ title: "Grocery list", text });
      return;
    } catch (err) {
      if (err?.name === "AbortError") return; // closing the share sheet isn't an error
    }
  }
  window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank", "noopener");
}

// Budget at the chosen prices, what's left to buy, and the same list at each shop.
function renderFooter(footer = document.getElementById("listFooter")) {
  if (!footer) return;
  footer.innerHTML = "";
  const list = onList();
  const cost = (i) => (pick(i.id)?.price || 0) * packs(i);
  const total = list.reduce((sum, i) => sum + cost(i), 0);
  const left = list.filter((i) => !i.inCart).reduce((sum, i) => sum + cost(i), 0);
  const unpriced = list.filter((i) => !pick(i.id)).length;

  const budget = el("div", "budget");
  budget.append(el("strong", "", `Budget: ${money(total)}`));
  const notes = [`${list.length} item${list.length === 1 ? "" : "s"} at ${priceModeLabel(state.mode)}`];
  if (left > 0.005 && left < total - 0.005) notes.push(`${money(left)} still to get`);
  if (unpriced) notes.push(`${unpriced} without a price`);
  budget.append(el("span", "muted small", notes.join(" · ")));

  // Each shop: the total of what it has a price for. Tap one to use its prices.
  const compare = el("div", "chips shop-compare");
  const cheapest = cheapestPrices(state.latest);
  const best = list.reduce((sum, i) => sum + (cheapest.get(i.id)?.price || 0) * packs(i), 0);
  const shopTotals = shopsKnown()
    .map((shop) => {
      const at = shopPrices(state.latest, shop);
      const have = list.filter((i) => at.has(i.id));
      return { shop, n: have.length, total: have.reduce((s, i) => s + at.get(i.id).price * packs(i), 0) };
    })
    .filter((s) => s.n);
  shopTotals.forEach(({ shop, n, total: t }) => {
    const chip = el("button", "chip", `${shop} ${money(t)}`);
    chip.type = "button";
    chip.append(el("span", "muted", ` · ${n}/${list.length}`));
    chip.title = `${n} of the ${list.length} items have a price at ${shop}`;
    chip.setAttribute("aria-pressed", state.mode === shop);
    chip.addEventListener("click", () => {
      state.mode = state.mode === shop ? "" : shop;
      savePriceMode(state.mode);
      render();
    });
    compare.append(chip);
  });
  if (shopTotals.length > 1 && best > 0) {
    const chip = el("button", "chip", `Cheapest mix ${money(best)}`);
    chip.type = "button";
    chip.setAttribute("aria-pressed", state.mode === "cheapest");
    chip.addEventListener("click", () => {
      state.mode = state.mode === "cheapest" ? "" : "cheapest";
      savePriceMode(state.mode);
      render();
    });
    compare.append(chip);
  }

  const actions = el("div", "footer-actions");
  const done = el("button", "btn primary", "✓ Done shopping");
  done.type = "button";
  done.disabled = !list.some((i) => i.inCart);
  done.addEventListener("click", () => {
    const bought = list.filter((i) => i.inCart);
    const now = Date.now();
    updateMany(
      bought,
      (i) => ({ toPurchase: false, inCart: false, packs: 1, timesBought: (Number(i.timesBought) || 0) + 1, lastBought: now }),
      `✓ ${bought.length} bought item${bought.length === 1 ? "" : "s"} taken off the list.`
    );
  });
  const share = el("button", "btn ghost", "📤 Share");
  share.type = "button";
  share.title = "Send what's left to buy (WhatsApp, Notes…)";
  share.addEventListener("click", shareList);
  const clear = el("button", "btn ghost danger", "Empty list");
  clear.type = "button";
  clear.addEventListener("click", () => {
    if (!confirm(`Take all ${list.length} items off the list?`)) return;
    updateMany(list, () => ({ toPurchase: false, inCart: false, packs: 1 }), "The list is empty.");
  });
  actions.append(done);
  // Only the budget and "Done shopping" stay pinned; comparing shops and sharing sit under the list.
  footer.append(budget, actions);
  const extras = el("div", "list-extras");
  if (compare.children.length) extras.append(el("p", "muted small", "The same list at each shop (tap one to use its prices):"), compare);
  const more = el("div", "footer-actions");
  more.append(share, clear);
  extras.append(more);
  footer.before(extras);
}

// ---------- Items tab ----------

function itemEditor(item, row) {
  const form = el("form", "edit-row item-edit");
  const name = field({ required: true }, item.name);
  name.setAttribute("aria-label", "Name");
  const qty = watchQty(field({ placeholder: "Pack size (1kg)" }, item.purchaseQty || ""));
  qty.classList.add("narrow");
  qty.setAttribute("aria-label", "Pack size");
  const cat = categoryField(item.category || "");
  const brand = field({ placeholder: "Brand (optional)" }, item.brand || "");
  brand.setAttribute("aria-label", "Brand");
  const aliases = field({ placeholder: "Other names: kammoun, cumin seeds…" }, item.aliases || "");
  aliases.setAttribute("aria-label", "Other names to search by, separated by commas");
  const conversion = field({ placeholder: "Conversion: 1 tbsp = 16g; 1 pc = 150g" }, item.conversion || "");
  conversion.setAttribute("aria-label", "How much a spoon or piece weighs");
  const checkConversion = () => {
    const problem = conversionProblem(conversion.value);
    conversion.classList.toggle("unclear", Boolean(problem));
    conversion.title = problem || "Used to cost recipes that measure this by the spoon, cup or piece.";
  };
  conversion.addEventListener("input", checkConversion);
  checkConversion();
  const save = el("button", "btn small primary", "Save");
  save.type = "submit";
  const del = el("button", "btn small ghost danger", "Delete");
  del.type = "button";
  const cancel = el("button", "btn small ghost", "Cancel");
  cancel.type = "button";
  const extra = el("div", "item-edit-extra");
  extra.append(brand, aliases, conversion);
  form.append(name, qty, cat, save, del, cancel, extra);
  cancel.addEventListener("click", render);
  del.addEventListener("click", () => {
    if (!confirm(`Delete ${item.name}? Recipes that use it will show it as unpriced.`)) return;
    state.items = state.items.filter((i) => i !== item);
    sync(store.deleteItem(item.id));
    render();
  });
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const newName = name.value.trim();
    if (!newName) return;
    const clash = findByName(newName);
    if (clash && clash !== item) {
      alert(`There's already an item called ${clash.name}.`);
      return;
    }
    update(item, {
      name: newName,
      purchaseQty: qty.value.trim(),
      category: cat.value.trim() || "Other",
      brand: brand.value.trim(),
      aliases: aliases.value.trim(),
      conversion: conversion.value.trim()
    });
    render();
  });
  row.replaceWith(form);
  name.focus();
}

function renderItems(panel) {
  const tools = el("div", "toolbar");
  const box = field({ type: "search", placeholder: "Search items, local names or brands (kammoun, javel, Chtaura…)" }, state.search);
  box.setAttribute("aria-label", "Search items");
  // Only the results redraw while typing, so the search box keeps focus.
  const results = el("div");
  box.addEventListener("input", () => {
    state.search = box.value;
    renderItemResults(results);
  });
  tools.append(box);
  panel.append(tools);

  const form = el("form", "add-row");
  const name = field({ placeholder: "New item", required: true });
  name.setAttribute("aria-label", "New item");
  const qty = watchQty(field({ placeholder: "Pack size (1kg, 6pcs)" }));
  qty.classList.add("narrow");
  qty.setAttribute("aria-label", "Pack size");
  const cat = categoryField();
  name.addEventListener("change", () => {
    if (!cat.value) cat.value = guessCategory(name.value);
  });
  const add = el("button", "btn", "＋ Add item");
  add.type = "submit";
  form.append(name, qty, cat, add);
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = name.value.trim();
    if (!text) return;
    if (findByName(text)) {
      alert("That item already exists.");
      return;
    }
    create({ name: text, purchaseQty: qty.value.trim(), category: cat.value.trim() || guessCategory(text), toPurchase: false, packs: 1 });
    render();
  });
  panel.append(form, results);
  renderItemResults(results);
}

function renderItemResults(results) {
  results.innerHTML = "";
  const found = search(state.items, state.search);
  results.append(categoryChips(found, () => renderItemResults(results)));
  const shown = found.filter((i) => inCategory(i, activeCategory()));
  results.append(el("p", "muted small", `${shown.length} item${shown.length === 1 ? "" : "s"} · tick one to put it on the list`));
  if (!shown.length && state.search.trim()) {
    results.append(el("p", "muted", `Nothing called “${state.search.trim()}” yet. Add it above.`));
  }

  // While searching, the best matches come first; otherwise items are grouped by category.
  const groups = state.search.trim() ? [["", shown]] : groupByCategory(shown);
  groups.forEach(([category, group]) => {
    if (category) results.append(el("h2", "group-title", categoryLabel(category)));
    const ul = el("ul", "grocery-list items");
    group.forEach((item) => {
      const li = el("li");
      const label = el("label");
      const box = el("input");
      box.type = "checkbox";
      box.checked = Boolean(item.toPurchase);
      box.setAttribute("aria-label", `${item.name} on the grocery list`);
      box.addEventListener("change", () => {
        update(item, { toPurchase: box.checked, inCart: false, packs: 1 });
        renderTabs();
      });
      const text = el("span", "item-text");
      text.append(el("strong", "", item.name));
      const sub = [item.purchaseQty, item.brand].filter(Boolean).join(" · ");
      if (sub) text.append(el("span", "muted", ` ${sub}`));
      if (!category) text.append(el("span", "muted small", ` · ${categoryLabel(item.category)}`));
      if (item.aliases && state.search.trim() && !norm(item.name).includes(norm(state.search.trim()))) {
        text.append(el("span", "muted small", ` (${item.aliases})`));
      }
      label.append(box, text);
      li.append(label);

      const history = el("button", "link-btn small", priceLabel(item));
      history.type = "button";
      history.title = "Price history";
      history.addEventListener("click", () => showPrices(item.id));
      li.append(history);

      const edit = el("button", "icon-btn", "✏️");
      edit.type = "button";
      edit.setAttribute("aria-label", `Edit ${item.name}`);
      edit.addEventListener("click", () => itemEditor(item, li));
      li.append(edit);
      ul.append(li);
    });
    results.append(ul);
  });
}

// ---------- Prices tab ----------

function showPrices(itemId) {
  state.priceItem = itemId;
  state.tab = "prices";
  history.replaceState(null, "", "#prices");
  render();
}

function renderPrices(panel) {
  panel.append(el("p", "muted small", `Add a price whenever you see one; type it in dollars or in LBP (converted at ${LBP_RATE.toLocaleString()} LBP per $). Recipes and the list use the prices chosen at the top.`));

  const form = el("form", "add-row price-form");
  const item = field({ placeholder: "Item", required: true }, itemById(state.priceItem)?.name || state.newPriceName || "");
  item.setAttribute("list", "allItems");
  item.setAttribute("aria-label", "Item");
  const shop = field({ placeholder: "Shop", required: true }, pref("wte-last-shop"));
  shop.setAttribute("list", "allShops");
  shop.setAttribute("aria-label", "Shop");
  const price = field({ type: "number", step: "any", min: "0", placeholder: "Price", required: true });
  price.classList.add("narrow");
  price.setAttribute("aria-label", "Price");
  const currency = el("select", "field small");
  currency.setAttribute("aria-label", "Currency");
  [["usd", "$"], ["lbp", "LBP"]].forEach(([v, t]) => {
    const o = el("option", "", t);
    o.value = v;
    currency.append(o);
  });
  currency.value = pref("wte-currency", "usd");
  const inDollars = el("span", "muted small");
  const showDollars = () => {
    inDollars.textContent = currency.value === "lbp" && Number(price.value) > 0 ? `= ${money(fromLbp(Number(price.value)))}` : "";
  };
  price.addEventListener("input", showDollars);
  currency.addEventListener("change", () => {
    setPref("wte-currency", currency.value);
    showDollars();
  });
  const qty = watchQty(field({ placeholder: "Qty (1kg)" }, itemById(state.priceItem)?.purchaseQty || ""));
  qty.classList.add("narrow");
  qty.setAttribute("aria-label", "Quantity");
  const date = field({ type: "date" }, new Date().toISOString().slice(0, 10));
  date.setAttribute("aria-label", "Date");
  const add = el("button", "btn primary", "Add price");
  add.type = "submit";
  form.append(item, shop, price, currency, inDollars, qty, date, add);
  item.addEventListener("change", () => {
    const existing = findByName(item.value);
    if (existing && !qty.value) qty.value = existing.purchaseQty || "";
  });
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const typed = Number(price.value);
    if (!item.value.trim() || !shop.value.trim() || price.value === "" || !(typed >= 0)) {
      notify("Fill in the item, shop and price.", "error");
      return;
    }
    const lbp = currency.value === "lbp";
    const amount = lbp ? fromLbp(typed) : typed;
    let target = findByName(item.value);
    if (!target) {
      const name = item.value.trim();
      const id = create({ name, purchaseQty: qty.value.trim(), category: guessCategory(name), toPurchase: false, packs: 1 });
      target = itemById(id);
    }
    setPref("wte-last-shop", shop.value.trim());
    // A past date keeps its order in the history; today uses the current time.
    const today = new Date().toISOString().slice(0, 10);
    const when = date.value && date.value !== today ? new Date(`${date.value}T12:00:00`).getTime() : Date.now();
    const added = store.addPrice(
      {
        itemId: target.id,
        item: target.name,
        price: amount,
        ...(lbp && { lbp: typed }),
        shop: shop.value.trim(),
        qty: qty.value.trim() || target.purchaseQty || "",
        date: when
      },
      state.latest
    );
    if (added.newest) setLatest(store.shopKey(added.entry), added.entry);
    state.history?.unshift(added.entry);
    state.history?.sort((a, b) => b.date - a.date);
    sync(added.done);
    state.priceItem = target.id;
    state.newPriceName = "";
    notify(`💲 ${target.name}: ${money(amount)} at ${shop.value.trim()}`);
    render();
  });
  panel.append(form);
  // Arrived from a recipe's "add price": the item's filled in, so start at the shop or price.
  if (arrivedForPrice) {
    arrivedForPrice = false;
    setTimeout(() => (shop.value ? price : shop).focus(), 0);
  }
  if (/recipe\.html/.test(document.referrer) && (params.has("price") || params.has("item"))) {
    const back = el("button", "link-btn small", "← Back to the recipe");
    back.type = "button";
    back.addEventListener("click", () => history.back());
    panel.append(back);
  }

  if (!state.history) {
    panel.append(el("p", "muted", "Loading the price history…"));
    loadHistory();
    return;
  }

  // Filter: one item's history, or everything.
  const tools = el("div", "toolbar");
  const filter = el("select", "field");
  filter.setAttribute("aria-label", "Show prices for");
  filter.append(el("option", "", "All items"));
  filter.firstChild.value = "";
  const priced = [...new Set(state.history.map((p) => p.itemId))]
    .map((id) => itemById(id) || { id, name: state.history.find((p) => p.itemId === id).item })
    .sort((a, b) => a.name.localeCompare(b.name));
  priced.forEach((i) => {
    const o = el("option", "", i.name);
    o.value = i.id;
    filter.append(o);
  });
  filter.value = state.priceItem;
  filter.addEventListener("change", () => {
    state.priceItem = filter.value;
    render();
  });
  tools.append(filter);
  panel.append(tools);

  const rows = state.history.filter((p) => !state.priceItem || p.itemId === state.priceItem);
  if (!rows.length) {
    panel.append(
      el(
        "p",
        "muted",
        state.priceItem
          ? "No prices for this item yet."
          : "No prices yet. ⚙️ Settings → Add shop prices fills in Le Charcutier and Carrefour prices for the common items."
      )
    );
    return;
  }

  // One item: each shop's latest price side by side, cheapest first (per kg / L when sizes differ).
  if (state.priceItem) {
    const perShop = new Map();
    rows.forEach((p) => {
      const k = p.shop.trim().toLowerCase();
      if (!perShop.has(k) || p.date > perShop.get(k).date) perShop.set(k, p);
    });
    const cmp = (p) => unitPrice(p)?.value ?? p.price;
    const summary = el("div", "cost-figures");
    [...perShop.values()]
      .sort((a, b) => cmp(a) - cmp(b))
      .forEach((p, i) => {
        const t = el("div", "cost");
        const per = unitPrice(p);
        t.append(
          el("strong", "", money(p.price)),
          el("span", "muted small", `${i === 0 && perShop.size > 1 ? "🏷 cheapest · " : ""}${p.shop} · ${p.qty || ""}${per ? ` · ${money(per.value)}/${per.label}` : ""}`)
        );
        summary.append(t);
      });
    panel.append(summary);
  }

  const latestIds = new Set([...latestPrices(state.history).values()].map((p) => p.priceId));
  const table = el("table", "price-table");
  table.innerHTML = "<thead><tr><th>Date</th><th>Item</th><th>Shop</th><th>Qty</th><th>Price</th><th>Per unit</th><th></th></tr></thead>";
  const body = el("tbody");
  rows.forEach((p) => {
    const tr = el("tr", latestIds.has(p.priceId) ? "latest" : "");
    const per = unitPrice(p);
    const itemCell = el("td", "", p.item);
    if (p.product) itemCell.append(el("div", "muted small", p.product));
    const shopCell = el("td");
    if (p.url) {
      const a = el("a", "", `${p.shop} ↗`);
      a.href = p.url;
      a.target = "_blank";
      a.rel = "noopener";
      shopCell.append(a);
    } else shopCell.append(p.shop);
    if (p.note) shopCell.append(el("div", "muted small", p.note));
    const priceCell = el("td", "num", money(p.price));
    if (p.lbp) priceCell.append(el("div", "muted small", `${Number(p.lbp).toLocaleString()} LBP`));
    tr.append(el("td", "", new Date(p.date).toLocaleDateString()), itemCell, shopCell, el("td", "", p.qty || ""), priceCell, el("td", "num muted", per ? `${money(per.value)}/${per.label}` : ""));
    const td = el("td");
    const del = el("button", "icon-btn", "×");
    del.type = "button";
    del.setAttribute("aria-label", "Delete this price");
    del.addEventListener("click", () => {
      if (!confirm(`Delete ${p.item} at ${p.shop} (${money(p.price)})?`)) return;
      sync(store.deletePrice(p, state.history));
      state.history = state.history.filter((x) => x !== p);
      const k = store.shopKey(p);
      setLatest(k, state.history.find((x) => store.shopKey(x) === k));
      render();
    });
    td.append(del);
    tr.append(td);
    body.append(tr);
  });
  table.append(body);
  const wrap = el("div", "table-wrap");
  wrap.append(table);
  panel.append(el("p", "muted small", "Bold rows are the latest price for that item."), wrap);
}

// ---------- Convert tab ----------

const EXAMPLES = ["1 tbsp tomato paste", "1 cup flour", "2 onions", "a handful of parsley", "3 cloves garlic", "1/2 cup Egyptian rice", "4 tbsp lemon juice", "1 tsp cumin"];

function renderConvert(panel) {
  panel.append(el("p", "muted small", "Type an amount and an ingredient to see roughly what it weighs and what it costs from the pack you buy."));
  const form = el("form", "add-row");
  const input = field({ type: "search", placeholder: "1 tbsp tomato paste", autocomplete: "off" }, state.convertText);
  input.setAttribute("aria-label", "Amount and ingredient");
  form.append(input);
  form.addEventListener("submit", (e) => e.preventDefault());
  const examples = el("div", "chips suggestions");
  EXAMPLES.forEach((x) => {
    const chip = el("button", "chip", x);
    chip.type = "button";
    chip.addEventListener("click", () => {
      input.value = state.convertText = x;
      show();
    });
    examples.append(chip);
  });
  const out = el("div", "convert-out");
  const show = () => {
    state.convertText = input.value;
    out.innerHTML = "";
    out.append(convertResult(input.value));
  };
  input.addEventListener("input", show);
  panel.append(form, examples, out);
  show();
}

function convertResult(text) {
  const box = el("div");
  const { qty, name } = splitAmount(text);
  if (!text.trim()) return box;
  if (!name) {
    box.append(el("p", "muted", "Add the ingredient after the amount, like “1 tbsp tomato paste”."));
    return box;
  }
  const item = findItem({ item: name }, state.items) || search(state.items, name)[0];
  const label = item?.name || name;
  const juiced = /juice/i.test(name) ? "juiced" : "";
  const q = parseQty(qty || "1", label);
  if (!q) {
    box.append(el("p", "muted", `“${qty}” isn't an amount this can measure.`));
    return box;
  }
  const grams = convert(q, "g", label, item, juiced);
  const ml = q.unit !== "ml" ? convert(q, "ml", label, item) : null;
  // Pieces only for things you count (lemons for juice, onions), not "tomato paste".
  const fruit = juiced ? label.replace(/\s*juice\b/i, "") : label;
  const pieces = q.unit !== "pcs" && countedByPiece(fruit) ? convert(q, "pcs", label, item, juiced) : null;
  const head = el("div", "cost-figures");
  const tile = (value, caption) => {
    const t = el("div", "cost");
    t.append(el("strong", "", value), el("span", "muted small", caption));
    head.append(t);
  };
  if (grams) tile(`${grams.approx ? "≈ " : ""}${formatAmount(grams.amount, "g")}`, `${qty || "1"} ${label}`);
  if (ml && q.unit !== "g") tile(`≈ ${formatAmount(ml.amount, "ml")}`, "by volume");
  if (pieces && pieces.amount >= 0.1 && pieces.amount < 50) tile(`≈ ${formatAmount(pieces.amount, "pcs")}`, "medium-sized");
  if (!grams && !ml) box.append(el("p", "muted", `There's no typical weight for ${label} in that unit. Set one on the item (Items → ✏️ → Conversion).`));
  box.append(head);

  // What it costs, from the pack at the chosen prices.
  const price = item && pick(item.id);
  if (item && price) {
    const pack = parseQty(price.qty || item.purchaseQty);
    const need = pack?.amount > 0 ? convert(q, pack.unit, label, item, juiced) : null;
    if (need) {
      const cost = price.price * (need.amount / pack.amount);
      box.append(
        el("p", "", `${need.approx ? "≈ " : ""}${money(cost)}: ${formatAmount(need.amount, pack.unit)} of a ${price.qty || item.purchaseQty} pack at ${money(price.price)} (${price.shop}${price.product ? `, ${price.product}` : ""}).`)
      );
    }
  } else if (item) {
    box.append(el("p", "muted small", `${item.name} has no price yet.`));
  } else {
    box.append(el("p", "muted small", `No grocery item called “${name}”, so this uses a typical weight.`));
  }

  // The usual measures for this ingredient.
  const table = el("table", "price-table");
  table.innerHTML = "<thead><tr><th>Measure</th><th>Weight</th></tr></thead>";
  const body = el("tbody");
  ["1 tsp", "1 tbsp", "1/4 cup", "1/2 cup", "1 cup", "1 pc"].forEach((m) => {
    const r = convert(parseQty(m, label), "g", label, item, juiced);
    if (r) body.append(trRow(m === "1 pc" ? "1 piece" : m, `${r.approx ? "≈ " : ""}${formatAmount(r.amount, "g")}`));
  });
  table.append(body);
  if (body.children.length) {
    const wrap = el("div", "table-wrap");
    wrap.append(table);
    box.append(el("h3", "group-title", `Common measures of ${label}`), wrap);
  }

  // Know better? Save it on the item, so recipes use it.
  if (item && q.unit !== "g") {
    const form = el("form", "add-row");
    const unitText = qty.replace(/^[\d\s./½¼¾⅓⅔-]+/, "").trim() || "pc";
    const g = field({ type: "number", step: "any", min: "0", placeholder: "grams" });
    g.classList.add("narrow");
    g.setAttribute("aria-label", `Grams in 1 ${unitText} of ${item.name}`);
    const save = el("button", "btn small", "Save on the item");
    save.type = "submit";
    form.append(el("span", "small", `Weighed it? 1 ${unitText} of ${item.name} =`), g, el("span", "small", "g"), save);
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const grams1 = Number(g.value);
      if (!(grams1 > 0)) return;
      const rule = `1 ${unitText} = ${grams1}g`;
      const unit = parseQty(`1 ${unitText}`)?.unit;
      // Replace an earlier rule for the same unit, keep the others.
      const others = String(item.conversion || "")
        .split(/[;\n]/)
        .map((s) => s.trim())
        .filter((s) => s && parseQty(s.split("=")[0])?.unit !== unit);
      update(item, { conversion: [...others, rule].join("; ") });
      notify(`⚖️ ${item.name}: ${rule}. Recipes use it from now on.`);
      render();
    });
    box.append(form);
    if (item.conversion) box.append(el("p", "muted small", `Saved for ${item.name}: ${item.conversion}`));
  }
  return box;
}

const trRow = (a, b) => {
  const tr = el("tr");
  tr.append(el("td", "", a), el("td", "num", b));
  return tr;
};

// ---------- Page ----------

function renderTabs() {
  const tabs = document.getElementById("tabs");
  if (!tabs) return;
  tabs.innerHTML = "";
  const list = onList();
  const left = list.filter((i) => !i.inCart).length;
  [
    ["list", `🛒 List (${left === list.length ? list.length : `${left}/${list.length}`})`],
    ["items", `📦 Items (${state.items.length})`],
    ["prices", "💲 Prices"],
    ["convert", "⚖️ Convert"]
  ].forEach(([value, label]) => {
    const t = el("button", "tab", label);
    t.type = "button";
    t.setAttribute("role", "tab");
    t.setAttribute("aria-selected", state.tab === value);
    t.addEventListener("click", () => {
      state.tab = value;
      history.replaceState(null, "", `#${value}`);
      render();
    });
    tabs.append(t);
  });
}

function render() {
  pick = pricePicker(state.latest, state.mode);
  // Keep the page where it was (ticking an item redraws the list).
  const y = window.scrollY;
  app.innerHTML = "";
  const head = el("div", "page-head");
  head.append(el("h1", "", "Groceries"));
  const tools = el("div", "head-tools");
  tools.append(priceModeBar(render));
  const lockBtn = el("button", "btn ghost small", "🔒 Lock");
  lockBtn.type = "button";
  lockBtn.addEventListener("click", () => {
    lock();
    location.reload();
  });
  tools.append(lockBtn);
  head.append(tools);
  app.append(head);

  app.append(
    datalist("allItems", state.items.map((i) => i.name)),
    datalist("allShops", shopsKnown()),
    datalist("allCategories", [...CATEGORIES.map((c) => c.name), ...state.items.map((i) => i.category)])
  );

  const tabs = el("div", "tabs");
  tabs.id = "tabs";
  tabs.setAttribute("role", "tablist");
  app.append(tabs);
  renderTabs();

  const panel = el("section", "card tab-panel");
  ({ list: renderList, items: renderItems, prices: renderPrices, convert: renderConvert })[state.tab](panel);
  app.append(panel);
  window.scrollTo(0, y);
}

await reload();
