// Registers the service worker (sw.js), which makes the site installable ("Add to Home
// Screen") and lets it open offline.
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("sw.js").catch((err) => console.warn("Offline support unavailable:", err));
  });
}
