// Firebase setup shared by every page (Spark plan: Hosting + Firestore only, no Auth).
//
// The project config comes from Firebase Hosting's reserved /__/firebase/init.json,
// so nothing project-specific is hard-coded. Firestore keeps an offline copy in
// the browser, so the grocery list keeps working with a weak signal and syncs later.
// On localhost (firebase emulators:start) the app talks to the local emulator.
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  initializeFirestore,
  connectFirestoreEmulator,
  persistentLocalCache,
  persistentMultipleTabManager
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const res = await fetch("/__/firebase/init.json");
if (!res.ok) throw new Error("Firebase config not found. Serve the site with Firebase Hosting or the emulators.");

export const app = initializeApp(await res.json());
export const db = initializeFirestore(app, {
  localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() })
});

if (["localhost", "127.0.0.1"].includes(location.hostname)) {
  connectFirestoreEmulator(db, "127.0.0.1", 8080);
}
