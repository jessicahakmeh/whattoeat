// The recipe book: search and filter every recipe, and export them to Excel.
import {
  loadMenu,
  ingredientName,
  ingredientOptions,
  isOptional,
  hasOwnRecipe,
  optionMatches,
  plainTips,
  recipeUrl,
  words,
  attempt,
  notify,
  el
} from "./menu.js";
import { loadSheetJS } from "./recipe-excel.js";
import { isUnlocked, requireUnlock } from "./vault.js";
import { mealCost, money, savedPriceMode } from "./cost.js";

const $ = (id) => document.getElementById(id);
const els = {
  search: $("search"),
  written: $("written"),
  labels: $("labels"),
  fewIngredients: $("fewIngredients"),
  exportExcel: $("exportExcel"),
  summary: $("summary"),
  list: $("list")
};
let shown = [];

const { meals, questions } = await loadMenu();
const asList = (v) => (Array.isArray(v) ? v : v === undefined ? [] : [v]);

// Labels (Notion's "Recipe Type"), in the wheel question's order; labels used by recipes
// but missing from the question come last.
const labelQuestion = questions.find((q) => q.field === "labels");
const LABELS = [
  ...(labelQuestion?.options || []).filter((o) => o.value !== undefined).map((o) => ({ value: o.value, text: `${o.emoji} ${o.label}` })),
  ...[...new Set(meals.flatMap((m) => asList(m.labels)))]
    .filter((v) => !labelQuestion?.options.some((o) => o.value === v))
    .sort()
    .map((v) => ({ value: v, text: v }))
];
const labelText = (v) => LABELS.find((l) => l.value === v)?.text || v;

// Costs on the cards once the device is unlocked (prices are private): the portion price
// and how many ingredients have no price yet.
const pricing = { on: false, items: [], prices: [], costs: new Map() };
const costOf = (m) => {
  // Only written recipes have amounts; an idea's ingredients would all count as whole packs.
  if (!pricing.on || !hasOwnRecipe(m) || !(m.ingredients || []).length) return null;
  if (!pricing.costs.has(m.id)) pricing.costs.set(m.id, mealCost(m, pricing.items, pricing.prices, {}, savedPriceMode()));
  return pricing.costs.get(m.id);
};
async function startPricing() {
  const store = await import("./store.js");
  [pricing.items, pricing.prices] = await Promise.all([store.loadItems(), store.loadLatestPrices()]);
  pricing.on = true;
  pricing.costs.clear();
  if (!els.written.querySelector('[value="missing"]')) {
    const o = el("option", "", "⚠️ Missing prices");
    o.value = "missing";
    els.written.append(o);
  }
  showCosts.remove();
  render();
}
const showCosts = el("button", "btn small ghost", "💰 Show costs");
showCosts.type = "button";
const lockArea = el("div", "lock-area");
showCosts.addEventListener("click", () =>
  attempt(showCosts, async () => {
    await requireUnlock(lockArea, "Enter your PIN to see what each recipe costs.");
    lockArea.innerHTML = "";
    await startPricing();
  })
);
els.exportExcel.after(showCosts);
els.labels.before(lockArea);
isUnlocked().then((yes) => yes && startPricing().catch((err) => console.warn("Couldn't load prices.", err)));
let chosenLabel = "";
try {
  chosenLabel = sessionStorage.getItem("wte-label") || "";
} catch {
  // Storage blocked: start with every label.
}

function renderLabels() {
  els.labels.innerHTML = "";
  const chip = (value, text, n) => {
    const b = el("button", "chip", `${text} ${n}`);
    b.type = "button";
    b.setAttribute("aria-pressed", chosenLabel === value);
    b.addEventListener("click", () => {
      chosenLabel = chosenLabel === value ? "" : value;
      try {
        sessionStorage.setItem("wte-label", chosenLabel);
      } catch {
        // Not remembered; that's fine.
      }
      render();
    });
    els.labels.append(b);
  };
  chip("", "All", meals.length);
  LABELS.forEach((l) => {
    const n = meals.filter((m) => asList(m.labels).includes(l.value)).length;
    if (n) chip(l.value, l.text, n);
  });
}
const FEW = 5;
// Optional ingredients don't count towards "few ingredients".
const ingredientCount = (m) => (m.ingredients || []).filter((i) => !isOptional(i)).length;

function card(meal) {
  const a = el("a", "card recipe-card");
  a.href = recipeUrl(meal);
  const head = el("div", "pr-head");
  head.append(el("span", "pr-emoji", meal.emoji));
  const titles = el("div");
  titles.append(el("h3", "", meal.name));
  const badges = el("p", "badges");
  badges.append(hasOwnRecipe(meal) ? el("span", "badge ready", "📖 Written") : el("span", "badge idea", "💡 Idea"));
  if (meal.onWheel === false) badges.append(el("span", "badge", "Not on the wheel"));
  titles.append(badges);
  head.append(titles);
  a.append(head, el("p", "muted small", meal.description || ""));
  const cost = costOf(meal);
  if (cost) {
    const line = el("p", "card-cost small");
    line.append(el("strong", "", `💰 ${cost.approx ? "≈ " : ""}${money(cost.portion)}${cost.unpriced.length ? " +" : ""}`), " a portion");
    if (cost.unpriced.length) {
      const warn = el("span", "card-warn", ` · ⚠️ ${cost.unpriced.length} without a price`);
      warn.title = [...new Set(cost.unpriced)].join(", ");
      line.append(warn);
    }
    a.append(line);
  }
  const labels = asList(meal.labels);
  if (labels.length) {
    const ul = el("ul", "tags left");
    labels.forEach((l) => ul.append(el("li", "", labelText(l))));
    a.append(ul);
  }
  return a;
}

function render() {
  renderLabels();
  const terms = words(els.search.value);
  const written = els.written.value;
  shown = meals
    .filter((m) => !written || (written === "missing" ? costOf(m)?.unpriced.length > 0 : (written === "written") === hasOwnRecipe(m)))
    .filter((m) => !chosenLabel || asList(m.labels).includes(chosenLabel))
    .filter((m) => !els.fewIngredients.checked || ingredientCount(m) <= FEW)
    .filter((m) => {
      if (!terms.length) return true;
      const haystack = words([m.name, ...(m.ingredients || []).map(ingredientName)].join(" "));
      return terms.every((t) => haystack.some((w) => w.startsWith(t)));
    })
    .sort((a, b) => Number(hasOwnRecipe(b)) - Number(hasOwnRecipe(a)) || a.name.localeCompare(b.name));

  els.summary.textContent = `${shown.length} recipe${shown.length === 1 ? "" : "s"}`;
  els.exportExcel.textContent = `⬇ Export ${shown.length} to Excel`;
  els.exportExcel.disabled = !shown.length;
  els.list.innerHTML = "";
  shown.forEach((m) => els.list.append(card(m)));
}

// ---------- Excel export ----------

// The answer labels a recipe is tagged with for one question, e.g. "Vegan, Meat".
function questionLabels(meal, q) {
  const values = asList(meal[q.field]);
  const specific = q.options.filter((o) => !o.any);
  const labels = values.map((v) => {
    const opt = specific.find((o) => o.value === v) || specific.find((o) => optionMatches(o, { [q.field]: v }, q.field));
    return opt ? opt.label : String(v);
  });
  return [...new Set(labels)].join(", ");
}

const ingredientLine = (ing) => {
  const [main, ...swaps] = ingredientOptions(ing);
  const name = main.item + (swaps.length ? ` (or ${swaps.map((s) => s.item).join(", ")})` : "");
  return [main.qty, name + (ing.state ? `, ${ing.state}` : ""), isOptional(ing) && !/optional/i.test(main.item) ? "(optional)" : ""].filter(Boolean).join(" ");
};

function exportExcel() {
  return attempt(els.exportExcel, async () => {
    const XLSX = await loadSheetJS();
    const byId = new Map(meals.map((m) => [m.id, m]));
    // Tag columns: one per wheel question (time is covered by Minutes).
    const tagQuestions = questions.filter((q) => !q.options.some((o) => o.min !== undefined || o.max !== undefined));

    const recipeRows = shown.map((m) => {
      const row = {
        Name: m.name,
        Emoji: m.emoji || "",
        Description: m.description || "",
        Servings: Number(m.servings) || "",
        Minutes: typeof m.minutes === "number" ? m.minutes : "",
        "Prep (min)": Number(m.prep) || "",
        "Cook (min)": Number(m.cook) || "",
        "Chill (min)": Number(m.chill) || "",
        "On the wheel": m.onWheel === false ? "No" : "Yes",
        "Recipe written": hasOwnRecipe(m) ? "Yes" : "No"
      };
      tagQuestions.forEach((q) => (row[q.title] = questionLabels(m, q)));
      row.Ingredients = (m.ingredients || []).map(ingredientLine).join("\n");
      row.Steps = (m.steps || []).map((s, i) => `${i + 1}. ${s}`).join("\n");
      row.Tips = (m.tips || []).map(plainTips).join("\n");
      row["Goes with"] = (m.links || [])
        .map((l) => byId.get(l.id) && `${l.label ? `${l.label}: ` : ""}${byId.get(l.id).name}`)
        .filter(Boolean)
        .join("\n");
      row.Link = new URL(recipeUrl(m), location.href).href;
      return row;
    });

    // One row per ingredient, handy for filtering and shopping.
    const ingredientRows = shown.flatMap((m) =>
      (m.ingredients || []).map((ing) => {
        const [main, ...swaps] = ingredientOptions(ing);
        return {
          Recipe: m.name,
          Amount: main.qty || "",
          Ingredient: main.item,
          State: ing.state || "",
          Swaps: swaps.map((s) => s.item).join(", "),
          Optional: isOptional(ing) ? "Yes" : ""
        };
      })
    );

    const book = XLSX.utils.book_new();
    const recipesSheet = XLSX.utils.json_to_sheet(recipeRows);
    recipesSheet["!cols"] = Object.keys(recipeRows[0]).map((k) => ({
      wch: { Name: 28, Description: 50, Ingredients: 45, Steps: 60, Tips: 40, "Goes with": 30, Link: 45 }[k] || Math.max(10, k.length + 2)
    }));
    recipesSheet["!autofilter"] = { ref: recipesSheet["!ref"] };
    XLSX.utils.book_append_sheet(book, recipesSheet, "Recipes");

    if (ingredientRows.length) {
      const ingSheet = XLSX.utils.json_to_sheet(ingredientRows);
      ingSheet["!cols"] = [{ wch: 28 }, { wch: 12 }, { wch: 30 }, { wch: 16 }, { wch: 30 }, { wch: 10 }];
      ingSheet["!autofilter"] = { ref: ingSheet["!ref"] };
      XLSX.utils.book_append_sheet(book, ingSheet, "Ingredients");
    }

    XLSX.writeFile(book, `whattoeat-recipes-${new Date().toISOString().slice(0, 10)}.xlsx`);
    notify(`⬇ Exported ${shown.length} recipe${shown.length === 1 ? "" : "s"}.`);
  });
}

els.exportExcel.addEventListener("click", exportExcel);
els.search.addEventListener("input", render);
[els.written, els.fewIngredients].forEach((x) => x.addEventListener("change", render));
render();
