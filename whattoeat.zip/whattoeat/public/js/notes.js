// Simple Markdown for recipe text: **bold** and *italic* in steps and tips, and whole guides
// (headings, lists, quotes, tables, rules) in a recipe's notes. Builds DOM nodes only, so
// nothing in the text can run as HTML.
import { el } from "./menu.js";

// Appends `text` to `node`, with **bold**, *italic* and [[Recipe]] links (via `link`).
export function inline(node, text, link) {
  const parts = String(text || "").split(/(\*\*[^*]+\*\*|\*[^*\s][^*]*\*|\[\[[^\]]+\]\])/);
  parts.forEach((part) => {
    if (!part) return;
    if (/^\*\*[^*]+\*\*$/.test(part)) node.append(el("strong", "", part.slice(2, -2)));
    else if (/^\*[^*]+\*$/.test(part)) node.append(el("em", "", part.slice(1, -1)));
    else if (/^\[\[[^\]]+\]\]$/.test(part)) node.append(link ? link(part.slice(2, -2)) : part.slice(2, -2));
    else node.append(part);
  });
  return node;
}

// A step as a list item: its first line, then any "- " lines as numbered sub-steps.
export function stepItem(step, link) {
  const [first, ...rest] = String(step).split("\n");
  const li = inline(el("li"), first, link);
  const subs = rest.map((s) => s.replace(/^\s*[-*•]\s*/, "").trim()).filter(Boolean);
  if (subs.length) {
    const ol = el("ol", "sub-steps");
    subs.forEach((s) => ol.append(inline(el("li"), s, link)));
    li.append(ol);
  }
  return li;
}

// The steps as written in the editor (one per line, "- " lines belong to the step above)
// and back.
export const stepsToText = (steps) => (steps || []).join("\n");
export function stepsFromText(text) {
  const out = [];
  String(text || "")
    .split("\n")
    .map((s) => s.trimEnd())
    .filter((s) => s.trim())
    .forEach((line) => {
      if (/^\s*[-•]\s+/.test(line) && out.length) out[out.length - 1] += `\n- ${line.replace(/^\s*[-•]\s+/, "").trim()}`;
      else out.push(line.trim());
    });
  return out;
}

const cells = (row) => row.trim().replace(/^\||\|$/g, "").split("|").map((c) => c.trim());

// A whole guide: # headings, paragraphs, - / • / 1. lists, > quotes, | tables |, ---.
export function renderNotes(markdown, link) {
  const box = el("div", "notes");
  const lines = String(markdown || "").replace(/\r/g, "").split("\n");
  let list = null;
  let listKind = "";
  const endList = () => {
    list = null;
    listKind = "";
  };
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const t = line.trim();
    if (!t) {
      endList();
      continue;
    }
    const heading = t.match(/^(#{1,4})\s+(.*)$/);
    if (heading) {
      endList();
      // Guides start at h3, under the page's own headings.
      box.append(inline(el(`h${Math.min(6, heading[1].length + 2)}`), heading[2].replace(/^\*\*(.*)\*\*$/, "$1"), link));
      continue;
    }
    if (/^(-{3,}|\*{3,})$/.test(t)) {
      endList();
      box.append(el("hr"));
      continue;
    }
    if (t.startsWith("|")) {
      endList();
      const rows = [];
      while (i < lines.length && lines[i].trim().startsWith("|")) rows.push(lines[i++].trim());
      i--;
      const table = el("table", "notes-table");
      const body = el("tbody");
      // The |---|---| line under the header is only layout.
      rows
        .filter((r) => !/^[\s|:-]+$/.test(r))
        .forEach((r, n) => {
          const tr = el("tr");
          cells(r).forEach((c) => tr.append(inline(el(n === 0 ? "th" : "td"), c, link)));
          (n === 0 ? table.createTHead() : body).append(tr);
        });
      table.append(body);
      const wrap = el("div", "table-wrap");
      wrap.append(table);
      box.append(wrap);
      continue;
    }
    if (t.startsWith(">")) {
      endList();
      box.append(inline(el("blockquote"), t.replace(/^>\s*/, ""), link));
      continue;
    }
    const bullet = t.match(/^(?:[-*•])\s+(.*)$/);
    const numbered = t.match(/^\d+[.)]\s+(.*)$/);
    if (bullet || numbered) {
      const kind = bullet ? "ul" : "ol";
      // An indented item belongs to the list item above it.
      const nested = /^\s{2,}/.test(line) && list?.lastElementChild;
      if (nested) {
        const parent = list.lastElementChild;
        let sub = parent.querySelector(":scope > ul, :scope > ol");
        if (!sub) parent.append((sub = el(kind)));
        sub.append(inline(el("li"), (bullet || numbered)[1], link));
        continue;
      }
      if (!list || listKind !== kind) {
        list = el(kind);
        listKind = kind;
        box.append(list);
      }
      list.append(inline(el("li"), (bullet || numbered)[1], link));
      continue;
    }
    endList();
    box.append(inline(el("p"), t, link));
  }
  return box;
}
