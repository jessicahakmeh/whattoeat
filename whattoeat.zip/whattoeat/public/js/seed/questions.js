// Questions asked one at a time, in this order.
//
// Each question filters meals on one property of the meals in js/meals.js:
//   id      unique name for the question
//   field   the meal property this question checks (e.g. "temp", "minutes")
//   title   the question text
//   multiple  optional; true lets you pick several options (a meal then
//             needs to fit any one of them), with a Next button to move on
//   options the answers to pick from; each option uses ONE of these filters:
//     value: "x"          meal[field] is "x" (or contains "x" if it's a list)
//     values: ["x", "y"]  meal[field] is any of these
//     min / max: number   meal[field] is within the range
//     any: true           no filter ("Surprise me")
//
// Options can also set `animate` to make their emoji move: roll, flicker,
// spin, zap, flip, sway, wiggle, bounce, swim or shake (see css/styles.css).
//
// Meals that don't have the field at all are never filtered out, so you can
// add a new question before tagging every meal with the new property.

// Every question ends with this "doesn't matter" option.
const SURPRISE = { any: true, emoji: "🎲", animate: "roll", label: "Surprise me", hint: "Doesn't matter" };

// The first question is the recipe's label (as in Notion), which also covers what the old
// "chicken, meat or vegetarian?" question asked. "Surprise me" leaves out desserts, sauces
// and mouneh, so they only come up when you ask for them.
window.QUESTIONS = [
  {
    id: "labels",
    field: "labels",
    title: "What kind of dish?",
    multiple: true,
    options: [
      { value: "Lebanese Tabekh", emoji: "🍲", animate: "bounce", label: "Lebanese Tabekh", hint: "Stews with rice" },
      { value: "Chicken", emoji: "🍗", animate: "bounce", label: "Chicken", hint: "Chicken mains" },
      { value: "Beef", emoji: "🥩", animate: "shake", label: "Beef", hint: "Meat mains" },
      { value: "Veg Mains", emoji: "🥦", animate: "sway", label: "Veg Mains", hint: "Vegetables, pulses and fish" },
      { value: "Pasta Dishes", emoji: "🍝", animate: "spin", label: "Pasta Dishes", hint: "Any kind of pasta" },
      { value: "Soup & Salad", emoji: "🥗", animate: "sway", label: "Soup & Salad", hint: "Light bowls" },
      { value: "Breakfast & Dinners", emoji: "🍳", animate: "wiggle", label: "Breakfast & Dinners", hint: "Eggs, sandwiches, quick plates" },
      { value: "Appetizers", emoji: "🥟", animate: "wiggle", label: "Appetizers", hint: "Mezze and bites" },
      { value: "Sauces Dips & Glazes", emoji: "🫙", animate: "wiggle", label: "Sauces Dips & Glazes", hint: "Something to dip in" },
      { value: "Dessert", emoji: "🍰", animate: "bounce", label: "Dessert", hint: "Something sweet" },
      { value: "MOUNEH", emoji: "🏺", animate: "sway", label: "Mouneh", hint: "Preserves, bread, pantry" },
      {
        values: ["Lebanese Tabekh", "Chicken", "Beef", "Veg Mains", "Pasta Dishes", "Soup & Salad", "Breakfast & Dinners", "Appetizers"],
        emoji: "🎲",
        animate: "roll",
        label: "Surprise me",
        hint: "Any meal (not desserts or sauces)"
      }
    ]
  },
  {
    id: "eaters",
    field: "eaters",
    title: "Who's eating?",
    options: [
      { value: "solo", emoji: "🙋", animate: "wiggle", label: "Just me", hint: "A plate for one" },
      { value: "family", emoji: "👨‍👩‍👧‍👦", animate: "bounce", label: "Family", hint: "Feeds the whole table" },
      SURPRISE
    ]
  },
  {
    id: "temp",
    field: "temp",
    title: "Hot or cold?",
    multiple: true,
    options: [
      { value: "hot", emoji: "🔥", animate: "flicker", label: "Hot", hint: "Something warm" },
      { value: "cold", emoji: "❄️", animate: "spin", label: "Cold", hint: "Fresh and chilled" },
      SURPRISE
    ]
  },
  {
    id: "time",
    field: "minutes",
    title: "Do you have time to cook?",
    options: [
      { max: 20, emoji: "⚡", animate: "zap", label: "In a rush", hint: "20 minutes or less" },
      { any: true, emoji: "⏳", animate: "flip", label: "I've got time", hint: "Slow-cooked is fine" },
      SURPRISE
    ]
  },
  {
    id: "cuisine",
    field: "cuisine",
    title: "What cuisine?",
    multiple: true,
    options: [
      { value: "lebanese", emoji: "🌲", animate: "sway", label: "Lebanese", hint: "Akl beyte, mezze, tabekh" },
      { value: "arab", emoji: "🫖", animate: "wiggle", label: "Arab", hint: "Gulf, Egyptian, Syrian, Moroccan" },
      { value: "mediterranean", emoji: "🫒", animate: "sway", label: "Mediterranean", hint: "Greek, Turkish, Spanish" },
      { value: "asian", emoji: "🥢", animate: "wiggle", label: "Asian", hint: "Noodles, rice, curries" },
      { value: "italian", emoji: "🍕", animate: "spin", label: "Italian", hint: "Pasta, pizza, risotto" },
      { value: "mexican", emoji: "🌮", animate: "bounce", label: "Mexican", hint: "Tacos, burritos, fajitas" },
      { value: "american", emoji: "🌭", animate: "wiggle", label: "American", hint: "Burgers, wings, diner classics" },
      { value: "other", emoji: "🌍", animate: "spin", label: "Something else", hint: "French, British, Caribbean…" },
      SURPRISE
    ]
  },
  {
    id: "mood",
    field: "mood",
    title: "What's the vibe?",
    multiple: true,
    options: [
      { value: "light", emoji: "🥗", animate: "sway", label: "Healthy & fresh", hint: "Light and clean" },
      { value: "protein", emoji: "💪", animate: "bounce", label: "High protein", hint: "Lean, low-cal, filling" },
      { value: "hearty", emoji: "🍲", animate: "bounce", label: "Hearty & cosy", hint: "Warm-hug food" },
      { value: "khabbousa", emoji: "🍔", animate: "shake", label: "Khabbousa", hint: "Messy, greasy, zero regrets" },
      SURPRISE
    ]
  },
  {
    id: "budget",
    field: "budget",
    title: "What's the budget?",
    multiple: true,
    options: [
      { value: "cheap", emoji: "🪙", animate: "spin", label: "Cheap", hint: "Pantry staples" },
      { value: "moderate", emoji: "💳", animate: "wiggle", label: "Moderate", hint: "A normal shop" },
      { value: "treat", emoji: "💎", animate: "flicker", label: "Treat", hint: "Go on, splurge" },
      SURPRISE
    ]
  }
];
