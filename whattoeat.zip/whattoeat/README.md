# What To Eat

**Shu mnekol? Let the wheel decide.**

A family recipe book, meal picker and grocery list. Answer a few questions and spin the wheel, find what you can cook with what's in the fridge, and keep a priced grocery list (food and household) that recipes can add to. Comes with 207 starter dishes, including the family's own recipes from Notion (labelled the same way), 250 Lebanese-kitchen grocery and household items, and Le Charcutier and Carrefour prices for them.

Runs on Firebase's free **Spark plan**: Hosting + Firestore only. There are no Cloud Functions, no Firebase Auth and no build step.

## Pages

| Page | Who | What |
| --- | --- | --- |
| `/` 🎡 Spin | public | Answer the questions, spin, respin |
| `/pantry.html` 🧺 Use it up | public | Type what you have; see what you can make, and what's missing |
| `/recipes.html` 📖 Recipes | public | Search the recipe book; filter by label (Lebanese Tabekh, Chicken, Dessert…) and by written / 💡 idea |
| `/recipe.html?id=…` | public | Ingredients, method, tips, linked recipes; 📤 Share PDF, ⬇ Excel, 📅 Plan. Cost and "add to grocery list" need the PIN |
| `/plan.html` 📅 Plan | PIN | A week at a time, breakfast / lunch / dinner, each with its servings; turns the week into a grocery list |
| `/editor.html` ✏️ | PIN | Write and edit recipes |
| `/groceries.html` 🛒 | PIN | Shopping list with budget and per-shop totals, items by category, price history per shop, ⚖️ kitchen converter |
| `/settings.html` ⚙️ | PIN | PIN setup, starter menu, backup/restore, import a recipe, wheel questions |

## Setup

1. **Create a Firebase project** at <https://console.firebase.google.com> (Spark plan is fine), then **Build → Firestore Database → Create database** (production mode, any region).
2. **Install the Firebase CLI** once and log in:
   ```
   npm install -g firebase-tools
   firebase login
   ```
3. **Point this folder at your project**: put your project ID in `.firebaserc`, or run `firebase use --add`.
4. **Deploy** the site and the security rules:
   ```
   firebase deploy
   ```
5. **Create your PIN.** Open `https://<project>.web.app/settings.html`, type a 6-digit PIN twice and press **Create PIN**.
6. **Import the starter menu.** On the same page, press **Import starter menu**, then **Grocery items: add …** (`public/js/seed/items.js`), then **Add … shop prices** (`public/js/seed/prices.js`).

Until step 6, every page shows the bundled starter menu from `public/js/seed/`.

**Updating later:** when `public/js/seed/meals.js` changes, deploy and press **Settings → Update from starter menu**. It adds the new dishes, refreshes the tags and labels of starter dishes, and removes the starter dishes listed in `RETIRED_MEALS` (marked `deleted`, so they can be restored from the console), but never touches recipes you've written steps for, and doesn't bring back recipes you deleted. It also replaces the wheel questions with the starter ones. The items button adds items whose names you don't have yet and fills in empty `aliases`, `brand` and `conversion` fields on the ones you do; the prices button adds only prices newer than yours for that item and shop.

**The Notion recipes** (exported 2026-11-07) are in `meals.js`: the 14 written ones with their ingredients, steps, tips and guides, the other 70 as 💡 ideas (name and label), replacing the starter recipe of the same dish where there was one. Notion's *Recipe Type* is the recipe's `labels`; *Preparation / Bake / Chill / Total Cook Time* are `prep`, `cook`, `chill` and `minutes`; an ingredient row's *State* is its `state`, and several ingredients in one row are swaps (except "Salt, Pepper", which are both used). The *Household Consumables* list is in the grocery items (Household).

### Running locally

```
firebase emulators:start
```

Open <http://localhost:5000>. The emulator's database starts empty: create a PIN and import from `/settings.html` as above. Opening `public/index.html` straight from disk also works, but read-only, using the bundled menu.

## How the PIN works (no Auth)

- The PIN **only locks the pages**: the grocery list, prices, recipe editor and settings ask for it; the wheel, Use it up and the recipe book don't.
- `settings/pin` holds a SHA-256 hash of the PIN; the PIN screen compares against it in the browser. Change it any time on **Settings → PIN**, and every device asks for the new one.
- The database itself is **open to the app**: anyone who knows the Firebase API for this project could read or change recipes, grocery items and prices without the PIN, and a 6-digit hash is easy to reverse. That's the trade-off for a simple PIN without sign-in; keep nothing private in it.
- The rules still keep the data in shape: recipes, questions and the snapshot can't be erased (**Delete** marks a recipe `deleted: true`), the PIN document must be a 64-character hash, and every other collection is closed.

## Data (Firestore)

```
snapshots/menu             every recipe + the questions as one JSON document, so a page
                           visit costs 1 read. Kept in sync on every save (transaction).

meals/{id}                 public recipes (id = slug of the name)
  name, emoji, description, servings, updatedAt
  minutes                  total time; prep, cook, chill are its parts (optional)
  labels                   the recipe's labels, as in Notion: "Lebanese Tabekh", "Chicken",
                           "Beef", "Veg Mains", "Pasta Dishes", "Soup & Salad", "Breakfast &
                           Dinners", "Appetizers", "Sauces Dips & Glazes", "Dessert", "MOUNEH"
  onWheel                  false = recipe book only; missing or true = also on the wheel
  type, temp, diet, cuisine, eaters, mood, budget    wheel tags (a value or a list)
  ingredients: [{ item, itemId, qty, state, optional, swaps: [{ item, itemId }] }]
                           qty = amount used ("200g"); state = how it's prepared ("diced",
                           "juiced"); swaps = alternatives you can use instead, each its
                           own grocery item (Tomatoes ↔ Cherry tomatoes)
  steps: [..]              a step's lines starting "- " are its sub-steps; **bold** works
  tips: [..]
  notes                    a longer guide in simple Markdown (headings, lists, tables), shown
                           under the method (the sourdough timelines)
  links: [{ id, label }]   e.g. { id: "tahini-sauce", label: "Dressing" }

questions/{id}             wheel questions, ordered by `order`

settings/pin               { hash } of the 6-digit PIN (checked by the PIN screen)

items/{id}                 grocery + household items; the id is the name as a slug
                           ("chicken-breast", "-2" if taken), kept when the item is renamed
  name, category           Produce, Dairy & eggs, Baking, Cleaning… or your own
  purchaseQty              pack size ("1kg", "6pcs", "1L")
  brand, aliases           a usual brand; other names to search by ("kammoun, cumin")
  conversion               your own weights, e.g. "1 tbsp = 16g; 1 pc = 150g" (beats the table)
  toPurchase, packs        on the grocery list, and how many packs to buy
  inCart                   ticked while shopping
  timesBought, lastBought  counted by "Done shopping", for the Buy again chips

prices/{priceId}           one record per price you enter (the full history)
  itemId, item, price, shop, qty, date
  lbp, product, url, note  optional: the shelf price in LBP, the product, its page

plans/{YYYY-MM}            the meal plan, one document per month:
  days: { "2026-10-26": { breakfast | lunch | dinner: { id, servings } } }
                           each slot is saved as its own field (two phones can plan at once;
                           works offline)

snapshots/prices           { latest: { "<itemId>|<shop>": price record } }: the latest price
                           of each item at each shop, so lists and costs cost 1 read however
                           long the history gets. Written in the same batch as each price
                           (works offline); built from the history on first use.
```

### Groceries

- **Adding**: one box on the List tab. Type "2 milk" for two packs; matches (by name, other names like "kammoun" or "javel", or brand) appear as chips to tap; with nothing typed, **Buy again** shows what you buy most. Pack size and category are under *Pack size & category* (new items get a guessed category).
- **Shopping**: the list is grouped by aisle in shopping order; tap anywhere on the name to tick it, ticked items sink to the bottom of their aisle, a bar shows how many are in the cart, and *Hide what's in the cart* keeps only what's left. Removing an item, **Done shopping** and **Empty list** can each be undone from the message that appears. **📤 Share** sends what's left by aisle (share sheet or WhatsApp).
- **Prices from**: at the top, *Latest anywhere*, *Cheapest shop* or one shop (Le Charcutier, Carrefour, Faddoul…). It sets the prices on every tab, recipe costs and the meal-plan list, and is remembered on the device. An item with no price at the chosen shop shows its price elsewhere ("only at …").
- **Budget**: the pinned bar shows the total at the chosen prices and what's still to get; under the list, the same list priced at each shop (with how many of the items it has) and the cheapest mix. Tap a shop to switch to its prices.
- **Finding items**: the Items tab search matches anywhere in the name, other names, brand or category, ignores case, accents and plurals, puts the best matches first, and also understands "food" and "household". Chips (All · Food · Household · each category, with counts) filter each tab. ✏️ edits the name, pack, category, brand, other names and conversion.
- **Price history**: the Prices tab lists every price with date, item (and product), shop (linked to its page when known), quantity, price (and LBP) and price per unit. Type a price in $ or LBP (converted at `LBP_RATE` in `public/js/cost.js`, 89,500). Pick an item (or click its price on the Items tab) to see each shop's latest price side by side, cheapest first.
- **Starter prices** (`public/js/seed/prices.js`, checked 2026-11-07): 134 from lecharcutier.com (read from the site) and 27 from Carrefour Lebanon's product pages as indexed by search (its site blocks automated reading and shows no date, so they're marked). Faddoul only shows prices in its phone app, so add those as you shop. Le Charcutier's site has few spices online, so most spices have no starter price.
- **⚖️ Convert**: type "1 tbsp tomato paste" to see what it weighs (≈ 17 g), what it costs from the pack you buy, and the usual measures of it; *Weighed it?* saves your own figure on the item, and recipes use it from then on.
- **Recipes → list**: each ingredient on a recipe page has its own ＋🛒 button, and it adds whichever swap you picked. New items get a guessed category you can change.
- **Offline**: Firestore keeps a copy in the browser, so the list works with a weak signal and syncs when you're back. If you remembered the PIN on the device, it opens offline too. Recipe edits need a connection.
- **Add to Home Screen**: `manifest.webmanifest` (name, icons in `icons/`, standalone) and the service worker `sw.js` make the site installable. iPhone: Safari → Share → Add to Home Screen. Android: Chrome → ⋮ → Add to Home screen / Install app; long-pressing the icon offers Groceries, Plan and Recipes. The service worker saves every page and script, and fetches the site's own files network-first (the saved copy if offline or after 3 s), so a deploy shows up on the next open; CDN libraries are versioned, so their saved copy is used. Add a new page or script to `SHELL` in `sw.js` to have it work offline before its first visit.

### Meal plan

- **Planning**: each day has breakfast, lunch and dinner. **＋ Add** opens a recipe search (breakfast lists small bites first; 🎲 picks one); − / + change the servings; × empties the slot. **📅 Plan** on a recipe page or **📅 Plan it** on the wheel's result asks which free slot to put it in. **💬 Share week** sends the week as a WhatsApp message.
- **Groceries from the plan**: **Build grocery list** adds up what the week's recipes need, scaled to the planned servings, as packs of each grocery item (1.5kg of courgettes sold per kg is 2 packs; ingredients without an amount count as one pack; optional ones are left out). Untick what you have, then **Add to the grocery list**: items already on the list keep the larger number of packs, so pressing it twice doesn't double anything.
- **Reads**: a week costs 1-2 reads (one per month it touches); building the list reads the items once, plus 1 for prices.

### Safety nets

- **Conflicts**: if someone else saved a recipe after you opened it, saving asks before replacing their changes.
- **📤 Share PDF** on a recipe page makes an A4 PDF of the recipe at the servings shown (header with the emoji, ingredients, numbered steps, tips). On a phone it opens the share sheet (WhatsApp, mail, Files…); on a computer it opens the PDF in a new tab to download or print. The pages are drawn as images (so emoji look right), which means the PDF's text can't be selected. The libraries (html2canvas, jsPDF) load only when you press the button.
- **⬇ Excel** on a recipe page downloads `<name>.xlsx`, readable on its own: sheets **Recipe** (Field / Value), **Ingredients** (Amount, Ingredient, Swap, Optional, Item ID; a swap is its own row under the ingredient it replaces; Item ID is the grocery item's id, e.g. `chicken-breast`), **Method**, **Tips** and **Goes with**. No PIN needed; no prices.
- **Settings → Import a recipe** reads that workbook (edited by hand is fine) or an older `.json` export: it shows what's in it, then imports it (or, when the name is taken, replaces that recipe or keeps both as "… (imported)"). Ingredients link to your grocery items by Item ID, then by name, and new names become items; links to recipes that aren't in this book are left out. Only known fields are kept, and sizes are limited.
- **Backups**: the Spark plan has no automatic backups. Use **Settings → Download backup** now and then; **Restore** writes a backup back (same ids are overwritten, nothing else is deleted). Items in a backup from before ids were names are given name ids and merged into the item of the same name.
- **Snapshot repair**: Settings → Rebuild snapshots, if the menu or the latest prices ever look out of date.
- **Readable item ids**: Settings → Give items readable ids renames any item whose id isn't its name (an old random id) and updates the recipes and prices that use it. It's safe to run again; the live database was switched on 2026-10-29.

### Costs

- **Making cost:** the packs you'd buy, at the **latest** price of each item: enough packs to cover every amount that uses the item (1.5kg of courgettes sold per kg is 2 packs), at least one each.
- **Per portion:** for each ingredient, price × (amount used ÷ pack size), added up and divided by the servings.
- Optional ingredients are left out. When some ingredients have no price, the cost is still worked out from the rest, marked **+** with a "⚠️ Partial cost" warning naming them; each ingredient line shows its own cost, or "⚠️ no price · add", which opens that item on the Prices tab. Estimated amounts are marked ≈, and a cost in *italics* is a whole pack.
- **Recipe book**: once the device is unlocked (or after 💰 Show costs), written recipes show their price per portion and how many ingredients have no price; *⚠️ Missing prices* lists just those.
- The currency symbol is `CURRENCY` in `public/js/cost.js`.

**Amounts and pack sizes** (`public/js/units.js`) are read as:

| Written | Read as |
| --- | --- |
| `200g`, `1.5 kg`, `1,5kg`, `1,000g`, `8 oz`, `2 lbs` | grams |
| `500ml`, `1L`, `2 tbsp`, `1 tsp`, `1/2 cup`, `1½ cups`, `half a cup`, `1 glass`, `2 fl oz` | millilitres (tsp 5, tbsp 15, cup 240, glass 250) |
| `3 pcs`, `6`, `2 eggs`, `1 medium onion`, `a dozen` | pieces |
| `2 cloves`, `1 bunch`, `2 cans`, `3 slices`, `4 leaves` | their own unit: compared with the same word |
| `1 can (400g)`, `2 cans (400g each)` | the weight in brackets |
| `2-3 cloves`, `2 to 3 tbsp` | the middle of the range (≈) |
| `6 x 1.5L`, `2x500g` | multipacks: 9L, 1kg |
| `10m`, `25 sq ft` | length and area (for foil and baking paper) |
| `a pinch`, `a dash` | 0.5g, 0.6ml (≈) |
| `a handful`, `2 handfuls` | a typical weight for the ingredient: parsley 15g, nuts 30g, spinach 30g… (≈) |
| `a splash`, `a big splash`, `a drizzle`, `a knob`, `a few` | 15ml, 22ml, 15ml, 15g, 3 pieces (≈) |
| `to taste`, `as needed` | about ½ tsp (≈) |
| `1/2 bag`, `1 jar`, `1 pack` of something with no known weight | that share of the pack you buy (≈) |
| no amount, for a seasoning or oil ("Salt", "Olive oil") | a typical amount: 1 tsp salt, 2 tbsp oil… (≈) |
| `some` | not measurable: the full pack price is used |

Changing the servings on a recipe page (and in its PDF) rescales each amount into the unit you'd measure it with: 6 tbsp × 2.5 is **1 cup**, ½ cup × ¼ is **2 tbsp**, 1 tbsp × ½ is **1½ tsp**, 700g × 2.5 is **1.75kg**, and "a handful" × 2.5 is **2½ handfuls**. Spoons round to ¼ tsp or ½ tbsp, and cups to ¼ or ⅓.

When the amount and the pack are different kinds, the conversion is approximate (≈) and uses the kitchen weights in `public/js/weights.js`: grams per cup for about 400 ingredients (USDA portion weights and standard baking charts: a tablespoon of tomato paste is 16-17 g, of flour 8 g, a cup of Egyptian rice 200 g), grams per piece (egg 60g, tomato 150g, onion 150g, lemon 100g…) and per counted unit (garlic clove 5g, bunch of parsley 100g…). Names are matched longest first, so "tomato paste" isn't read as "tomato". An ingredient prepared "juiced" turns juice into fruit (4 tbsp of lemon juice ≈ 170 g of lemons). An item's own **conversion** ("1 tbsp = 18g") always wins. Metres never become grams. The recipe page's **How it's worked out** shows each ingredient's amount, what it is in pack units, the price used and its cost. The recipe editor and the grocery forms show a dashed border on any amount, pack size or conversion that can't be read.

### Free-plan limits

Spark limits are **per Firebase project**: every app inside one project shares them, and a second project gets its own. Firestore allows 50,000 reads, 20,000 writes and 20,000 deletes a day, plus 1 GiB stored; Hosting allows 10 GB stored and 360 MB transferred a day. The snapshot must stay under 1 MB (roughly 1,500–2,500 written recipes).

What each page costs in reads (searching and filtering happen in the browser and cost nothing):

| Page | Reads per visit |
| --- | --- |
| Spin, Use it up, Recipes, a recipe page | 1 (the menu snapshot) |
| A recipe page with costs shown (PIN) | 1 + every item + 1 (latest prices) |
| Groceries (List, Items) | every item + 1 (latest prices) |
| Groceries → Prices tab | + every price, once per visit (the full history) |
| Recipe editor | every item + 1 |
| Meal plan | 1 + 1-2 (the months of the week); Build grocery list: + every item + 1 |
| Each save | a few writes; a snapshot is rewritten on recipe and price saves |

With 118 items, opening Groceries costs about 120 reads however many prices you add, so the daily 50,000 allows roughly 400 opens a day. Only the Prices tab reads the whole history.

## Wheel questions

The starter questions are: what kind of dish (the recipe labels; "Surprise me" leaves out desserts, sauces and mouneh), who's eating, hot or cold, time, cuisine, vibe and budget. The labels replace the old "vegan / chicken / fish / meat" question; recipes keep their `diet` tag. Edit them on `/settings.html` (JSON). Each question filters one recipe field, and each option uses one of:

| Option | Matches recipes where |
| --- | --- |
| `value: "x"` | the field is `"x"` (or contains it, if it's a list) |
| `values: ["x", "y"]` | the field is any of these (how "Vegetarian" includes vegan dishes) |
| `min: 10, max: 20` | the field is a number in that range (how "In a rush" works on `minutes`) |
| `any: true` | always ("Surprise me") |

While you answer, each option shows how many dishes it would leave given your other answers; options that would leave none are greyed out, so the wheel never ends up empty. (With 8 questions there are thousands of full combinations, more than any menu can fill, so this matters more than menu size.)

Optional per question: `multiple: true` lets you pick several answers. Optional per option: `animate` is one of `roll`, `flicker`, `spin`, `zap`, `flip`, `sway`, `wiggle`, `bounce`, `swim` or `shake`. New questions show up automatically as tag choices in the recipe editor. Recipes without the field match any answer.
